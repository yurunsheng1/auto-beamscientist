"""Reviewed supplementary experiments, independent of all model-written text.

These are post-exploration mechanism tests, not new pre-registered discoveries.
The caller freezes protocols and validated figure plans before running them.
"""
from dataclasses import replace
from pathlib import Path
import json
import time
import numpy as np
from scipy.special import gammainc
from scipy.optimize import brentq
from ..physics import AngularSpectrum, OpticalSetup
from .beams import base_field, normalize, rotate_field
from .schemas import Beam
from .physics import fresnel_direct


def disk_weights(sim, radius, subpixels=32):
    if radius<=0 or not 2<=subpixels<=64:raise ValueError('Invalid circular quadrature')
    r=np.sqrt(sim.r2);d=sim.dx/np.sqrt(2)
    weights=(r<=radius-d).astype(float)
    rows,cols=np.where(abs(r-radius)<=d)
    offsets=((np.arange(subpixels)+.5)/subpixels-.5)*sim.dx
    ox,oy=np.meshgrid(offsets,offsets)
    for row,col in zip(rows,cols):
        weights[row,col]=np.mean((sim.x[row,col]+ox)**2+(sim.y[row,col]+oy)**2<=radius**2)
    return weights


def vortex_field(sim,charge,aperture=.9e-3):
    if not isinstance(charge,int) or abs(charge)>6:raise ValueError('Trusted charge scan is bounded to integers -6..6')
    w=sim.setup.waist_m
    f=((sim.x+1j*np.sign(charge or 1)*sim.y)/w)**abs(charge)*np.exp(-sim.r2/w**2)
    return normalize(f*(sim.r2<=aperture**2),sim.dx,sim.setup.power_w)


def vortex_analytic(z,charge,waist,lam=633e-9,f=.06,rc=50e-6):
    wz=waist*np.sqrt((1-np.asarray(z)/f)**2+(lam*np.asarray(z)/(np.pi*waist**2))**2)
    return wz*np.sqrt(abs(charge)/2), gammainc(abs(charge)+1,2*rc**2/wz**2)


def coherent_core(c,cr,h,gamma,a,delta):
    den=1+a*a+2*a*np.real(np.exp(1j*delta)*gamma)
    if den<1e-10:raise ValueError('Coherent input cancels; no normalized output')
    return (c+a*a*cr+2*a*np.real(np.exp(1j*delta)*h))/den


class RevisionEngine:
    def __init__(self,out,backend='cuda',seconds=600,max_runs=180,phase_parameters=None):
        self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.phase_parameters=phase_parameters
        self.backend=backend;self.deadline=time.monotonic()+seconds;self.max_runs=max_runs;self.runs=[]

    def sim(self,n=384,waist=300e-6,lens=True,first=False,extent=2.4e-3,axial=21):
        z=np.linspace(.049,.071,axial) if lens or first else np.linspace(.02,.08,13 if axial==21 else axial)
        return AngularSpectrum(OpticalSetup(n=n,extent_m=extent,waist_m=waist),z,backend=self.backend,gpu_memory_mb=4096)

    def source(self,sim,family,scale=150e-6):
        return normalize(base_field(Beam(family,scale_m=scale),sim)*(sim.r2<=.9e-3**2),sim.dx,1.)

    def measure(self,sim,field,rc,label,direct=False):
        if len(self.runs)>=self.max_runs or time.monotonic()>self.deadline:raise RuntimeError('Supplemental experiment allowance exhausted')
        weights=disk_weights(sim,rc);spec=sim.fft2(field)
        core=[];pixel=[];edge=[];focal=None;phase=None
        for j,z in enumerate(sim.z_m):
            u=fresnel_direct(field,sim,z) if direct else sim.field(spec,j)
            image=abs(u)**2
            core.append(float(np.sum(image*weights)*sim.dx**2));pixel.append(float(np.sum(image[sim.r2<=rc**2])*sim.dx**2))
            edge.append(sim.edge_fraction(u))
            if j==int(np.argmin(abs(sim.z_m-.06))):focal=image;phase=np.angle(u)
        record={'label':label,'n':sim.setup.n,'extent_m':sim.setup.extent_m,'waist_m':sim.setup.waist_m,
                'z_planes':len(sim.z_m),'core_radius_m':rc,'solver':'direct Fresnel' if direct else 'scalar ASM','core':core,'pixel_core':pixel,
                'median':float(np.median(core)),'input_power':float(np.sum(abs(field)**2)*sim.dx**2),
                'retention':float(np.min(sim.input_spectral_retention(spec))),'edge_fraction':float(max(edge))}
        record['valid']=record['retention']>=.995 and record['edge_fraction']<=.01 and abs(record['input_power']-1)<1e-8
        np.savez_compressed(self.out/(label+'.npz'),x_m=sim.x[0],z_m=sim.z_m,core=core,pixel_core=pixel,focal=focal,phase=phase,input_field=field)
        self.runs.append(record)
        (self.out/'measurements.json').write_text(json.dumps(self.runs,indent=2))
        print('SUPPLEMENT',label,record['median'],record['valid'],flush=True)
        return record

    def run(self):
        results={};sim=self.sim(first=True,lens=False,n=768)
        best=self.phase_parameters
        if best is None:best=json.loads(Path('runs/pgcd/paper/assets/optimized_comparison.json').read_text())['best']
        parity=[]
        for family in ['gaussian','pearcey','butterfly']:
            par=best['gaussian_single' if family=='gaussian' else family+'_coherent']['parameters']
            rho2=sim.r2/sim.setup.waist_m**2
            phase=par['q2']*rho2+par['q4']*rho2**2+par['q3']*((sim.x/sim.setup.waist_m)**3+(sim.y/sim.setup.waist_m)**3)+par['ripple']*np.sin(2*rho2)
            u=self.source(sim,family)*np.exp(1j*phase);v=rotate_field(u,np.pi)
            even=(u+v)/2;odd=(u-v)/2
            pe=float(np.sum(abs(even)**2)*sim.dx**2);po=float(np.sum(abs(odd)**2)*sim.dx**2)
            arms=[self.measure(sim,normalize(f,sim.dx,1),35e-6,'parity_'+family+'_'+name) for name,f in [('single',u),('even',even),('odd',odd)]]
            err=np.max(abs(np.array(arms[0]['core'])-pe*np.array(arms[1]['core'])-po*np.array(arms[2]['core'])))
            parity.append({'family':family,'even_throughput':pe,'odd_throughput':po,'identity_error':float(err),'arms':arms})
        results['parity']=parity
        sim=self.sim(lens=False);quartic=[]
        for family in ['gaussian','pearcey','butterfly']:
            u=self.source(sim,family,200e-6);rho2=sim.r2/sim.setup.waist_m**2
            ratio=float(np.sum(abs(u)**2*rho2**2)/np.sum(abs(u)**2*rho2))
            base=self.measure(sim,u,50e-6,'quartic_'+family+'_base')
            for a in [.3,.6,.7]:
                q=self.measure(sim,u*np.exp(1j*a*rho2**2),50e-6,'quartic_'+family+'_'+str(a))
                c=self.measure(sim,u*np.exp(1j*a*ratio*rho2),50e-6,'quadratic_'+family+'_'+str(a))
                quartic.append({'family':family,'a4':a,'a2_equiv':a*ratio,'baseline':base,'quartic':q,'quadratic':c,
                    'residual_ratio':abs(q['median']-c['median'])/max(abs(c['median']-base['median']),1e-12)})
        results['quartic']=quartic
        vortex=[]
        for waist in [180e-6,300e-6]:
            sim=self.sim(waist=waist)
            for charge in range(7):
                u=vortex_field(sim,charge)*np.exp(1j*sim.lens_phase)
                rec=self.measure(sim,u,50e-6,'vortex_'+str(round(waist*1e6))+'_'+str(charge))
                radius,c=vortex_analytic(sim.z_m,charge,waist)
                vortex.append({'waist_m':waist,'charge':charge,'measurement':rec,'analytic_core':c.tolist(),'analytic_median':float(np.median(c)),
                               'ring_at_f_m':float(vortex_analytic(.06,charge,waist)[0])})
            rec=self.measure(sim,vortex_field(sim,-3)*np.exp(1j*sim.lens_phase),50e-6,'vortex_'+str(round(waist*1e6))+'_minus3')
        results['vortex']=vortex
        sim=self.sim();u=self.source(sim,'pearcey');v=rotate_field(u,np.pi)
        gamma=complex(np.sum(np.conj(u)*v)*sim.dx**2);weights=disk_weights(sim,35e-6)
        def cross_terms(source,rotated):
            us=sim.fft2(source*np.exp(1j*sim.lens_phase));vs=sim.fft2(rotated*np.exp(1j*sim.lens_phase))
            cs=[];rs=[];hs=[]
            for j in range(len(sim.z_m)):
                f=sim.field(us,j);g=sim.field(vs,j)
                cs.append(float(np.sum(weights*abs(f)**2)*sim.dx**2));rs.append(float(np.sum(weights*abs(g)**2)*sim.dx**2));hs.append(complex(np.sum(weights*np.conj(f)*g)*sim.dx**2))
            return np.array(cs),np.array(rs),np.array(hs)
        c,cr,h=cross_terms(u,v);coherence=[]
        for a in [1/3,.5,.733799,1.]:
            for delta in [0,np.pi/2,np.pi]:
                field=normalize(u+a*np.exp(1j*delta)*v,sim.dx,1)*np.exp(1j*sim.lens_phase)
                rec=self.measure(sim,field,35e-6,'coherence_'+str(a)+'_'+str(round(delta,5)))
                pred=coherent_core(c,cr,h,gamma,a,delta)
                coherence.append({'weight':a,'phase':delta,'measurement':rec,'predicted_core':pred.tolist(),'maximum_error':float(np.max(abs(pred-rec['core'])))})
        # Orthogonal even/odd Gaussian modes match global parity and input second moment.
        target_moment=float(np.sum(abs(u)**2*sim.r2)*sim.dx**2);g=float(np.real(gamma))
        def control(waist):
            even=normalize(np.exp(-sim.r2/waist**2)*(sim.r2<=.9e-3**2),sim.dx,1)
            odd=normalize(sim.x/waist*even,sim.dx,1)
            return np.sqrt((1+g)/2)*even+np.sqrt((1-g)/2)*odd
        w=brentq(lambda w:np.sum(abs(control(w))**2*sim.r2)*sim.dx**2-target_moment,50e-6,600e-6,xtol=1e-14)
        ctrl=control(w);rot=rotate_field(ctrl,np.pi);cc,rr,hh=cross_terms(ctrl,rot)
        ctrlrec=self.measure(sim,normalize(ctrl+.5*rot,sim.dx,1)*np.exp(1j*sim.lens_phase),35e-6,'coherence_matched_control')
        results['coherence']={'gamma':[gamma.real,gamma.imag],'c':c.tolist(),'cr':cr.tolist(),'h_real':h.real.tolist(),'h_imag':h.imag.tolist(),
            'cases':coherence,'control':ctrlrec,'control_baseline':float(np.median(cc)),'control_waist':w,'target_moment':target_moment,
            'moment_error':float(np.sum(abs(ctrl)**2*sim.r2)*sim.dx**2-target_moment),
            'overlap_error':float(abs(np.sum(np.conj(ctrl)*rot)*sim.dx**2-gamma)),
            'control_predicted_core':coherent_core(cc,rr,hh,gamma,.5,0).tolist()}
        # Frozen representative checks: identical fields, larger mesh/window, denser z and independent propagation.
        confirmations=[]
        for label,n,extent,axial,direct in [('mesh768',768,.0024,21,False),('window1152',1152,.0036,21,False),('axial41',384,.0024,41,False),('fresnel768',768,.0024,21,True)]:
            sim=self.sim(n=n,extent=extent,axial=axial)
            for recipe in ['quartic','vortex','coherence']:
                if recipe=='quartic':
                    simq=self.sim(n=n,extent=extent,lens=False,axial=axial);field=self.source(simq,'pearcey',200e-6)*np.exp(.7j*(simq.r2/simq.setup.waist_m**2)**2);s=simq;rc=50e-6
                elif recipe=='vortex':field=vortex_field(sim,3)*np.exp(1j*sim.lens_phase);s=sim;rc=50e-6
                else:
                    source=self.source(sim,'pearcey');field=normalize(source+.5*rotate_field(source,np.pi),sim.dx,1)*np.exp(1j*sim.lens_phase);s=sim;rc=35e-6
                record=self.measure(s,field,rc,recipe+'_'+label,direct)
                record['field_family']='pearcey' if recipe in ('quartic','coherence') else 'vortex'
                confirmations.append(record)
        results['confirmations']=confirmations
        results['quartic_full_confirmation']=quartic_full_confirmation(self)
        results['gradient_controls']=gradient_controls(self)
        results['status']=['SIMULATION_ONLY','NOVELTY_NOT_VERIFIED','NOT_PUBLICATION_READY']
        (self.out/'results.json').write_text(json.dumps(results,indent=2))
        return results


def quartic_full_confirmation(engine):
    """Confirm all three arms with unambiguous family and axial-grid identity."""
    records=[]
    for family in ['gaussian','pearcey']:
        for condition,n,axial,direct in [('mesh768',768,21,False),('fresnel768',768,21,True),('axial41',384,41,False)]:
            sim=engine.sim(n=n,lens=False,axial=axial);u=engine.source(sim,family,200e-6);rho=sim.r2/sim.setup.waist_m**2
            ratio=float(np.sum(abs(u)**2*rho**2)/np.sum(abs(u)**2*rho));arms={}
            for arm,field in [('baseline',u),('quartic',u*np.exp(.7j*rho**2)),('quadratic',u*np.exp(.7j*ratio*rho))]:
                rec=engine.measure(sim,field,50e-6,family+'_'+condition+'_'+arm,direct);rec['field_family']=family;arms[arm]=rec
            b,q,c=[arms[k]['median'] for k in ['baseline','quartic','quadratic']]
            records.append({'family':family,'condition':condition,'a4':.7,'a2_equiv':.7*ratio,'arms':arms,'residual_ratio':abs(q-c)/abs(c-b)})
    return records


def gradient_quadratic(field,sim,a4):
    """Intensity-weighted least-squares fit to the radial quartic phase gradient."""
    if not 0<=a4<=.7:raise ValueError('Reviewed quartic range is 0..0.7')
    rho=sim.r2/sim.setup.waist_m**2
    return 2*a4*float(np.sum(abs(field)**2*rho**2)/np.sum(abs(field)**2*rho))


def gradient_controls(engine):
    records=[];checks=[]
    for family in ['gaussian','pearcey','butterfly']:
        for a in [.3,.6,.7]:
            sim=engine.sim(lens=False);u=engine.source(sim,family,200e-6);rho=sim.r2/sim.setup.waist_m**2
            coef=gradient_quadratic(u,sim,a)
            records.append({'family':family,'a4':a,'coefficient':coef,'measurement':engine.measure(sim,u*np.exp(1j*coef*rho),50e-6,'gradient_'+family+'_'+str(a))})
    for family in ['gaussian','pearcey']:
        for direct in [False,True]:
            sim=engine.sim(n=768,lens=False);u=engine.source(sim,family,200e-6);rho=sim.r2/sim.setup.waist_m**2
            coef=gradient_quadratic(u,sim,.7)
            checks.append({'family':family,'coefficient':coef,'measurement':engine.measure(sim,u*np.exp(1j*coef*rho),50e-6,'gradient_'+family+('_fresnel768' if direct else '_mesh768'),direct)})
    return {'primary':records,'confirmations':checks}
