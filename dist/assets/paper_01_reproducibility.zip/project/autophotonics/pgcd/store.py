"""Transactional, resumable lineage including failed experiments and state events."""
from __future__ import annotations
from dataclasses import asdict
import json
import sqlite3
import datetime
from pathlib import Path


class ResearchStore:
    def __init__(self,path: Path,config: dict):
        self.db=sqlite3.connect(path)
        self.db.executescript('''
          PRAGMA journal_mode=WAL;
          CREATE TABLE IF NOT EXISTS config(id INTEGER PRIMARY KEY CHECK(id=1),data TEXT);
          CREATE TABLE IF NOT EXISTS nodes(id TEXT PRIMARY KEY,parent_id TEXT,data TEXT NOT NULL,ordinal INTEGER NOT NULL UNIQUE);
          CREATE TABLE IF NOT EXISTS experiments(id TEXT PRIMARY KEY,hypothesis_id TEXT,data TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,node_id TEXT,state TEXT,data TEXT,utc TEXT);
          CREATE TABLE IF NOT EXISTS archive(cell TEXT PRIMARY KEY,node_id TEXT,score REAL);
        ''')
        encoded=json.dumps(config,sort_keys=True)
        old=self.db.execute('SELECT data FROM config WHERE id=1').fetchone()
        if old and old[0]!=encoded:raise ValueError('Resume configuration differs from frozen protocol')
        self.db.execute('INSERT OR IGNORE INTO config VALUES(1,?)',(encoded,));self.db.commit()
    def node(self,node):
        data=asdict(node)
        with self.db:
            self.db.execute('''INSERT INTO nodes VALUES(?,?,?,(SELECT COALESCE(MAX(ordinal),0)+1 FROM nodes))
                            ON CONFLICT(id) DO UPDATE SET parent_id=excluded.parent_id,data=excluded.data''',
                            (node.id,node.parent_id,json.dumps(data)))
            self.db.execute('INSERT INTO events(node_id,state,data,utc) VALUES(?,?,?,?)',
                            (node.id,node.state,json.dumps(data),datetime.datetime.now(datetime.timezone.utc).isoformat()))
    def experiment(self,experiment):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO experiments VALUES(?,?,?)',
                            (experiment.id,experiment.hypothesis_id,json.dumps(asdict(experiment))))
    def all_nodes(self):
        return [json.loads(row[0]) for row in self.db.execute('SELECT data FROM nodes ORDER BY ordinal')]
    def update_archive(self,node):
        key=json.dumps(node.descriptor)
        row=self.db.execute('SELECT score FROM archive WHERE cell=?',(key,)).fetchone()
        if row is None or node.selection_score>row[0]:
            with self.db:self.db.execute('INSERT OR REPLACE INTO archive VALUES(?,?,?)',(key,node.id,node.selection_score))
    def export(self,out):
        nodes=self.all_nodes()
        (out/'research_tree.json').write_text(json.dumps(nodes,indent=2),encoding='utf-8')
        archive=[{'cell':json.loads(c),'node_id':i,'score':s} for c,i,s in self.db.execute('SELECT * FROM archive')]
        (out/'quality_diversity_archive.json').write_text(json.dumps(archive,indent=2),encoding='utf-8')
        return nodes
