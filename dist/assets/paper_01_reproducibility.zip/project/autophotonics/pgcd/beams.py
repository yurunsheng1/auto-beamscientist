"""Finite-aperture, power-normalized mathematical beam generators.

Catastrophe integrals use an exponentially convergent contour rotation, not a
polynomial phase mask mislabeled as a Pearcey or Butterfly field.
"""
from __future__ import annotations
from functools import lru_cache
import numpy as np
from scipy.special import airy
from scipy.ndimage import map_coordinates
from .schemas import Beam, Hypothesis


def catastrophe(u,v,order=4,points=192):
    """C_n(u,v)=integral_R exp[i(t^n+v*t^2+u*t)]dt, n=4 or 6.

    The real contour is deformed to t=s*exp(i*pi/(2*n)); the leading factor
    becomes exp(-s**n). u,v are one-dimensional real coordinate arrays. The
    two remaining Butterfly control parameters are explicitly zero here.
    """
    if order not in (4,6) or not 64<=points<=1024:raise ValueError('Unsupported catastrophe quadrature')
    s=np.linspace(-3.,3.,points)
    t=s*np.exp(1j*np.pi/(2*order))
    weights=np.ones(points)*(s[1]-s[0]);weights[[0,-1]]*=.5
    weights=weights*np.exp(1j*np.pi/(2*order))*np.exp(-s**order)
    return (np.exp(1j*np.outer(v,t*t))*weights) @ np.exp(1j*np.outer(t,u))


def normalize(field,dx,power):
    total=float(np.sum(abs(field)**2)*dx*dx)
    if not np.isfinite(total) or total<=0:raise ValueError('Invalid beam power')
    return np.asarray(field,dtype=complex)*np.sqrt(power/total)


def rotate_field(field,angle):
    """Rotate around the physical origin n//2, not the array's half-pixel center."""
    n=len(field);coords=np.arange(n)-n//2
    x,y=np.meshgrid(coords,coords)
    sample=np.array([(-np.sin(angle)*x+np.cos(angle)*y)+n//2,
                     (np.cos(angle)*x+np.sin(angle)*y)+n//2])
    return (map_coordinates(field.real,sample,order=1,mode='constant')+
            1j*map_coordinates(field.imag,sample,order=1,mode='constant'))


@lru_cache(maxsize=40)
def _base(family,n,extent,waist,scale,apodization,charge,points):
    x=(np.arange(n)-n//2)*extent/n
    xx,yy=np.meshgrid(x,x);r2=xx*xx+yy*yy
    if family=='gaussian':field=np.exp(-r2/waist**2)
    elif family=='vortex':
        field=((xx+1j*np.sign(charge or 1)*yy)/waist)**abs(charge)*np.exp(-r2/waist**2)
    elif family=='airy':
        one=airy(x/scale)[0]*np.exp(apodization*x/scale)
        field=np.outer(one,one)
    else:
        field=catastrophe(x/scale,x/scale,4 if family=='pearcey' else 6,points)*np.exp(-r2/waist**2)
    field=np.asarray(field,dtype=complex)
    field.setflags(write=False)
    return field


def base_field(beam: Beam,sim,points=192):
    p=sim.setup
    return _base(beam.family,p.n,p.extent_m,p.waist_m,beam.scale_m,
                 beam.apodization,beam.charge,points).copy()


def compose(h: Hypothesis,sim,*,chirp=0.,points=192,aperture_m=.9e-3):
    field=base_field(h.beam,sim,points)
    x,y=sim.x,sim.y
    rho2=sim.r2/sim.setup.waist_m**2
    for t in h.transformations:
        a=t.amount
        if t.kind=='chirp':field*=np.exp(1j*a*rho2)
        elif t.kind=='quartic':field*=np.exp(1j*a*rho2**2)
        elif t.kind=='quartic_xy':field*=np.exp(1j*a*((x/sim.setup.waist_m)**4+(y/sim.setup.waist_m)**4))
        elif t.kind=='ripple':field*=np.exp(1j*a*np.sin(2*rho2))
        elif t.kind=='vortex':field*=np.exp(1j*a*np.arctan2(y,x))
        elif t.kind=='rotate':
            field=rotate_field(field,a)
        elif t.kind=='stretch':
            # A defined anisotropic Gaussian amplitude transformation, not resampling the beam coordinates.
            field*=np.exp(-((a-1)*x*x+(1/a-1)*y*y)/sim.setup.waist_m**2)
        elif t.kind=='coherent_pair':field=field+np.exp(1j*a)*rotate_field(field,np.pi)
    field*=np.exp(1j*chirp*rho2)
    if h.environment.kind=='phase_screen':
        noise=np.random.default_rng(h.environment.seed).normal(0,h.environment.phase_rms,field.shape)
        field*=np.exp(1j*noise)
    field*=sim.r2<=aperture_m**2
    return normalize(field,sim.dx,sim.setup.power_w)


def airy_analytic(s,xi,a):
    """Finite-energy Airy solution, global carrier omitted (Siviloglou 2007)."""
    return airy(s-xi*xi/4+1j*a*xi)[0]*np.exp(a*s-a*xi*xi/2+
                       1j*(s*xi/2-xi**3/12+a*a*xi/2))
