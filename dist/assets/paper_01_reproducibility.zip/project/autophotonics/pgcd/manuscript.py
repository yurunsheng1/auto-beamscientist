"""Native PGCD evidence for the pinned AI Scientist writeup component."""
from __future__ import annotations
import json
from pathlib import Path
from ..paper_writing import WRITING, EDITORIAL_METHOD, EDITORIAL_METHOD_VERSION, load_editorial_method

AUTHOR='Auto BeamScientist Project'
SYSTEM='Auto BeamScientist'
EQUATIONS={
 'eq:input':r'U_0(x_j,y_k)=\sqrt{P/(\Delta x^2\sum_{a,b}|V_{ab}|^2)}\,V(x_j,y_k)',
 'eq:propagation':r'U_z=\mathcal F^{-1}[\mathcal F(U_0)B_z\exp(i2\pi z\sqrt{\lambda^{-2}-f_x^2-f_y^2})]',
 'eq:pair':r'U_c=\sqrt{\frac{P}{\int|U+a e^{i\delta}\mathcal R_\theta U|^2dA}}\,(U+a e^{i\delta}\mathcal R_\theta U)',
 'eq:observable':r'C(z)=P^{-1}\int_{x^2+y^2\leq r_c^2}|U_z|^2dA,\qquad \overline C=\operatorname{median}_{z\in\mathcal Z}C(z)',
}


def build_manuscript_context(evidence:dict,previous_review=None):
    registry=json.loads((WRITING/'sources.json').read_text())
    cards=[(WRITING/s['card']).read_text() for s in registry['sources'] if s.get('full_text_checked') and s.get('evidence_type')=='theory_and_numerical_only']
    equations='\n\n'.join('\\begin{equation}\n'+body+'\n\\label{'+label+'}\n\\end{equation}' for label,body in EQUATIONS.items())
    context='''Write a complete optics research article in the supplied unbranded preprint1 article template.
The system is Auto BeamScientist. Author and PDF author are Auto BeamScientist Project.
Use Introduction, an independent Related Work section, theoretical model, numerical methods,
results and physical interpretation, and Conclusions. Target 6--8 substantive pages without padding.
Use the actual positive and negative numerical observations to decide the scientific argument.
Explain the mechanism, equations, parameter values, controls, and the reason for each figure.
Use only supplied verified bibliography keys and actual evidence. No invented experiments or references.
The hypothesis is model-authored. Preserve its question and registered observable; never replace it
with the legacy axial-floor experiment or call a polynomial phase mask a canonical catastrophe beam.
Use the exact executed lens/environment/composition fields, rather than unexecuted prose in a proposal.
Composition uses an explicit rotation theta, relative phase delta and amplitude weight a.
An exactly zero coherent field cannot be normalized; other arms remain measurable.
For Airy V=Ai(x/s)Ai(y/s)exp(alpha*(x+y)/s) inside the aperture.
For Pearcey/Butterfly V=C_n(x/s,y/s)exp(-r^2/w^2), n=4/6, where
C_n(u,v)=integral exp(i*(t^n+v*t^2+u*t))dt. The unused Butterfly controls are zero.
The Gaussian envelope radius w comes from OpticalSetup. Beam.apodization affects Airy only.
The ASM bandwidth is a conservative radial cutoff, not the complete Matsushima construction.
State numerical methods naturally. Avoid repetitive defensive language and administrative warnings.
Do not print SIMULATION_ONLY, NOVELTY_NOT_VERIFIED, NOT_PUBLICATION_READY, or pending-review boilerplate.
Keep a concise factual acknowledgement that Auto BeamScientist adapts Sakana AI Scientist-v2.
The equations below define normalization, propagation, composition and circular-core energy.
Include and explain them, and add the actual primary-observable formula when it is not core energy.
Do not interpret baseline comparison effects as absolute concentration or a negated optimizer score.
Confirmation records show what actually ran; a diagnostic failing a check is not positive evidence.
Return complete compilable LaTeX with inline equations and embedded references.bib, not external inputs.
'''
    context+='\n## Project editorial method\n'+load_editorial_method()
    context+='\n## Trusted equations\n'+equations
    context+='\n## Verified writing exemplars: writing logic only, never experiment evidence\n'+'\n\n'.join(cards)
    context+='\n## Exact evidence packet\n'+json.dumps(evidence,ensure_ascii=False,indent=2)
    if previous_review:context+='\n## Prior automatic review\n'+json.dumps(previous_review)
    manifest={'author':AUTHOR,'system_name':SYSTEM,'required_equation_labels':list(EQUATIONS),
              'sources':registry['sources'],'template':'preprint1 / unbranded article','evidence_schema':'pgcd_manuscript_v1',
              'editorial_method':EDITORIAL_METHOD.name,'editorial_method_version':EDITORIAL_METHOD_VERSION}
    return context,manifest
