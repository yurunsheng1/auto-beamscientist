"""Auditable equations/known effects, with optional verified DOI metadata refresh."""
from __future__ import annotations
import datetime
import json
from pathlib import Path
from urllib.request import Request,urlopen
from .schemas import Beam

LIBRARY = Path(__file__).resolve().parents[2]/'integrations/pgcd/knowledge.json'


class KnowledgeAgent:
    def __init__(self,path=LIBRARY):
        self.data=json.loads(path.read_text(encoding='utf-8'))
    def beam(self,family):
        if family not in self.data['families']:raise ValueError('Unknown verified beam')
        return Beam(family,scale_m=60e-6 if family=='airy' else 300e-6)
    def citations(self,family):return self.data['families'][family]['sources']
    def retrieve(self,out,timeout=10):
        records=[]
        for doi in self.data['sources']:
            stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
            try:
                request=Request('https://api.crossref.org/works/'+doi,headers={'User-Agent':'AutoPhotonics-PGCD/0.1'})
                with urlopen(request,timeout=timeout) as stream:row=json.load(stream)['message']
                if row['DOI'].lower()!=doi.lower():raise ValueError('DOI metadata mismatch')
                records.append({'doi':doi,'retrieved_at_utc':stamp,'title':row.get('title'),
                                'status':'verified_metadata','scope':'metadata, not full-text novelty search'})
            except Exception as exc:
                records.append({'doi':doi,'retrieved_at_utc':stamp,'status':'retrieval_failed','error':str(exc)})
        (out/'retrieved_prior_art.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        return records
