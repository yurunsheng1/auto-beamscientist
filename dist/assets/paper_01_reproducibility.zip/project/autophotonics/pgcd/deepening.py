"""AI-owned continuation of recorded branches through experiments and writeup.

The coordinator supplies evidence, budgets and reviewed solver interfaces. The
pinned AI Scientist ideator and its model choose questions, tests and manuscripts.
"""
from __future__ import annotations
from dataclasses import replace
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from .planner import plan_research
from .loop import run_loop
from .research_experiment import ResearchBatch,ResearchExperiment,OBSERVABLES,COMPARISONS
from .journal import EvaluationJournal
from ..auto_paper import run_paper


def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')


def compact(record):
    return {k:record[k] for k in ('hypothesis','comparison','checks','executed_setup','coherent_cancellation','error') if k in record} | {
        'arm_metrics':{k:v['metrics'] for k,v in record.get('arms',{}).items()}}


def verified_bibliography(root):
    path=root/'runs/pgcd/paper/references.bib'
    text=path.read_text() if path.exists() else ''
    from .knowledge import KnowledgeAgent
    for i,(doi,source) in enumerate(KnowledgeAgent().data['sources'].items()):
        if doi.lower() not in text.lower():
            # Known metadata only; missing author information is never guessed.
            title=source['title'].replace('&',r'\&')
            text+='\n@misc{pgcd_source_'+str(i)+', title={'+title+'}, year={'+str(source['year'])+'}, howpublished={\\url{https://doi.org/'+doi+'}}}\n'
    text+='\n@misc{aiscientistv2, author={{Sakana AI}}, title={The AI Scientist-v2}, howpublished={\\url{https://github.com/SakanaAI/AI-Scientist-v2}}}\n' if 'aiscientistv2' not in text else ''
    return text


def source_branches(source:Path):
    branches=[]
    for p in sorted(source.glob('cycle_*')):
        q=p/'scientific_critique.json'
        if q.exists():
            critique=json.loads(q.read_text())
            if critique.get('next_action')=='continue':
                branches.append({'source_cycle':p.name,'frozen_protocol':json.loads((p/'frozen_protocol.json').read_text()),
                                 'scientific_critique':critique,
                                 'observations':[compact(r) for r in json.loads((p/'experiment_summary.json').read_text())]})
    if not branches:raise ValueError('No model-critic continue branches in the supplied run')
    return branches


def prepare_packet(research:Path,out:Path,*,backend,check,deadline,other_manuscripts,ledger_path=None,global_max_calls=1500):
    cycles=[p for p in sorted(research.glob('cycle_*')) if (p/'scientific_critique.json').exists()]
    if not cycles:return None
    cycle=cycles[-1];batch=ResearchBatch.from_dict(json.loads((cycle/'frozen_protocol.json').read_text()))
    records=json.loads((cycle/'experiment_summary.json').read_text())
    good=[r for r in records if r.get('checks') and all(r['checks'].values()) and r.get('comparison',{}).get('testable')]
    if not good:return None
    good.sort(key=lambda r:bool(r['comparison'].get('prediction_supported')),reverse=True)
    out.mkdir(parents=True,exist_ok=True)
    from .figure_planning import select_evidence_figure
    check()
    selection=select_evidence_figure(records,batch.question,out,deadline=deadline,
        ledger_path=ledger_path or Path(__file__).resolve().parents[2]/'runs/paper_api_budget.json',
        global_max_calls=global_max_calls)
    selected=set(selection.hypothesis_ids)
    good.sort(key=lambda r:r['hypothesis']['id'] not in selected)
    journal=EvaluationJournal(out,200,max(.1,deadline-time.monotonic()))
    confirmations=[]
    for record in good[:2]:
        h=next(h for h in batch.cases if h.id==record['hypothesis']['id'])
        variants=[('mesh256',256,2.4e-3,'asm'),('mesh384',384,2.4e-3,'asm'),
                  ('fresnel384',384,2.4e-3,'fresnel'),('window576',576,3.6e-3,'asm')]
        for label,n,extent,solver in variants:
            check()
            def compute():
                experiment=ResearchExperiment(batch,n=n,extent=extent,backend=backend,gpu_memory_mb=1024)
                return compact(experiment.evaluate(h,save=out/f'{h.id}_{label}.npz',propagator=solver))
            confirmations.append({'hypothesis_id':h.id,'condition':label,'measurement':journal.run(h.id+'/'+label,compute)})
        for label,kw in [('quantization',{'quantize':True}),('wavelength640',{'phase_wavelength_ratio':633/640})]:
            check()
            def compute():
                e=ResearchExperiment(batch,n=384,backend=backend,wavelength=640e-9 if label=='wavelength640' else 633e-9)
                return compact(e.evaluate(h,**kw))
            confirmations.append({'hypothesis_id':h.id,'condition':label,'measurement':journal.run(h.id+'/'+label,compute)})
        check()
        def axial():
            e=ResearchExperiment(batch,n=384,backend=backend)
            e.engine=e.engine.variant(z_m=np.linspace(batch.z_start_m,batch.z_end_m,41))
            return compact(e.evaluate(h))
        confirmations.append({'hypothesis_id':h.id,'condition':'axial41','measurement':journal.run(h.id+'/axial41',axial)})
    packet={'schema':'pgcd_manuscript_v1','question':batch.question,'frozen_protocol':batch.record(),
            'observations':[compact(r) for r in records],
            'controls':json.loads((cycle/'optimized_controls.json').read_text()),
            'scientific_critique':json.loads((cycle/'scientific_critique.json').read_text()),
            'confirmation_measurements':confirmations,'other_manuscripts':other_manuscripts,
            'figure_files':['research_results.png'],'source_cycle':str(cycle),
            'lineage':{'source_run':str(research),'source_protocol_sha256':hashlib.sha256((cycle/'frozen_protocol.json').read_bytes()).hexdigest(),
                       'generated_code_executed':False},
            'interpretation':'Report measured numerical effects and the actual executed lens and composition. A diagnostic failing a check remains a diagnostic; manuscript status is not discovery acceptance.'}
    write(out/'experiment.json',packet)
    (out/'research_brief.md').write_text('# '+batch.question+'\n\n'+json.dumps(packet,ensure_ascii=False,indent=2),encoding='utf-8')
    from .figure_planning import render_recorded_evidence
    plan, files = render_recorded_evidence(records, cycle, out, batch.observable, COMPARISONS[batch.comparison])
    from .figure_planning import render_selected_evidence
    additional=render_selected_evidence(selection,records,cycle,out)
    if additional:files.append(additional)
    packet['figure_selection']=json.loads((out/'figure_selection.json').read_text())
    packet['figure_caution']='Saved focal panels select their own brightest planes; a difference between them is not a same-plane interference cross term. Use separately frozen common-plane tests for that claim.'
    packet['figure_plan'] = plan.record()
    packet['figure_files'] = files
    packet['figure_scope'] = 'Recorded comparisons and individually identified propagation; a mechanism claim requires a separately frozen discriminating experiment.'
    write(out/'experiment.json',packet)
    (out/'research_brief.md').write_text('# '+batch.question+'\n\n'+json.dumps(packet,ensure_ascii=False,indent=2),encoding='utf-8')
    return packet


def deepen(source:Path,out:Path,*,target_papers=3,seconds=1800,max_new_calls=60,
           backend='cuda',n=192,depth_cycles=2,initial_plan:Path|None=None,resume=False):
    if not 1<=target_papers<=3 or not 30<=seconds<=7200 or not 1<=max_new_calls<=150:raise ValueError('Invalid bounded continuation budget')
    if not 1<=depth_cycles<=5:raise ValueError('Depth cycles must be 1..5')
    source=Path(source).resolve();out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True)
    lock=(out/'.deepening.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise RuntimeError('This continuation is already active')
    root=Path(__file__).resolve().parents[2];ledger=root/'runs/paper_api_budget.json'
    used=lambda:json.loads(ledger.read_text()).get('calls',0) if ledger.exists() else 0
    statefile=out/'pipeline_state.json'
    config={'source':str(source),'target_papers':target_papers,'seconds':seconds,'max_new_calls':max_new_calls,'backend':backend,'n':n,'depth_cycles':depth_cycles}
    if statefile.exists():
        state=json.loads(statefile.read_text())
        if not resume or state['config']!=config:raise ValueError('Use --resume with the frozen continuation configuration')
        prior_elapsed=state['elapsed_seconds']
    else:
        prior_elapsed=0.;state={'config':config,'status':'running','stage':'source_branches','calls_at_start':used(),'manuscripts':[],
                               'branches':[],'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    if state.get('error'):
        state.setdefault('prior_failures',[]).append({k:state.get(k) for k in ('error','error_type','stage','elapsed_seconds')})
    state['status']='running'
    for key in ('error','error_type','http_status'):state.pop(key,None)
    started=time.monotonic();deadline=started+max(0,seconds-prior_elapsed)
    call_limit=min(1500,state['calls_at_start']+max_new_calls)
    def save(stage):
        state.update(stage=stage,elapsed_seconds=prior_elapsed+time.monotonic()-started,cumulative_api_calls=used(),
                     updated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        write(statefile,state);print('DEEPENING',stage,'papers',len(state['manuscripts']),'calls',used(),flush=True)
    def check():
        if (out/'STOP').exists() or time.monotonic()>=deadline or used()>=call_limit:raise RuntimeError('Continuation reached its stopping allowance')
    try:
        branches=source_branches(source);write(out/'source_branches.json',branches);save('ai_scientist_selecting_continuation')
        for slot in range(1,6):
            if len(state['manuscripts'])>=target_papers:break
            check();branch=out/f'branch_{slot:02d}';branch.mkdir(exist_ok=True)
            if any(b['slot']==slot and b.get('finished') for b in state['branches']):continue
            context={'task':'Deepen the supplied model-critic continue branches. Choose your own concrete follow-up and hypothesis. Stay within those branches. Select a different load-bearing scientific question from the other manuscripts; do not split one dataset into multiple papers.',
                     'target_distinct_manuscripts':target_papers,'continue_branches':branches,'previous_branches':state['branches'],
                     'other_manuscripts':state['manuscripts'],'trusted_observables':OBSERVABLES,'trusted_comparisons':COMPARISONS,
                     'supported_composition':'Each hypothesis has composition angle_rad, phase_rad and amplitude weight. Exact cancellation disables only coherent comparisons, not independent single-arm measurements.',
                     'execution_contract':'free_space has no lens. thin_lens includes f=60mm. charge applies only to vortex family; use a vortex transformation otherwise. phase_screen activates the random pre-lens screen. Choose supported measurements explicitly.'}
            plan_path=Path(initial_plan) if slot==1 and initial_plan else branch/'plan/research_plan.json'
            if not plan_path.exists():
                plan_dir=branch/'plan'
                for attempt in range(2):
                    check()
                    try:
                        plan_research(plan_dir,max_calls=4,resume=plan_dir.exists(),global_max_calls=call_limit,
                                      ledger_path=ledger,research_context=context,deadline_monotonic=deadline)
                        break
                    except Exception as exc:
                        if getattr(exc,'status_code',None) in (401,402,403):raise
                        if attempt or len(list(plan_dir.glob('call_*.json')))>=4:raise
            plan=json.loads(plan_path.read_text());item={'slot':slot,'model_plan':plan,'finished':False}
            state['branches']=[b for b in state['branches'] if b['slot']!=slot]+[item]
            save('executing_ai_scientist_experiments')
            research=branch/'research'
            if (research/'loop_state.json').exists():result=json.loads((research/'loop_state.json').read_text())
            else:
                result=run_loop(research,hours=min(7.,max(.001,(deadline-time.monotonic())/3600)),
                                max_api_calls=call_limit,backend=backend,n=n,cases_per_cycle=5,max_cycles=depth_cycles,
                                max_evaluations=1500,initial_plan=plan_path,continuation_context=context,ledger_path=ledger)
            item['research_state']=result
            if result.get('status')=='provider_blocked':raise RuntimeError('Model provider blocked during experiments: '+str(result.get('provider_http_status')))
            save('independent_numerical_followup')
            evidence=branch/'evidence'
            packet=prepare_packet(research,evidence,backend=backend,check=check,deadline=deadline,other_manuscripts=state['manuscripts'],ledger_path=ledger,global_max_calls=call_limit)
            if packet is None:
                item.update(finished=True,outcome='no_testable_batch');save('branch_recorded');continue
            # Reuse verified bibliography already supplied with this project.
            (evidence/'verified_metadata.bib').write_text(verified_bibliography(root),encoding='utf-8')
            save('ai_scientist_manuscript_decision_and_writeup')
            attempts=sorted(branch.glob('manuscript*/paper_pipeline.json'),key=lambda p:p.stat().st_mtime)
            prior_states=[json.loads(p.read_text()) for p in attempts]
            paper=attempts[-1].parent if attempts else branch/'manuscript'
            if prior_states and prior_states[-1].get('status')!='failed':
                paper_state=prior_states[-1]
            else:
                previous=paper if attempts else None
                if attempts:
                    paper=branch/('manuscript_retry' if len(attempts)==1 else f'manuscript_retry_{len(attempts):02d}')
                allowance=15-sum(s.get('local_calls',0) for s in prior_states)
                if allowance<1:raise RuntimeError('The branch manuscript exhausted its call allowance')
                paper_state=run_paper(evidence,paper,max_calls=allowance,previous=previous,ledger_path=ledger,
                                      global_max_calls=call_limit,deadline_monotonic=deadline)
            item.update(finished=True,paper_state=paper_state)
            item['scientific_critique']=packet.get('scientific_critique',{})
            if (paper/'automatic_decision.json').exists():item['writing_decision']=json.loads((paper/'automatic_decision.json').read_text())
            if paper_state.get('status')=='completed':
                state['manuscripts'].append({'slot':slot,'question':packet['question'],'path':paper_state['manuscript'],
                                             'model_review_decision':paper_state.get('model_review_decision'),'kind':'research draft, not venue acceptance'})
            save('branch_recorded')
        state['status']='completed' if len(state['manuscripts'])>=target_papers else 'completed_available_branches'
    except Exception as exc:
        state.update(status='stopped',error_type=type(exc).__name__,error=str(exc),http_status=getattr(exc,'status_code',None))
    finally:
        save('finished' if state['status'].startswith('completed') else 'stopped')
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    return state
