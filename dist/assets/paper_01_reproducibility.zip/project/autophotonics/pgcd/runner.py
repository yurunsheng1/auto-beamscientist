"""Bounded PGCD research loop over trusted mathematical compositions.

This is a restricted project extension to AI Scientist, not an upstream arbitrary
code runner. Proposals can come from the deterministic evolver or validated JSON.
"""
from __future__ import annotations
from dataclasses import asdict
import datetime
import hashlib
import json
from pathlib import Path
import platform
import shutil
import sys
import time
import numpy as np
import scipy
from ..physics import OpticalSetup
from ..designs import Candidate, residual_phase
from ..budgeted_search import optimize_arm
from ..discovery import Trial, evaluate
from .schemas import Hypothesis, ResearchNode, Experiment
from .knowledge import KnowledgeAgent, LIBRARY
from .composition import CompositionAgent, ResearchEvolutionAgent, PhenomenonDiscoveryAgent
from .physics import ExperimentEngine, ClassicalAdapter, fresnel_direct
from .critic import ScientificCritic
from .journal import EvaluationJournal, BudgetStop
from .store import ResearchStore
from .report import report

ROOT=Path(__file__).resolve().parents[2]
STRATEGY=ROOT/'integrations/pgcd/strategy.md'


def source_files():
    return sorted(list((ROOT/'autophotonics/pgcd').glob('*.py'))+
                  [ROOT/'autophotonics'/name for name in ('physics.py','designs.py','discovery.py','budgeted_search.py')]+
                  [ROOT/'scientist_v2_cli.py',LIBRARY,STRATEGY])


def _run_pgcd(out: Path,*,backend='numpy',n=128,hypotheses=20,budget=64,seed=7,
             seconds=180,max_evaluations=3000,gpu_memory_mb=512,proposals: Path | None=None,
             retrieve_literature=False,agent='heuristic',model='deepseek-flash'):
    if isinstance(n,bool) or n<64 or n>256 or n%2:raise ValueError('PGCD n must be even and within 64..256')
    if not 1<=hypotheses<=20:raise ValueError('Hypothesis ceiling is 20 for this milestone')
    if not 32<=budget<=256:raise ValueError('Per-arm fitting budget must be 32..256')
    if not 1<=seconds<=600 or not 1<=max_evaluations<=10000:raise ValueError('Invalid bounded runtime/evaluation ceiling')
    if not 0<=seed<2**31:raise ValueError('Invalid seed')
    if not 32<=gpu_memory_mb<=1024:raise ValueError('GPU memory estimate budget must be 32..1024 MB')
    if backend not in ('numpy','cuda'):raise ValueError('Unsupported backend')
    if agent not in ('heuristic','llm'):raise ValueError('Unknown proposal agent')
    if proposals and agent=='llm':raise ValueError('Choose either JSON proposals or an LLM proposal agent')
    proposal_rows=None
    if proposals:
        raw=json.loads(proposals.read_text())
        if not isinstance(raw,list) or len(raw)!=hypotheses:raise ValueError('Provide exactly the requested number of JSON hypotheses')
        proposal_rows=[Hypothesis.from_dict(row) for row in raw]
        seen=set()
        for h in proposal_rows:
            if h.id in seen or (h.parent_id is not None and h.parent_id not in seen):
                raise ValueError('IDs must be unique and parents precede children')
            if h.minimum_gain!=.03:raise ValueError('Protocol freezes the 3% prediction margin')
            seen.add(h.id)
    setup=OpticalSetup(n=n)
    protocol={'strategy':'Physics-Guided Compositional Discovery','version':'pgcd-0.1',
              'reproduction_enabled':False,'mode':'direct_research','backend':backend,'setup':asdict(setup),
              'z_m':np.linspace(.049,.071,15).tolist(),'aperture_radius_m':.9e-3,
              'hypotheses':hypotheses,'budget_per_optimized_arm':budget,'seed':seed,
              'seconds':seconds,'max_evaluations':max_evaluations,'gpu_memory_mb':gpu_memory_mb,
              'objective':'min_z I(0,0,z) / max_z I_Gaussian(0,0,z)',
              'minimum_gain':.03,'minimum_retention':.995,'maximum_edge_fraction':.01,
              'independent_max_absolute_error':.02,'convergence_absolute_or_relative':[.005,.05],
              'phase_noise_rms_rad':.02,'phase_noise_seeds':[107,109,113],
              'holdout_wavelength_m':780e-9,'phase_quantization_bits':8,
              'quadrature_points':[192,384],'quadrature_overlap_minimum':.9999,
              'robustness_minimum_ratio':.9,'source_sha256':{
                  str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files()},
              'provided_hypotheses':[h.record() for h in proposal_rows] if proposal_rows else None,
              'retrieve_literature':retrieve_literature,'proposal_agent':agent,'model':model if agent=='llm' else None,
              'api_call_limit':4 if agent=='llm' else 0,
              'proposal_failure_policy':'Record model or schema errors; continue with reviewed deterministic composition for the affected batch.',
              'generated_code_execution':False,'human_discovery_approval_required':True,
              'screening_policy':'staged-v1: exploration does not require a performance gain or completed robustness; confirmation and discovery retain their gates',
              'baseline_fairness':'Equal per-arm fitting trial allowance, power, aperture and grid. Twenty structural arms have greater total cost than one control arm; no equal-total-cost discovery claim.',
              'status_labels':['SIMULATION_ONLY','NOVELTY_NOT_VERIFIED','NOT_PUBLICATION_READY']}
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    store=ResearchStore(out/'research.sqlite',protocol)
    if (out/'state.json').exists():
        prior=json.loads((out/'state.json').read_text())
        if prior.get('status')=='completed':store.db.close();return prior
    else:prior={}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
    (out/'artifacts').mkdir(exist_ok=True)
    snapshot=out/'source_snapshot'
    if not snapshot.exists():
        snapshot.mkdir()
        for p in source_files():
            target=snapshot/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(p,target)
    shutil.copyfile(LIBRARY,out/'knowledge.json');shutil.copyfile(STRATEGY,out/'strategy.md')
    journal=EvaluationJournal(out,max_evaluations,seconds,prior.get('elapsed_seconds',0.))
    state={'status':'running','strategy':'PGCD','mode':'direct_research','reproduction_enabled':False,
           'api_calls':0,'target_hypotheses':hypotheses,'completed_hypotheses':0,
           'scientific_status':protocol['status_labels'],'generated_code_execution':False,
           'proposal_mode':'validated_json' if proposals else ('llm_json_composition' if agent=='llm' else 'deterministic_evidence_guided_composition')}
    def save(stage):
        state.update(stage=stage,evaluations=journal.attempts,elapsed_seconds=journal.elapsed,
                     updated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (out/'state.json').write_text(json.dumps(state,indent=2))
        print('PGCD_STAGE',stage,'hypotheses',state['completed_hypotheses'],'evaluations',journal.attempts,flush=True)
    knowledge=KnowledgeAgent();baselines={}
    try:
        save('initializing_physics')
        engine=ExperimentEngine(setup,np.asarray(protocol['z_m']),backend=backend,gpu_memory_mb=gpu_memory_mb)
        hardware={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,
                  'backend':backend,'code_identity':'SHA256 source snapshot; enclosing parent repository commit does not identify this project.'}
        if backend=='cuda':
            cp=engine.sim.xp;props=cp.cuda.runtime.getDeviceProperties(0)
            hardware.update(cupy=cp.__version__,cuda_runtime=cp.cuda.runtime.runtimeGetVersion(),
                            gpu_name=props['name'].decode() if isinstance(props['name'],bytes) else props['name'])
        (out/'environment.json').write_text(json.dumps(hardware,indent=2))
        if retrieve_literature and not (out/'retrieved_prior_art.json').exists():
            journal.check();knowledge.retrieve(out,timeout=5)
        adapter=ClassicalAdapter(engine)
        def control_field(e,record):
            return e.gaussian*np.exp(1j*(e.sim.lens_phase+residual_phase(Candidate(**record),e.sim)))
        gaussian={'family':'gaussian_lens','q2':0.,'q3':0.,'q4':0.,'ripple':0.}
        g=journal.run('control/gaussian',lambda:evaluate(adapter,Candidate(**gaussian),engine.reference_peak).record())
        baselines['gaussian_lens']={'parameters':gaussian,'axial_floor':g['normalized_floor'],'retention':g['minimum_retained_power'],'attempts':1}
        for arm,names in [('defocus',['q2']),('quadratic_quartic',['q2','q4']),('four_parameter',['q2','q4','q3','ripple'])]:
            save('control_'+arm);counter=[0]
            def cached_evaluate(sim,candidate,reference_peak):
                index=counter[0];counter[0]+=1
                row=journal.run(f'control/{arm}/{index:03d}',lambda:evaluate(sim,candidate,reference_peak).record())
                return Trial(**row)
            trials=optimize_arm(adapter,engine.reference_peak,budget=budget,family=arm,names=names,seed=seed,trial_evaluator=cached_evaluate)
            best=max((t for t in trials if t.admissible),key=lambda t:t.normalized_floor)
            baselines[arm]={'parameters':best.candidate().record(),'axial_floor':best.normalized_floor,
                            'retention':best.minimum_retained_power,'attempts':budget}
        (out/'baselines.json').write_text(json.dumps(baselines,indent=2))
        save('validate_optimized_controls')
        control_variants={
            'mesh':engine.variant(n=n*2),
            'window':engine.variant(n=int(np.ceil(n*1.25/2))*2,
                                    extent=setup.extent_m*(int(np.ceil(n*1.25/2))*2)/n),
            'z_grid':engine.variant(z_m=np.linspace(.049,.071,29))}
        for name,b in baselines.items():
            field=control_field(engine,b['parameters'])
            def validate_control(field=field,b=b):
                metrics,_=engine.measure(field)
                trace=engine.trace(field)/engine.reference_peak
                indices=[0,7,14]
                direct=[float(abs(fresnel_direct(field,engine.sim,float(engine.sim.z_m[i]),np.array([0.]))[0,0])**2/engine.reference_peak) for i in indices]
                checks={'sampling_retention':metrics['retention']>=.995,
                        'window_edges':metrics['edge_fraction']<=.01,
                        'equal_power':abs(metrics['input_power_w']/setup.power_w-1)<1e-10,
                        'independent_fresnel':float(np.max(abs(trace[indices]-direct)))<=.02}
                diagnostics={'independent_error':float(np.max(abs(trace[indices]-direct)))}
                for label,v in control_variants.items():
                    row=v.quick(control_field(v,b['parameters']))
                    error=abs(row['axial_floor']-b['axial_floor'])
                    diagnostics[label+'_absolute_error']=error
                    checks[label+'_convergence']=error<=max(.005,.05*b['axial_floor'])
                return {'checks':checks,'diagnostics':diagnostics,'validated':all(checks.values())}
            b['validation']=journal.run('control_validation/'+name,validate_control)
        (out/'baselines.json').write_text(json.dumps(baselines,indent=2))
        strongest=max(baselines.values(),key=lambda b:b['axial_floor'])
        baseline={**strongest,'field_factory':lambda e:control_field(e,strongest['parameters']),
                  'controls_validated':all(b['validation']['validated'] for b in baselines.values())}
        known_fields={name:control_field(engine,b['parameters']) for name,b in baselines.items()}
        composer=CompositionAgent(knowledge,seed);critic=ScientificCritic(engine,journal,knowledge)
        llm=None;batch={}
        if agent=='llm':
            from .proposal_agent import PGCDProposalAgent
            llm=PGCDProposalAgent(out,knowledge,STRATEGY.read_text(),model,out.parent/'paper_api_budget.json')
        batch_path=out/'pending_proposals.json'
        if batch_path.exists():batch={int(k):Hypothesis.from_dict(v) for k,v in json.loads(batch_path.read_text()).items()}
        for index in range(hypotheses):
            nodes=store.all_nodes()
            if index<len(nodes):
                old=nodes[index]
                h=Hypothesis.from_dict(old['hypothesis'])
                if old['state'] in ('criticized','candidate','failed'):
                    state['completed_hypotheses']+=1
                    if (out/'artifacts'/f'{h.id}.npz').exists():
                        with np.load(out/'artifacts'/f'{h.id}.npz') as data:known_fields[h.id]=data['input_field'].copy()
                    continue
                node=ResearchNode(h.id,h.parent_id,h)
            else:
                journal.check()
                if llm and index not in batch:
                    save('llm_composition_batch')
                    count=min(5,hypotheses-index)
                    try:
                        proposed=llm.propose_batch(index,count,nodes,baselines,composer.propose(index,nodes),journal)
                    except BudgetStop:raise
                    except Exception as exc:
                        with (out/'proposal_errors.jsonl').open('a') as stream:
                            stream.write(json.dumps({'batch_start':index,'error':type(exc).__name__+': '+str(exc),
                                                     'fallback':'deterministic_evidence_guided_composition'})+'\n')
                        proposed=[composer.propose(index+offset,nodes) for offset in range(count)]
                    for offset,item in enumerate(proposed):batch[index+offset]=item
                    batch_path.write_text(json.dumps({str(k):v.record() for k,v in batch.items()},indent=2))
                    state['api_calls']=llm.local_calls
                    journal.check()
                h=proposal_rows[index] if proposal_rows else (batch[index] if llm else composer.propose(index,nodes))
                node=ResearchNode(h.id,h.parent_id,h);store.node(node)
            save('hypothesis_'+h.id);started=time.monotonic()
            try:
                rng=np.random.default_rng(seed+index*997);best=None
                for attempt in range(budget):
                    if attempt<25:chirp=float(np.linspace(-1.2,1.2,25)[attempt])
                    elif attempt%8==0:chirp=float(rng.uniform(-1.2,1.2))
                    else:chirp=float(np.clip(best['chirp']+rng.normal(0,.15/(1+attempt/64)**.5),-1.2,1.2))
                    def trial(chirp=chirp):
                        row=engine.quick(engine.input(h,chirp)[1]);row['chirp']=chirp;return row
                    row=journal.run(f'{h.id}/fit/{attempt:03d}',trial)
                    if best is None or (row['retention']>=.995 and (best['retention']<.995 or row['axial_floor']>best['axial_floor'])):best=row
                chirp=best['chirp'];pre,field=engine.input(h,chirp)
                def measure():
                    metrics,arrays=engine.measure(field)
                    np.savez_compressed(out/'artifacts'/f'{h.id}.npz',**arrays,pre_lens=pre)
                    return metrics
                metrics=journal.run(h.id+'/measure',measure)
                experiment=Experiment('E_'+h.id,h.id,seed+index*997,asdict(setup),metrics,budget,
                                      time.monotonic()-started,str(Path('artifacts')/f'{h.id}.npz'))
                (out/'artifacts'/f'{h.id}.json').write_text(json.dumps({**asdict(experiment),'fitted_chirp':chirp},indent=2))
                store.experiment(experiment);node.state='simulated';node.experiment_id=experiment.id;store.node(node)
                evidence,review=critic.review(h,chirp,metrics,baseline,known_fields)
                node.evidence=asdict(evidence);node.state='validated' if evidence.numerical_valid else 'validation_failed';store.node(node)
                node.review=asdict(review);node.descriptor=PhenomenonDiscoveryAgent.descriptor(metrics)
                cost=sum(key.startswith(h.id+'/') for key in journal.cache)
                node.selection_score=ResearchEvolutionAgent.score(metrics,evidence.diagnostics,evidence.numerical_valid,cost)
                node.state='candidate' if review.decision=='numerical_candidate' else 'criticized';store.node(node);store.update_archive(node)
                explanation=PhenomenonDiscoveryAgent.explain(h,metrics,evidence.diagnostics['ablations'])
                (out/'artifacts'/f'{h.id}_explanation.json').write_text(json.dumps(explanation,indent=2))
                known_fields[h.id]=field
            except BudgetStop:raise
            except Exception as exc:
                node.state='failed';node.review={'decision':'rejected','numerical_valid':False,
                    'prediction_supported':False,'reasons':['Solver/schema/validation failure: '+type(exc).__name__+': '+str(exc)]}
                store.node(node)
                with (out/'errors.jsonl').open('a') as stream:stream.write(json.dumps({'hypothesis':h.record(),'error':repr(exc)})+'\n')
            state['completed_hypotheses']+=1
            store.export(out);save('reviewed_'+h.id)
        state['status']='completed'
    except BudgetStop as exc:
        state.update(status='budget_exhausted',stop_reason=str(exc))
    except KeyboardInterrupt:
        state.update(status='interrupted',stop_reason='User interrupt; safely resumable')
    except Exception as exc:
        state.update(status='failed',stop_reason=type(exc).__name__+': '+str(exc))
        raise
    finally:
        state['api_calls']=len(list(out.glob('proposal_call_*.json')))
        state['proposal_error_batches']=len((out/'proposal_errors.jsonl').read_text().splitlines()) if (out/'proposal_errors.jsonl').exists() else 0
        nodes=store.export(out)
        if baselines:
            state.update(report(out,nodes,baselines,state,knowledge))
        save('finished');store.db.close()
    return state


def run_pgcd(out: Path,**kwargs):
    """Prevent concurrent resumes from double-spending experiments or API calls."""
    import fcntl
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with (out/'.run.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError as exc:raise RuntimeError('PGCD run already active in this output directory') from exc
        try:return _run_pgcd(out,**kwargs)
        finally:fcntl.flock(lock,fcntl.LOCK_UN)
