"""Typed, runtime-validated data boundary. No model-written executable content."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Literal
import math
import re

Family = Literal['gaussian','airy','pearcey','butterfly','vortex']
TRANSFORMS = {'chirp':(-1.2,1.2),'quartic':(-.7,.7),'quartic_xy':(-.7,.7),'ripple':(-1.,1.),
              'vortex':(-3.,3.),'rotate':(-math.pi,math.pi),'stretch':(.7,1.4),
              'coherent_pair':(-math.pi,math.pi)}


def finite(value,low,high,name):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not low<=value<=high:
        raise ValueError(f'{name} is outside [{low},{high}]')


def keys(data,allowed):
    if not isinstance(data,dict) or set(data)-set(allowed):
        raise ValueError('Unknown keys or executable content in structured interface')


@dataclass(frozen=True)
class Beam:
    family: Family
    scale_m: float = 60e-6
    apodization: float = .1
    charge: int = 1

    def __post_init__(self):
        if self.family not in ('gaussian','airy','pearcey','butterfly','vortex'):
            raise ValueError('Unknown verified beam family')
        finite(self.scale_m,20e-6,400e-6,'beam scale')
        finite(self.apodization,.05,.5,'apodization')
        finite(self.charge,-3,3,'charge')
        if int(self.charge)!=self.charge:raise ValueError('Vortex charge must be integral')


@dataclass(frozen=True)
class Transformation:
    kind: str
    amount: float

    def __post_init__(self):
        if self.kind not in TRANSFORMS:raise ValueError('Unknown transformation')
        finite(self.amount,*TRANSFORMS[self.kind],self.kind)
        if self.kind=='vortex' and int(self.amount)!=self.amount:
            raise ValueError('Vortex winding number must be integral')


@dataclass(frozen=True)
class Environment:
    kind: Literal['free_space','thin_lens','phase_screen'] = 'thin_lens'
    phase_rms: float = .02
    seed: int = 103

    def __post_init__(self):
        if self.kind not in ('free_space','thin_lens','phase_screen'):
            raise ValueError('Unsupported physical environment; no implicit nonlinear solver')
        finite(self.phase_rms,0,.1,'phase screen RMS')
        finite(self.seed,0,2**31-1,'environment seed')
        if int(self.seed)!=self.seed:raise ValueError('Environment seed must be integral')


@dataclass(frozen=True)
class Composition:
    angle_rad: float = math.pi
    phase_rad: float = 0.
    weight: float = 1.

    def __post_init__(self):
        finite(self.angle_rad,-math.pi,math.pi,'copy rotation')
        finite(self.phase_rad,-math.pi,math.pi,'relative phase')
        finite(self.weight,0.,1.,'copy amplitude weight')


@dataclass(frozen=True)
class Hypothesis:
    id: str
    beam: Beam
    transformations: tuple[Transformation,...]
    environment: Environment
    prediction: str
    mechanism: str
    minimum_gain: float = .03
    metric: str = 'axial_floor'
    parent_id: str | None = None
    composition: Composition = field(default_factory=Composition)

    def __post_init__(self):
        if not isinstance(self.id,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}',self.id):raise ValueError('Invalid hypothesis ID')
        if self.parent_id is not None and (not isinstance(self.parent_id,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}',self.parent_id)):raise ValueError('Invalid parent ID')
        if len(self.transformations)>3:raise ValueError('At most three transformations')
        if not isinstance(self.prediction,str) or not isinstance(self.mechanism,str) or not self.prediction.strip() or not self.mechanism.strip() or max(len(self.prediction),len(self.mechanism))>4000:
            raise ValueError('Every hypothesis requires a falsifiable prediction and mechanism')
        finite(self.minimum_gain,0,1,'prediction margin')
        if self.metric not in ('axial_floor','scientist_selected'):raise ValueError('Unsupported protocol metric')

    def record(self):return asdict(self)

    @classmethod
    def from_dict(cls,data):
        keys(data,cls.__dataclass_fields__)
        keys(data['beam'],Beam.__dataclass_fields__)
        keys(data['environment'],Environment.__dataclass_fields__)
        keys(data.get('composition',{}),Composition.__dataclass_fields__)
        for t in data['transformations']:keys(t,Transformation.__dataclass_fields__)
        return cls(**{**data,'beam':Beam(**data['beam']),
                      'environment':Environment(**data['environment']),
                      'composition':Composition(**data.get('composition',{})),
                      'transformations':tuple(Transformation(**t) for t in data['transformations'])})


@dataclass
class Experiment:
    id: str
    hypothesis_id: str
    seed: int
    setup: dict
    metrics: dict[str,float]
    attempts: int
    elapsed_seconds: float
    artifact: str
    status: str = 'simulated'


@dataclass
class Evidence:
    hypothesis_id: str
    checks: dict[str,bool]
    diagnostics: dict
    citations: list[str] = field(default_factory=list)
    simulation_only: bool = True
    novelty_verified: bool = False

    @property
    def numerical_valid(self):return bool(self.checks) and all(self.checks.values())


@dataclass
class Review:
    hypothesis_id: str
    numerical_valid: bool
    prediction_supported: bool
    equivalent_to: str | None
    reasons: list[str]
    decision: Literal['rejected','known_control','exploratory','numerical_candidate','research_candidate']
    novelty_verified: bool = False
    human_reviewed: bool = False
    stage: Literal['exploration','candidate_confirmation','discovery'] = 'exploration'

    def __post_init__(self):
        if self.decision not in ('rejected','known_control','exploratory','numerical_candidate','research_candidate'):
            raise ValueError('Unknown review decision')
        if self.decision=='numerical_candidate' and not (self.numerical_valid and self.prediction_supported and not self.equivalent_to):
            raise ValueError('Numerical candidate requires numerical, prediction and equivalence gates')
        if self.decision=='research_candidate' and not (self.numerical_valid and self.prediction_supported and self.novelty_verified and self.human_reviewed and not self.equivalent_to):
            raise ValueError('Discovery acceptance requires numerical, novelty and human gates')


@dataclass
class ResearchNode:
    id: str
    parent_id: str | None
    hypothesis: Hypothesis
    state: str = 'idea'
    selection_score: float = 0.
    descriptor: tuple[int,int] | None = None
    experiment_id: str | None = None
    evidence: dict | None = None
    review: dict | None = None
