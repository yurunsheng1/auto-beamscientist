"""Trusted PGCD experiment engine; LLMs never enter this module's execution path."""
from __future__ import annotations
from dataclasses import replace
import numpy as np
from ..physics import AngularSpectrum, OpticalSetup
from .beams import compose, normalize
from .schemas import Hypothesis


def fresnel_direct(field,sim,z,x_out=None):
    """Independent separable real-space Fresnel quadrature (not an ASM FFT).

    U=e^(ikz)/(i*lambda*z) integral U0 exp[ik*((x-x')²+(y-y')²)/(2z)] dx'dy'.
    The paraxial model must agree only in its applicable low-angle regime.
    CUDA uses explicit CuPy matrix products; CPU is an explicit backend choice.
    """
    if z<=0:raise ValueError('Direct Fresnel requires z>0')
    xp=sim.xp
    xin=xp.asarray(sim.x[0])
    output=xin if x_out is None else xp.asarray(x_out)
    k=2*np.pi/sim.setup.wavelength_m
    matrix=xp.exp(1j*k/(2*z)*(output[:,None]-xin[None,:])**2)
    result=np.exp(1j*k*z)/(1j*sim.setup.wavelength_m*z)*sim.dx**2*(matrix@xp.asarray(field)@matrix.T)
    return sim.to_host(result)


class ExperimentEngine:
    def __init__(self,setup: OpticalSetup,z_m,*,backend='numpy',gpu_memory_mb=512,aperture_m=.9e-3):
        if not 0<aperture_m<setup.extent_m/2:raise ValueError('Aperture must lie inside window')
        self.sim=AngularSpectrum(setup,z_m,backend=backend,gpu_memory_mb=gpu_memory_mb)
        self.aperture_m=aperture_m
        self.gaussian=normalize(self.sim.amplitude*(self.sim.r2<=aperture_m**2),self.sim.dx,setup.power_w)
        self.reference_peak=float(self.trace(self.gaussian*np.exp(1j*self.sim.lens_phase)).max())

    def input(self,h: Hypothesis,chirp=0.,points=192):
        pre=compose(h,self.sim,chirp=chirp,points=points,aperture_m=self.aperture_m)
        return pre,self.with_lens(pre,h)

    def with_lens(self,pre,h):
        return pre*np.exp(1j*self.sim.lens_phase) if h.environment.kind!='free_space' else pre

    def trace(self,field):return self.sim.center_trace_from_spectrum(self.sim.fft2(field))

    def quick(self,field):
        spec=self.sim.fft2(field)
        trace=self.sim.center_trace_from_spectrum(spec)
        keep=float(np.min(self.sim.input_spectral_retention(spec)))
        return {'axial_floor':float(trace.min()/self.reference_peak),
                'peak_on_axis':float(trace.max()/self.reference_peak),'retention':keep}

    def measure(self,field):
        sim=self.sim
        spec=sim.fft2(field)
        trace=sim.center_trace_from_spectrum(spec)
        fields=np.asarray([sim.field(spec,j) for j in range(len(sim.z_m))])
        intensity=abs(fields)**2
        flat=intensity.reshape(len(fields),-1)
        peak_indices=np.argmax(flat,axis=1)
        rows,cols=np.unravel_index(peak_indices,field.shape)
        trajectory=np.column_stack((sim.z_m,sim.x[rows,cols],sim.y[rows,cols]))
        j=int(np.argmax(flat.max(axis=1)))
        focal=intensity[j]
        radius2=(sim.x-sim.x[rows[j],cols[j]])**2+(sim.y-sim.y[rows[j],cols[j]])**2
        core=radius2<=(110e-6)**2
        energy=float(focal.sum()*sim.dx**2)
        core_fraction=float(focal[core].sum()/focal.sum())
        outside=focal[~core]
        metrics=self.quick(field)
        metrics.update({'focal_intensity':float(focal.max()),'focal_z_m':float(sim.z_m[j]),
                        'core_efficiency':core_fraction,'sidelobe_energy_fraction':1-core_fraction,
                        'sidelobe_peak_ratio':float(outside.max()/focal.max()) if outside.size else 0.,
                        'output_power_w':energy,'input_power_w':float(np.sum(abs(field)**2)*sim.dx**2),
                        'trajectory_excursion_m':float(np.linalg.norm(trajectory[:,1:]-trajectory[0,1:],axis=1).max()),
                        'edge_fraction':max(sim.edge_fraction(f) for f in fields)})
        return metrics,{'z_m':sim.z_m,'on_axis':trace/self.reference_peak,
                        'trajectory':trajectory,'focal_intensity':focal,'input_field':field,
                        'longitudinal_cut':intensity[:,sim.setup.n//2,:]}

    def variant(self,*,n=None,extent=None,wavelength=None,z_m=None):
        p=self.sim.setup
        return ExperimentEngine(replace(p,n=n or p.n,extent_m=extent or p.extent_m,
                                         wavelength_m=wavelength or p.wavelength_m),
                                self.sim.z_m if z_m is None else z_m,backend=self.sim.backend,
                                gpu_memory_mb=self.sim.gpu_memory_mb,aperture_m=self.aperture_m)


class ClassicalAdapter:
    """Reuse the existing optimized-control code with PGCD's identical aperture."""
    def __init__(self,engine):
        self.engine=engine;self.sim=engine.sim;self.setup=self.sim.setup
        self.x=self.sim.x;self.y=self.sim.y
    def input_field(self,phase=0.):
        return self.engine.gaussian*np.exp(1j*(self.sim.lens_phase+phase))
    def __getattr__(self,name):return getattr(self.sim,name)
