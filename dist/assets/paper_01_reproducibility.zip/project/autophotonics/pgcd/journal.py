"""Reserved attempts, deterministic replay and cumulative work/time ceilings."""
from __future__ import annotations
import datetime
import json
import time


class BudgetStop(RuntimeError):pass


class EvaluationJournal:
    def __init__(self,out,max_evaluations,seconds,prior_seconds=0.):
        self.path=out/'evaluations.jsonl';self.limit=max_evaluations;self.seconds=seconds
        self.started=time.monotonic();self.prior_seconds=prior_seconds;self.cache={};self.attempts=0
        if self.path.exists():
            for line in self.path.read_text().splitlines():
                row=json.loads(line)
                if row['status']=='started':self.attempts+=1
                elif row['status']=='completed':self.cache[row['key']]=row['result']
        self.starting_attempts=self.attempts

    @property
    def elapsed(self):return self.prior_seconds+time.monotonic()-self.started

    def append(self,row):
        row['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with self.path.open('a') as stream:
            stream.write(json.dumps(row,allow_nan=False)+'\n');stream.flush()

    def check(self):
        if self.elapsed>=self.seconds:raise BudgetStop('Cumulative wall-work time ceiling reached')
        if self.attempts>=self.limit:raise BudgetStop('Cumulative evaluation ceiling reached')

    def run(self,key,compute):
        if key in self.cache:return self.cache[key]
        self.check();self.attempts+=1;seq=self.attempts
        self.append({'key':key,'attempt':seq,'status':'started'})
        start=time.monotonic()
        try:
            value=compute()
            # Reject NaN/Inf before persistence or downstream comparisons.
            json.dumps(value,allow_nan=False)
            self.append({'key':key,'attempt':seq,'status':'completed','result':value,
                         'elapsed_seconds':time.monotonic()-start})
            self.cache[key]=value
            return value
        except BaseException as exc:
            self.append({'key':key,'attempt':seq,'status':'failed','error':type(exc).__name__+': '+str(exc),
                         'elapsed_seconds':time.monotonic()-start})
            raise
