"""Reviewed measurements for model-selected questions, without generated code."""
from __future__ import annotations
from dataclasses import dataclass,replace,asdict
import numpy as np
from scipy.signal import find_peaks
from .schemas import Hypothesis,Beam,finite,keys
from .beams import rotate_field,normalize
from .physics import ExperimentEngine,fresnel_direct

OBSERVABLES={
 'axial_floor':'Minimum on-axis intensity / Gaussian peak over the frozen window.',
 'peak_intensity':'Maximum transverse intensity / Gaussian on-axis peak over the frozen window.',
 'core_efficiency':'Median power inside a fixed, on-axis circular core / input power.',
 'sidelobe_fraction':'Median power outside that core / propagated power; not a canonical lobe decomposition.',
 'peak_excursion_m':'Largest displacement of the brightest pixel from its first-plane position; degenerate maxima are ambiguous.',
 'centroid_excursion_m':'Largest displacement of the power centroid from its first-plane position.',
 'peak_bending_m':'Largest deviation of brightest-pixel trajectory from the line joining first and last points.',
 'intensity_overlap':'Median intensity cosine overlap with the single-arm reference; scalar, not phase fidelity.',
 'valley_filling':'Median valley/mean-ridge intensity in the y-integrated x profile; requires two prominent ridges.',
 'ridge_separation_m':'Median separation of those two ridges; no qualifying pair means untestable.',
 'focal_z_m':'Position of the brightest sampled transverse peak.'}
COMPARISONS={'coherent_vs_single':('coherent','single'),
             'coherent_vs_incoherent':('coherent','incoherent'),
             'transformed_vs_base':('single','base'),
             'perturbed_vs_clean':('perturbed','single')}


@dataclass(frozen=True)
class ResearchBatch:
    question: str
    mechanism: str
    observable: str
    comparison: str
    effect: str
    direction: str
    threshold: float
    z_start_m: float
    z_end_m: float
    z_planes: int
    core_radius_m: float
    marginal_half_width_m: float
    ridge_prominence: float
    phase_noise_rms: float
    max_separation_change: float | None
    cases: tuple[Hypothesis,...]

    def __post_init__(self):
        if not isinstance(self.question,str) or not self.question.strip() or len(self.question)>6000:raise ValueError('Missing bounded scientific question')
        if not isinstance(self.mechanism,str) or not self.mechanism.strip() or len(self.mechanism)>6000:raise ValueError('Missing proposed mechanism')
        if self.observable not in OBSERVABLES or self.comparison not in COMPARISONS:raise ValueError('Unsupported trusted measurement/comparison')
        if self.effect not in ('ratio','difference','relative_change') or self.direction not in ('>=','<='):raise ValueError('Invalid prediction operator')
        finite(self.threshold,-1e6,1e6,'prediction threshold')
        finite(self.z_start_m,.01,.19,'z start');finite(self.z_end_m,.011,.2,'z end')
        if self.z_end_m<=self.z_start_m:raise ValueError('Empty observation window')
        finite(self.z_planes,5,21,'z planes')
        if int(self.z_planes)!=self.z_planes:raise ValueError('Integral plane count required')
        finite(self.core_radius_m,20e-6,250e-6,'core radius')
        finite(self.marginal_half_width_m,.2e-3,.6e-3,'marginal half width')
        finite(self.ridge_prominence,.1,.5,'ridge prominence')
        finite(self.phase_noise_rms,0,.1,'phase noise')
        if self.max_separation_change is not None:finite(self.max_separation_change,0,1,'separation guard')
        if not 1<=len(self.cases)<=20:raise ValueError('At most 20 hypotheses per frozen batch')
        if len({h.id for h in self.cases})!=len(self.cases):raise ValueError('Duplicate hypothesis IDs')
        if len({h.environment.kind for h in self.cases})!=1:raise ValueError('Use one common environment per comparison batch')
        if self.comparison in ('coherent_vs_single','coherent_vs_incoherent') and all(
            h.transformations and h.transformations[-1].kind=='coherent_pair' and
            abs(h.transformations[-1].amount)<1e-12 for h in self.cases):
            raise ValueError('All source fields already contain the same coherent projection; the requested comparison is degenerate')
        for h in self.cases:
            if h.beam.family in ('pearcey','butterfly') and h.beam.scale_m<150e-6:
                raise ValueError('Catastrophe scale requires at least 150 micrometres in this protocol')

    @classmethod
    def from_dict(cls,data):
        keys(data,cls.__dataclass_fields__)
        return cls(**{**data,'cases':tuple(Hypothesis.from_dict(h) for h in data['cases'])})

    def record(self):return asdict(self)


def ridge_profile(intensity,sim,width,prominence):
    x=sim.x[0];inside=abs(x)<width
    profile=intensity[inside,:].sum(axis=0)*sim.dx
    peaks,_=find_peaks(profile,prominence=prominence*float(profile.max()))
    peaks=peaks[inside[peaks]]
    if len(peaks)<2:return {'eligible':False,'separation_m':None,'valley':None},profile
    chosen=sorted(peaks[np.argsort(profile[peaks])[-2:]])
    left,right=chosen
    middle=(x[left]+x[right])/2
    valley=float(np.interp(middle,x,profile)/((profile[left]+profile[right])/2))
    return {'eligible':True,'separation_m':float(x[right]-x[left]),'valley':valley},profile


def summarize(intensities,engine,batch,reference=None):
    sim=engine.sim;intensity=np.asarray(intensities)
    powers=intensity.sum(axis=(1,2))*sim.dx**2
    if np.any(powers<=0) or not np.isfinite(intensity).all():raise ValueError('Invalid propagated intensity')
    flat=intensity.reshape(len(intensity),-1)
    rows,cols=np.unravel_index(np.argmax(flat,axis=1),intensity.shape[1:])
    peak_path=np.column_stack((sim.x[rows,cols],sim.y[rows,cols]))
    centroid=np.column_stack(((intensity*sim.x).sum(axis=(1,2))/(intensity.sum(axis=(1,2))),
                              (intensity*sim.y).sum(axis=(1,2))/(intensity.sum(axis=(1,2)))))
    line=peak_path[0]+np.linspace(0,1,len(intensity))[:,None]*(peak_path[-1]-peak_path[0])
    core=sim.r2<=batch.core_radius_m**2
    core_power=intensity[:,core].sum(axis=1)*sim.dx**2
    ridge=[];profiles=[]
    for image in intensity:
        row,profile=ridge_profile(image,sim,batch.marginal_half_width_m,batch.ridge_prominence)
        ridge.append(row);profiles.append(profile)
    eligible=[r for r in ridge if r['eligible']]
    overlap=1.
    if reference is not None:
        numerator=(intensity*reference).sum(axis=(1,2))
        denominator=np.sqrt((intensity**2).sum(axis=(1,2))*(reference**2).sum(axis=(1,2)))
        overlap=float(np.median(numerator/denominator))
    edge=int(round(sim.setup.n*.12));mask=np.ones(intensity.shape[1:],bool);mask[edge:-edge,edge:-edge]=False
    metrics={'axial_floor':float(intensity[:,sim.setup.n//2,sim.setup.n//2].min()/engine.reference_peak),
             'peak_intensity':float(intensity.max()/engine.reference_peak),
             'core_efficiency':float(np.median(core_power/sim.setup.power_w)),
             'sidelobe_fraction':float(np.median(1-core_power/powers)),
             'peak_excursion_m':float(np.linalg.norm(peak_path-peak_path[0],axis=1).max()),
             'centroid_excursion_m':float(np.linalg.norm(centroid-centroid[0],axis=1).max()),
             'peak_bending_m':float(np.linalg.norm(peak_path-line,axis=1).max()),
             'intensity_overlap':overlap,
             'valley_filling':float(np.median([r['valley'] for r in eligible])) if eligible else None,
             'ridge_separation_m':float(np.median([r['separation_m'] for r in eligible])) if eligible else None,
             'focal_z_m':float(sim.z_m[int(np.argmax(flat.max(axis=1)))]),
             'minimum_output_power_w':float(powers.min()),
             'maximum_edge_fraction':float(np.max(intensity[:,mask].sum(axis=1)*sim.dx**2/powers)),
             'qualifying_ridge_planes':len(eligible)}
    return metrics,ridge,np.asarray(profiles)


def compare(arms,batch):
    a,b=COMPARISONS[batch.comparison]
    if a not in arms or b not in arms:
        return {'testable':False,'effect':None,'prediction_supported':False,
                'reason':'Requested arm has zero coherent power; equal-power normalization is undefined.'}
    ma,mb=arms[a]['metrics'],arms[b]['metrics']
    va,vb=ma[batch.observable],mb[batch.observable]
    # Eligibility is fixed using the single reference, not selected independently
    # after looking at the favorable coherent image.
    if batch.observable in ('valley_filling','ridge_separation_m'):
        eligible=[i for i,r in enumerate(arms['single']['ridge']) if r['eligible']]
        if not eligible or any(not arms[arm]['ridge'][i]['eligible'] for arm in (a,b) for i in eligible):
            return {'testable':False,'effect':None,'prediction_supported':False,'reason':'No matched qualifying ridge pair; do not discard missing comparison planes.'}
        key='valley' if batch.observable=='valley_filling' else 'separation_m'
        va=float(np.median([arms[a]['ridge'][i][key] for i in eligible]));vb=float(np.median([arms[b]['ridge'][i][key] for i in eligible]))
    if va is None or vb is None or (batch.effect!='difference' and abs(vb)<1e-12):
        return {'testable':False,'effect':None,'prediction_supported':False,'reason':'Unidentified reference value; ratio is not defined.'}
    effect=float(va-vb) if batch.effect=='difference' else float(va/vb if batch.effect=='ratio' else (va-vb)/abs(vb))
    supported=effect>=batch.threshold if batch.direction=='>=' else effect<=batch.threshold
    separation_change=None
    if batch.max_separation_change is not None:
        da,db=ma['ridge_separation_m'],mb['ridge_separation_m']
        if da is None or db is None or db<=0:supported=False
        else:
            separation_change=float(abs(da/db-1));supported=bool(supported and separation_change<=batch.max_separation_change)
    return {'testable':True,'effect':effect,'prediction_supported':bool(supported),
            'separation_relative_change':separation_change,'comparison_values':[va,vb]}


class ResearchExperiment:
    def __init__(self,batch,*,n=192,backend='numpy',gpu_memory_mb=512,wavelength=633e-9,extent=2.4e-3,aperture=.9e-3):
        from ..physics import OpticalSetup
        self.batch=batch
        setup=OpticalSetup(n=n,wavelength_m=wavelength,extent_m=extent)
        self.engine=ExperimentEngine(setup,np.linspace(batch.z_start_m,batch.z_end_m,int(batch.z_planes)),
                                     backend=backend,gpu_memory_mb=gpu_memory_mb,aperture_m=aperture)

    def evaluate(self,h,*,save=None,field_override=None,quantize=False,phase_wavelength_ratio=1.,propagator='asm'):
        if propagator not in ('asm','fresnel'):raise ValueError('Unsupported trusted propagator')
        e=self.engine;sim=e.sim;batch=self.batch
        pre,field=e.input(h)
        if phase_wavelength_ratio!=1.:
            pre=abs(pre)*np.exp(1j*np.angle(pre)*phase_wavelength_ratio);field=e.with_lens(pre,h)
        if quantize:
            pre=abs(pre)*np.exp(1j*np.round(np.angle(pre)/(2*np.pi)*8)/8*2*np.pi);field=e.with_lens(pre,h)
        if field_override is not None:field=np.asarray(field_override)
        rotated=normalize(rotate_field(field,h.composition.angle_rad),sim.dx,sim.setup.power_w)
        pair=field+h.composition.weight*np.exp(1j*h.composition.phase_rad)*rotated
        pair_power=float((abs(pair)**2).sum()*sim.dx**2)
        coherent=normalize(pair,sim.dx,sim.setup.power_w) if pair_power>=sim.setup.power_w*1e-12 else None
        base=e.input(replace(h,transformations=()))[1]
        rng=np.random.default_rng(h.environment.seed+17)
        perturbed=field*np.exp(1j*batch.phase_noise_rms*rng.normal(size=field.shape))
        inputs={'single':field,'rotated':rotated}
        if coherent is not None:inputs['coherent']=coherent
        inputs.update(base=base,perturbed=perturbed)
        arms={};reference=None;profiles={};focal={};retentions=[]
        input_power=[];single_intensity=None;rotated_intensity=None
        for name,f in inputs.items():
            spec=sim.fft2(f);retentions.append(float(sim.input_spectral_retention(spec).min()))
            input_power.append(float((abs(f)**2).sum()*sim.dx**2))
            intensities=np.asarray([abs(sim.field(spec,j))**2 if propagator=='asm' else
                                    abs(fresnel_direct(f,sim,float(z)))**2 for j,z in enumerate(sim.z_m)])
            if name=='single':reference=intensities;single_intensity=intensities
            if name=='rotated':rotated_intensity=intensities
            metrics,ridge,profile=summarize(intensities,e,batch,reference)
            arms[name]={'metrics':metrics,'ridge':ridge};profiles[name]=profile
            focal[name]=intensities[int(np.argmax(intensities.reshape(len(intensities),-1).max(axis=1)))]
        incoherent=(single_intensity+h.composition.weight**2*rotated_intensity)/(1+h.composition.weight**2)
        metrics,ridge,profile=summarize(incoherent,e,batch,reference)
        arms['incoherent']={'metrics':metrics,'ridge':ridge};profiles['incoherent']=profile
        result=compare(arms,batch)
        checks={'finite':True,'equal_power':bool(max(abs(p/sim.setup.power_w-1) for p in input_power)<1e-9),
                'sampling_retention':min(retentions)>=.995,
                'window_edges':max(a['metrics']['maximum_edge_fraction'] for a in arms.values())<=.01}
        if h.beam.family in ('pearcey','butterfly'):
            refined=e.input(h,points=384)[1]
            overlap=abs(np.vdot(field,refined))/np.linalg.norm(field)/np.linalg.norm(refined)
            checks['integral_convergence']=bool(overlap>=.9999)
        record={'hypothesis':h.record(),'arms':arms,'comparison':result,'checks':checks,
                'minimum_retention':min(retentions),'input_powers_w':input_power,
                'stage':'exploration','simulation_only':True,'novelty_verified':False,
                'executed_setup':{'optical_setup':asdict(sim.setup),'z_m':sim.z_m.tolist(),
                                  'lens_applied':h.environment.kind!='free_space','propagator':propagator,
                                  'composition':asdict(h.composition)},
                'coherent_cancellation':coherent is None}
        overlap=float(abs(np.vdot(field,coherent))/np.linalg.norm(field)/np.linalg.norm(coherent)) if coherent is not None else None
        record['equivalence']={'single_coherent_field_overlap':min(overlap,1.) if overlap is not None else None,
                               'known_identity':bool(overlap is not None and overlap>=1-1e-8),
                               'scope':'This sampled input and global phase only; not a broad prior-art equivalence proof.'}
        if save is not None:
            np.savez_compressed(save,x_m=sim.x[0],z_m=sim.z_m,
                                **{name+'_profile':v for name,v in profiles.items()},
                                **{name+'_focal':v for name,v in focal.items()})
        return record
