"""Deterministic duplicate detection for preregistered PGCD experiments.

Candidate IDs, prose, and random seeds do not make an unchanged optical setup a
new experiment. The model may revisit a direction when its physical design or
registered measurement changes.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


_MEASUREMENT_FIELDS = (
    'observable', 'comparison', 'z_start_m', 'z_end_m', 'z_planes',
    'core_radius_m', 'marginal_half_width_m', 'ridge_prominence',
    'phase_noise_rms', 'max_separation_change',
)


def _stable(value):
    if isinstance(value, float):
        return format(value, '.10g')
    if isinstance(value, dict):
        return {str(k): _stable(v) for k, v in sorted(value.items()) if k != 'seed'}
    if isinstance(value, (list, tuple)):
        return [_stable(v) for v in value]
    return value


def candidate_record(batch: dict, hypothesis: dict) -> dict:
    """Return an ID/prose/seed-independent record of the tested design."""
    env = hypothesis.get('environment', {})
    design = {
        'measurement': {key: batch.get(key) for key in _MEASUREMENT_FIELDS},
        'beam': hypothesis.get('beam'),
        'transformations': hypothesis.get('transformations', []),
        'environment': {'kind': env.get('kind'), 'phase_rms': env.get('phase_rms')},
        'composition': hypothesis.get('composition', {}),
    }
    canonical = json.dumps(_stable(design), sort_keys=True, separators=(',', ':'))
    signature = hashlib.sha256(canonical.encode('utf-8')).hexdigest()
    return {
        'signature': signature,
        'hypothesis_id': hypothesis.get('id'),
        'question': batch.get('question', ''),
        'observable': batch.get('observable'),
        'comparison': batch.get('comparison'),
        'beam': _stable(hypothesis.get('beam', {})),
        'transformations': _stable(hypothesis.get('transformations', [])),
        'environment': _stable({'kind': env.get('kind'), 'phase_rms': env.get('phase_rms')}),
        'composition': _stable(hypothesis.get('composition', {})),
        'measurement': _stable({key: batch.get(key) for key in _MEASUREMENT_FIELDS}),
    }


def load_design_registry(run_dir: Path | None) -> list[dict]:
    """Read preregistered candidate designs from a previous run's ancestry."""
    if run_dir is None:
        return []
    roots = []
    pending = [Path(run_dir)]
    visited = set()
    while pending:
        root = pending.pop()
        key = str(root.resolve())
        if key in visited or not root.is_dir():
            continue
        visited.add(key)
        roots.append(root)
        state_path = root / 'loop_state.json'
        if state_path.is_file():
            try:
                parent = json.loads(state_path.read_text(encoding='utf-8')).get('prior_run')
                if parent:
                    pending.append(Path(parent))
            except (OSError, ValueError, TypeError):
                pass
    rows = []
    seen = set()
    for root in roots:
        for path in sorted(root.glob('cycle_*/frozen_protocol.json')):
            try:
                batch = json.loads(path.read_text(encoding='utf-8'))
                for hypothesis in batch.get('cases', []):
                    row = candidate_record(batch, hypothesis)
                    if row['signature'] in seen:
                        continue
                    seen.add(row['signature'])
                    row['source'] = str(path.parent.name)
                    rows.append(row)
            except (OSError, ValueError, TypeError):
                # Preserve usable history even when an unrelated partial artifact
                # is malformed; the original file remains available for audit.
                continue
    return rows


def find_duplicates(batch: dict, registry: list[dict]) -> list[dict]:
    """Find repeated physical designs within this batch or prior experiments."""
    first_seen = {row['signature']: row for row in registry}
    duplicates = []
    for hypothesis in batch.get('cases', []):
        row = candidate_record(batch, hypothesis)
        previous = first_seen.get(row['signature'])
        if previous is not None:
            duplicates.append({
                'hypothesis_id': row['hypothesis_id'],
                'duplicate_of': previous.get('hypothesis_id'),
                'source': previous.get('source', 'same proposed batch'),
                'signature': row['signature'],
            })
        else:
            first_seen[row['signature']] = {**row, 'source': 'same proposed batch'}
    return duplicates


def prompt_history(registry: list[dict], limit: int = 40) -> list[dict]:
    """Compact, readable recent design history for the model's next decision."""
    unique = {}
    for row in registry:
        unique.setdefault(row['signature'], row)
    return list(unique.values())[-limit:]
