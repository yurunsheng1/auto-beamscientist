"""Constrained structural evolution; performance is never a novelty score."""
from __future__ import annotations
from dataclasses import replace
import numpy as np
from .schemas import Hypothesis, Transformation, Environment

FAMILIES=('gaussian','airy','pearcey','butterfly','vortex')


class ResearchEvolutionAgent:
    def select(self,nodes,index):
        eligible=[n for n in nodes if (n.get('evidence') or {}).get('checks') and n.get('state') in ('criticized','candidate')]
        if not eligible:return None
        # Alternate exploitation and underrepresented descriptor cells. Failed
        # predictions remain eligible for structural repair, never discovery acceptance.
        ranked=sorted(eligible,key=lambda n:(n['selection_score'],n['id']),reverse=True)
        if index%3==0:
            counts={}
            for n in eligible:counts[tuple(n['descriptor'])]=counts.get(tuple(n['descriptor']),0)+1
            return min(eligible,key=lambda n:(counts[tuple(n['descriptor'])],n['id']))
        return ranked[(index//3)%min(3,len(ranked))]

    @staticmethod
    def score(metrics,diagnostics,valid,evaluation_cost):
        robustness=diagnostics.get('phase_noise_ratio',0.)
        generality=diagnostics.get('holdout_ratio',0.)
        return float(metrics['axial_floor']+.05*min(robustness,1)+.05*min(generality,1)
                     +.05*valid-.0001*evaluation_cost)


class CompositionAgent:
    def __init__(self,knowledge,seed=7):self.knowledge=knowledge;self.seed=seed

    def propose(self,index,nodes):
        rng=np.random.default_rng(self.seed+index*997)
        parent=ResearchEvolutionAgent().select(nodes,index) if index>=5 else None
        family=FAMILIES[index%5]
        transforms=()
        environment=Environment()
        mechanism='Known family diffraction provides a reference, not a new beam claim.'
        if parent:
            previous=Hypothesis.from_dict(parent['hypothesis'])
            # Every expansion changes a discrete optical structure; continuous
            # fitting happens separately under an equal trial budget.
            if index%3==0:
                family=family if family!=previous.beam.family else FAMILIES[(index+1)%5]
                transforms=previous.transformations[:2]
                mechanism='Changing the canonical input redistributes the stationary-phase contributions; test independently of the parent input.'
            elif index%3==1:
                family=previous.beam.family
                kind=('quartic','ripple','coherent_pair','stretch','vortex')[index%5]
                amount=float(rng.uniform(-.5,.5))
                if kind=='stretch':amount=float(rng.uniform(.8,1.2))
                if kind=='vortex':amount=int(rng.choice([-1,1]))
                transforms=(previous.transformations+(Transformation(kind,amount),))[-3:]
                mechanism='The added transformation may redistribute axial interference; removal of that transformation is the discriminating ablation.'
            else:
                family=previous.beam.family;transforms=previous.transformations[:2]
                environment=Environment(kind='free_space' if previous.environment.kind!='free_space' else 'thin_lens')
                mechanism='Removing or introducing the lens changes curvature-driven focusing; compare at a fixed observation window without retuning the window.'
        beam=self.knowledge.beam(family)
        if family=='airy' and index>=5:beam=replace(beam,apodization=float(rng.uniform(.08,.2)))
        return Hypothesis(f'H{index+1:03d}',beam,transforms,environment,
                          'At equal input power, aperture and per-arm fitting budget, the minimum on-axis intensity in 49–71 mm exceeds the strongest optimized classical control by at least 3%, and survives numerical/robustness gates.',
                          mechanism,parent_id=parent['id'] if parent else None)


class PhenomenonDiscoveryAgent:
    @staticmethod
    def descriptor(metrics):
        return (min(3,max(0,int((metrics['focal_z_m']-.049)/.022*4))),
                min(3,max(0,int(metrics['sidelobe_energy_fraction']*4))))

    @staticmethod
    def explain(h,metrics,ablations):
        return {'status':'proposed_explanation_not_established',
                'mechanism':h.mechanism,
                'observation':{'trajectory_peak_excursion_m':metrics['trajectory_excursion_m'],
                               'core_efficiency':metrics['core_efficiency']},
                'discriminating_tests':['remove each transformation with fitted chirp frozen',
                                        'independent Fresnel quadrature','mesh/window/z-grid refinement'],
                'ablation_effects':ablations}
