"""Attempt to disprove predictions with independent and held-out checks."""
from __future__ import annotations
from dataclasses import replace
import numpy as np
from .schemas import Evidence, Review
from .physics import fresnel_direct
from .beams import rotate_field


EXPLORATION_CHECKS=('finite','equal_power','sampling_retention','window_edges')


def classify_evidence(evidence,*,prediction_supported,robustness_supported,equivalent_to=None):
    """Route continued research separately from permission to claim a discovery.

    Missing/failed confirmation stays explicit; it is never upgraded to validated
    evidence. Zero performance gain does not discard a trustworthy exploration.
    """
    checks=evidence.checks
    basic=all(checks.get(name,False) for name in EXPLORATION_CHECKS)
    if 'integral_convergence' in checks:basic=basic and checks['integral_convergence']
    reasons=[f'Exploration physics gate failed: {name}' for name in EXPLORATION_CHECKS if not checks.get(name,False)]
    if checks.get('integral_convergence') is False:reasons.append('Canonical-integral quadrature has not converged.')
    pending=[name for name,value in checks.items() if not value and name not in EXPLORATION_CHECKS]
    if pending:reasons.append('Numerical confirmation still required: '+', '.join(pending))
    if not basic:decision='rejected'
    elif equivalent_to:
        decision='known_control';reasons.append('Known field/control identity: '+equivalent_to)
    elif evidence.numerical_valid and prediction_supported and robustness_supported:decision='numerical_candidate'
    else:decision='exploratory'
    if not prediction_supported:reasons.append('This prediction is unsupported; retain the negative result and allow revised structural hypotheses.')
    if not robustness_supported:reasons.append('Robustness is unconfirmed; this does not discard the exploratory branch.')
    reasons.append('NOVELTY_NOT_VERIFIED: numerical evidence alone does not establish a discovery.')
    return Review(evidence.hypothesis_id,evidence.numerical_valid,prediction_supported,equivalent_to,reasons,decision,
                  stage='candidate_confirmation' if decision=='numerical_candidate' else 'exploration')


class ScientificCritic:
    def __init__(self,engine,journal,knowledge):
        self.engine=engine;self.journal=journal;self.knowledge=knowledge
        self.variants={}

    def variant(self,key,**kwargs):
        if key not in self.variants:self.variants[key]=self.engine.variant(**kwargs)
        return self.variants[key]

    def review(self,h,chirp,metrics,baseline,known_fields):
        e=self.engine;sim=e.sim
        pre,field=e.input(h,chirp)
        run=lambda key,fn:self.journal.run(h.id+'/'+key,fn)
        j=metrics['axial_floor'];scale=max(j,1e-10)
        checks={'optimized_controls_validated':baseline['controls_validated'],
                'finite':bool(all(np.isfinite(v) for v in metrics.values())),
                'equal_power':abs(metrics['input_power_w']/sim.setup.power_w-1)<1e-10,
                'sampling_retention':metrics['retention']>=.995,
                'window_edges':metrics['edge_fraction']<=.01}
        diagnostics={};ablations=[]
        # Normalize errors to the fixed Gaussian peak, rather than dividing by
        # an almost-dark vortex-axis measurement.
        def direct_check():
            indices=[0,len(sim.z_m)//2,len(sim.z_m)-1]
            asm=e.trace(field)/e.reference_peak
            direct=[float(abs(fresnel_direct(field,sim,float(sim.z_m[i]),np.array([0.]))[0,0])**2/e.reference_peak) for i in indices]
            error=float(np.max(abs(asm[indices]-direct)))
            return {'normalized_intensity_max_absolute_error':error,'asm':asm[indices].tolist(),'direct':direct}
        diagnostics['independent_fresnel']=run('independent_fresnel',direct_check)
        checks['independent_fresnel']=diagnostics['independent_fresnel']['normalized_intensity_max_absolute_error']<=.02
        # Frozen optical designs, never reoptimized on a validation grid.
        mesh_n=2*sim.setup.n
        expanded_n=int(np.ceil(1.25*sim.setup.n/2))*2
        variants=[('mesh',self.variant('mesh',n=mesh_n)),
                  ('window',self.variant('window',n=expanded_n,extent=sim.setup.extent_m*expanded_n/sim.setup.n)),
                  ('z_grid',self.variant('z_grid',z_m=np.linspace(sim.z_m[0],sim.z_m[-1],2*len(sim.z_m)-1)))]
        for label,v in variants:
            row=run(label,lambda v=v:v.quick(v.input(h,chirp)[1]))
            # Absolute normalization avoids meaningless relative error for a
            # field with identically zero on-axis amplitude.
            error=abs(row['axial_floor']-j)
            diagnostics[label]={'axial_floor':row['axial_floor'],'absolute_error':error}
            checks[label+'_convergence']=error<=max(.005,.05*scale)
        def quadrature_check():
            refined=e.input(h,chirp,points=384)[0]
            overlap=abs(np.vdot(pre,refined))/np.sqrt(np.vdot(pre,pre).real*np.vdot(refined,refined).real)
            return {'field_overlap':float(min(overlap,1.))}
        if h.beam.family in ('pearcey','butterfly'):
            diagnostics['quadrature']=run('quadrature',quadrature_check)
            checks['integral_convergence']=diagnostics['quadrature']['field_overlap']>=.9999
        # Phase quantization applies to the composed pre-lens field; the ideal
        # physical lens is kept continuous. Amplitude is not quantized.
        def quantized():
            phase=np.angle(pre)
            q=np.round(phase/(2*np.pi)*256)/256*2*np.pi
            return e.quick(e.with_lens(abs(pre)*np.exp(1j*q),h))
        quant=run('quantization_8bit',quantized)
        diagnostics['quantization_ratio']=float(quant['axial_floor']/scale) if j>1e-10 else 0.
        noise=[]
        for seed in (107,109,113):
            def perturbed(seed=seed):
                rng=np.random.default_rng(seed)
                return e.quick(e.with_lens(pre*np.exp(.02j*rng.normal(size=pre.shape)),h))
            noise.append(run(f'phase_noise_{seed}',perturbed)['axial_floor'])
        diagnostics['phase_noise_ratio']=float(min(noise)/scale) if j>1e-10 else 0.
        # Wavelength hold-out: fixed complex amplitude and residual optical path;
        # only the ideal physical lens is recomputed at the new wavelength.
        hold=self.variant('holdout',wavelength=780e-9)
        def held_out():
            frozen=abs(pre)*np.exp(1j*np.angle(pre)*sim.setup.wavelength_m/hold.sim.setup.wavelength_m)
            result=hold.quick(hold.with_lens(frozen,h))
            control=baseline['field_factory'](hold)
            result['control_floor']=hold.quick(control)['axial_floor']
            return result
        held=run('holdout_780nm',held_out)
        diagnostics['holdout']=held
        diagnostics['holdout_ratio']=float(held['axial_floor']/max(held['control_floor'],1e-10))
        diagnostics['holdout_phase_convention']='Wrapped pre-lens residual phase realized as principal-branch optical path, amplitude frozen; lens recomputed; no reoptimization.'
        # Individual ablations and local finite-difference sensitivity are
        # diagnostic, not extra optimization attempts.
        for i,t in enumerate(h.transformations):
            ablated=replace(h,transformations=h.transformations[:i]+h.transformations[i+1:])
            row=run(f'ablation_{i}',lambda ablated=ablated:e.quick(e.input(ablated,chirp)[1]))
            ablations.append({'removed':t.kind,'amount':t.amount,'floor':row['axial_floor'],
                              'full_minus_ablated':j-row['axial_floor']})
        sensitivity=[]
        for delta in (-.03,.03):
            shifted=float(np.clip(chirp+delta,-1.2,1.2))
            row=run(f'sensitivity_{delta}',lambda shifted=shifted:e.quick(e.input(h,shifted)[1]))
            sensitivity.append({'chirp':shifted,'floor':row['axial_floor']})
        diagnostics['sensitivity']=sensitivity
        diagnostics['ablations']=ablations
        equivalent=None;overlaps={}
        for name,other in known_fields.items():
            # Global phase and quarter-turn equivalence only. This is not a
            # complete proof of mathematical non-equivalence.
            overlap=max(abs(np.vdot(field,rotate_field(other,k*np.pi/2)))/np.sqrt(np.vdot(field,field).real*np.vdot(other,other).real) for k in range(4))
            overlaps[name]=float(min(overlap,1.))
            if overlap>=1-1e-8:equivalent=name
        diagnostics['equivalence_overlaps']=overlaps
        diagnostics['equivalence_scope']='Global phase and quarter-turns on this sampled input only; broader analytical/literature equivalence remains unverified.'
        gaussian_input=h.beam.family=='gaussian' or (h.beam.family=='vortex' and h.beam.charge==0)
        if gaussian_input and h.environment.kind=='thin_lens' and all(t.kind in ('chirp','quartic','ripple') for t in h.transformations):
            equivalent='known Gaussian polynomial/ripple phase control family (analytic identity)'
        evidence=Evidence(h.id,checks,diagnostics,self.knowledge.citations(h.beam.family))
        improved=j>=baseline['axial_floor']*(1+h.minimum_gain)
        robust=(diagnostics['quantization_ratio']>=.9 and diagnostics['phase_noise_ratio']>=.9
                and diagnostics['holdout_ratio']>=1+h.minimum_gain)
        review=classify_evidence(evidence,prediction_supported=bool(improved),
                                 robustness_supported=bool(robust),equivalent_to=equivalent)
        return evidence,review
