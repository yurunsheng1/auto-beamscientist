"""Evidence-only numerical report; failed validation is never plotted as a finding."""
from __future__ import annotations
import json
import numpy as np


def report(out,nodes,baselines,state,knowledge):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    valid=[n for n in nodes if n.get('review') and n['review']['numerical_valid']]
    invalid=[n for n in nodes if n not in valid]
    rows=[]
    for n in valid:
        experiment=json.loads((out/'artifacts'/f"{n['id']}.json").read_text())
        rows.append({'id':n['id'],'family':n['hypothesis']['beam']['family'],
                     'metrics':experiment['metrics'],'decision':n['review']['decision'],
                     'prediction_supported':n['review']['prediction_supported']})
    (out/'validated_evidence.json').write_text(json.dumps(rows,indent=2))
    lines=['# PGCD numerical research report','',
           'SIMULATION_ONLY · NOVELTY_NOT_VERIFIED · NOT_PUBLICATION_READY','',
           f"Run status: {state['status']}. {len(nodes)} hypotheses recorded; {len(valid)} passed all numerical accuracy gates; {len(invalid)} failed or have incomplete validation.",
           'No publication-reproduction stage was run. This direct-research protocol was requested by the user.',
           'No research discovery is accepted without verified technical prior-art analysis and human review.','',
           '## Fixed research question and controls','',
           'Can a constrained beam composition improve minimum on-axis intensity in 49–71 mm by at least 3%, at equal aperture, input power, grid and per-arm fitting budget?',
           'The fixed axial objective can reject useful off-axis beams; that is a limitation of this research question, not a claim that those beam families lack value.','',
           '| Control | Fitted axial floor | Search attempts | Numerical validation |','|---|---:|---:|---|']
    for name,b in baselines.items():lines.append(f"| {name} | {b['axial_floor']:.6g} | {b['attempts']} | {b.get('validation',{}).get('validated','incomplete')} |")
    lines+=['','## Validated numerical observations','',
            '| Hypothesis | Family | Axial floor | Core efficiency | Prediction supported | Decision |',
            '|---|---|---:|---:|---|---|']
    for row in rows:
        m=row['metrics'];lines.append(f"| {row['id']} | {row['family']} | {m['axial_floor']:.6g} | {m['core_efficiency']:.6g} | {row['prediction_supported']} | {row['decision']} |")
    if not rows:lines.append('No hypothesis passed every numerical gate. No candidate pattern is presented as validated evidence.')
    lines+=['','## Rejected and incomplete directions','']
    for n in nodes:
        r=n.get('review')
        if r:lines.append(f"- {n['id']} ({n['hypothesis']['beam']['family']}): "+' '.join(r['reasons']))
        else:lines.append(f"- {n['id']}: {n['state']}; see errors and event ledger. No validated result.")
    lines+=['','## Methods and reproducibility','',
            'Beam equations and attributed sources are in knowledge.json. All inputs are finite-aperture and normalized to the configured power. Scalar ASM uses the existing conservative radial anti-alias cutoff. An independent real-space Fresnel quadrature checks three on-axis planes in the paraxial regime. Mesh, window and z-grid refinements use frozen optical designs. Catastrophe integrals have a separate quadrature refinement check.',
            'Core efficiency is the power fraction within 110 micrometres of the global intensity peak in the brightest sampled plane; sidelobe energy is its complement, not a canonical lobe decomposition. Trajectory tracks the brightest pixel, not a centroid. Aperture radius is 0.9 mm. Only the declared primary metric selects candidates.',
            'Fitting varies a bounded quadratic chirp for each composition. Classical controls additionally include optimized defocus, quadratic-plus-quartic and a four-parameter polynomial/ripple phase arm. Each arm has the same fitting trial allowance; the total structural search is not claimed to have the same cost as one control arm.',
            '8-bit phase quantization, 0.02-rad independent pixel phase noise (three seeds), individual transform removal, local chirp sensitivity and a 780-nm wavelength hold-out are recorded for every completed hypothesis. These are limited numerical stress tests, not laboratory validation.',
            'Raw trials, including errors and rejected outcomes, are in evaluations.jsonl. research.sqlite contains transactional lineage, stage events and the quality-diversity archive. source_snapshot and environment.json identify code, packages and hardware. Resume requires an unchanged frozen protocol. Counts refer to objective/validation invocations, not individual FFTs.',
            'Global-phase/quarter-turn field comparisons are only a limited equivalence screen. Known-family provenance is not a novelty assessment. No arbitrary generated code, executable plugin or model-written solver is run. Proposal mode: '+state['proposal_mode']+'. The critic and numerical gates are deterministic; this is not a full autonomous literature reviewer.','',
            '## Verified sources','']
    for doi,source in knowledge.data['sources'].items():
        lines.append(f"- [{source['title']}]({source['url']}) (DOI {doi}). {source['verification']}")
    (out/'research_report.md').write_text('\n'.join(lines)+'\n')
    if rows:
        fig,ax=plt.subplots(figsize=(8,4))
        ax.bar([r['id'] for r in rows],[r['metrics']['axial_floor'] for r in rows])
        ax.axhline(max(b['axial_floor'] for b in baselines.values()),color='black',ls='--',label='Strongest fitted control')
        ax.set(ylabel='Fixed normalized axial floor',title='Only hypotheses passing all numerical accuracy gates')
        ax.legend();fig.tight_layout();fig.savefig(out/'validated_comparison.png',dpi=150);plt.close(fig)
        for row in rows:
            with np.load(out/'artifacts'/f"{row['id']}.npz") as data:
                fig,axes=plt.subplots(1,2,figsize=(9,3.5))
                axes[0].plot(data['z_m']*1e3,data['on_axis']);axes[0].set(xlabel='z (mm)',ylabel='Normalized on-axis intensity')
                axes[1].imshow(data['focal_intensity'],origin='lower');axes[1].set_title(row['id']+' validated numerical field')
                fig.tight_layout();fig.savefig(out/'artifacts'/f"{row['id']}_validated.png",dpi=120);plt.close(fig)
    return {'numerically_validated':len(valid),'rejected_or_incomplete':len(invalid),
            'numerical_candidates':sum((n.get('review') or {}).get('decision')=='numerical_candidate' for n in nodes),
            'accepted_discoveries':0}
