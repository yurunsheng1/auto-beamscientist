"""Reproducible Matplotlib renderers for reviewed numerical mechanism tests."""
from pathlib import Path
import json
import numpy as np

def render(out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out=Path(out);data=json.loads((out/'numerical/results.json').read_text());raw=out/'numerical'
    plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':190})
    gradients=data.get('gradient_controls')
    if gradients is None and (out/'gradient_control.json').exists():gradients=json.loads((out/'gradient_control.json').read_text())
    colors=['#247BA0','#D66B24','#596A45'];manifest={}
    def save(fig,paper,name,caption):
        dest=out/f'paper_{paper:02d}';dest.mkdir(exist_ok=True)
        for ext in ['png','pdf']:fig.savefig(dest/(name+'.'+ext),bbox_inches='tight')
        plt.close(fig);manifest.setdefault(str(paper),[]).append({'file':name+'.pdf','caption':caption})
    fig,axs=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
    for i,r in enumerate(data['parity']):
        even=r['even_throughput'];axs[0].bar(i,even,color=colors[i]);axs[0].bar(i,1-even,bottom=even,color=colors[i],alpha=.25)
        axs[0].text(i,even/2,f'{even:.1%}',ha='center',va='center',color='white')
        for arm,ls in zip([r['arms'][0],r['arms'][1]],['--','-']):
            with np.load(raw/(arm['label']+'.npz')) as a:axs[1].plot(a['z_m']*1e3,100*np.array(arm['core']),ls,color=colors[i],label=r['family']+' / '+('single' if ls=='--' else 'even'))
    axs[0].set(xticks=range(3),xticklabels=['Gaussian','Pearcey','Butterfly'],ylabel='Fraction of incident power',ylim=(0,1),title='Even port throughput; pale = odd port')
    axs[1].set(xlabel='z (mm)',ylabel='Core power / normalized output (%)',title='Identical frozen phase in both arms');axs[1].legend(fontsize=7,ncol=2,frameon=False)
    save(fig,1,'parity_budget','Power accounting for even and odd rotational components, followed by same-phase single and unit-power even-port core curves. A normalized concentration increase does not imply lossless collection of all incident power. Common core radius 35 micrometres, N=768; shaded bar portions are the odd-port power.')
    fig,axs=plt.subplots(2,3,figsize=(9,5.7),layout='constrained')
    for row,family in enumerate(['pearcey','butterfly']):
        for ax,name in zip(axs[row],['single','even','odd']):
            with np.load(raw/f'parity_{family}_{name}.npz') as a:
                image=abs(a['input_field'])**2;x=a['x_m']*1e3
                im=ax.pcolormesh(x,x,image/image.max(),cmap='magma',shading='nearest',rasterized=True,vmin=0,vmax=1)
                ax.set(xlim=(-.55,.55),ylim=(-.55,.55),aspect='equal',xlabel='x (mm)',ylabel='y (mm)',title=family+' / '+name)
    fig.colorbar(im,ax=list(axs.flat),label='Intensity / individual maximum')
    save(fig,1,'parity_fields','Source-plane intensities of the frozen single fields and their normalized even/odd components. Each panel is normalized to its own maximum for morphology; the preceding throughput plot supplies the physically relevant powers. These are numerical scalar fields.')
    fig,axs=plt.subplots(1,3,figsize=(11,3.4),layout='constrained')
    for ax,family in zip(axs,['gaussian','pearcey','butterfly']):
        r=next(r for r in data['quartic'] if r['family']==family and r['a4']==.7)
        for arm,ls in [('baseline','--'),('quartic','-'),('quadratic',':')]:
            rec=r[arm]
            with np.load(raw/(rec['label']+'.npz')) as a:ax.plot(a['z_m']*1e3,np.array(rec['core'])*100,ls,label=arm)
        if gradients:
            g=next(v for v in gradients['primary'] if v['family']==family and v['a4']==.7)
            ax.plot(np.linspace(20,80,len(g['measurement']['core'])),100*np.array(g['measurement']['core']),'-.',label='gradient-matched')
        ax.set(xlabel='z (mm)',ylabel='Core power (%)',title=family.capitalize());ax.legend(frameon=False,fontsize=8)
    save(fig,2,'quartic_curves','Free-space core curves for the unmodified field, quartic phase a4=0.7, and mean-phase-matched quadratic and least-squares phase-gradient-matched quadratic phases. All arms use 1 W input, a 0.9 mm aperture, N=384 and a 50 micrometre collection radius; no ideal lens is applied.')
    fig,axs=plt.subplots(1,2,figsize=(9,3.7),layout='constrained')
    for color,family in zip(colors,['gaussian','pearcey','butterfly']):
        rs=[r for r in data['quartic'] if r['family']==family];a=[r['a4'] for r in rs]
        axs[0].plot(a,[100*(r['quartic']['median']/r['baseline']['median']-1) for r in rs],'o-',color=color,label=family+' quartic')
        axs[0].plot(a,[100*(r['quadratic']['median']/r['baseline']['median']-1) for r in rs],'s--',color=color,label=family+' quadratic')
        axs[1].plot(a,[r['residual_ratio'] for r in rs],'o-',color=color,label=family)
    axs[0].set(xlabel='Quartic coefficient a4 (rad)',ylabel='Change of median core energy (%)');axs[0].legend(frameon=False,fontsize=7)
    axs[1].set(xlabel='Quartic coefficient a4 (rad)',ylabel='|quartic − quadratic| / |quadratic − baseline|');axs[1].axhline(.15,color='gray',ls=':',label='Original Gaussian anchor');axs[1].legend(frameon=False,fontsize=8)
    save(fig,2,'quartic_equivalence','Moment-matched quadratic comparison at three fixed quartic coefficients. The right panel measures residual relative to the quadratic response, rather than declaring two visually similar patterns equivalent. The 15% line is the original Gaussian equivalence anchor; it is not a universal acceptance threshold for every family.')
    fig,axs=plt.subplots(1,2,figsize=(9,3.7),layout='constrained')
    for color,waist in zip(colors,[180e-6,300e-6]):
        rs=[r for r in data['vortex'] if abs(r['waist_m']-waist)<1e-12];charge=[r['charge'] for r in rs]
        axs[0].plot(charge,[100*r['measurement']['median'] for r in rs],'o',color=color,label=f'ASM, w={waist*1e6:.0f} µm')
        axs[0].plot(charge,[100*r['analytic_median'] for r in rs],'-',color=color,label='LG analytic')
        axs[1].plot(charge,[r['ring_at_f_m']*1e6 for r in rs],'o-',color=color,label=f'w={waist*1e6:.0f} µm')
    axs[0].set(xlabel='Absolute topological charge |l|',ylabel='Median core energy (%)',title='True waist change; fixed z window');axs[0].legend(frameon=False,fontsize=8)
    axs[1].axhline(50,color='gray',ls='--',label='Collection radius');axs[1].set(xlabel='Absolute topological charge |l|',ylabel='Analytic ring radius at z=f (µm)',title='Square-root scaling');axs[1].legend(frameon=False,fontsize=8)
    save(fig,3,'vortex_scaling','Actual 180 and 300 micrometre waist scans, charges 0 to 6. Symbols show area-weighted ASM core energy and lines the paraxial p=0 LG incomplete-gamma prediction over the same axial planes. The right panel is an analytical ring-radius prediction, not an independently measured ring fit. Collection radius is 50 micrometres.')
    fig,axs=plt.subplots(2,3,figsize=(9,5.8),layout='constrained')
    for col,charge in enumerate([1,3,6]):
        with np.load(raw/f'vortex_300_{charge}.npz') as a:
            x=a['x_m']*1e6;image=a['focal'];phase=np.ma.masked_where(image<image.max()*.01,a['phase'])
            axs[0,col].pcolormesh(x,x,image/image.max(),cmap='magma',shading='nearest',rasterized=True,vmin=0,vmax=1)
            im=axs[1,col].pcolormesh(x,x,phase,cmap='twilight',shading='nearest',rasterized=True,vmin=-np.pi,vmax=np.pi)
            for ax in axs[:,col]:
                ax.add_patch(plt.Circle((0,0),50,fill=False,color='cyan',lw=.8));ax.set(xlim=(-130,130),ylim=(-130,130),aspect='equal',xlabel='x (µm)',ylabel='y (µm)')
            axs[0,col].set_title(f'|l|={charge}: intensity at z=f');axs[1,col].set_title('Phase; dark pixels masked')
    fig.colorbar(im,ax=list(axs[1]),label='Phase (rad)')
    save(fig,3,'vortex_cross_sections','Calculated intensity and phase at the focal plane for charges 1, 3 and 6 with a 300 micrometre input waist. Cyan circles mark the fixed collection radius. Intensities have separate unit maxima; phase is masked below 1% of each peak.')
    coh=data['coherence'];c=np.array(coh['c']);cr=np.array(coh['cr']);h=np.array(coh['h_real'])+1j*np.array(coh['h_imag']);g=complex(*coh['gamma'])
    from .evidence_revision import coherent_core
    aa=np.linspace(0,1,61);dd=np.linspace(-np.pi,np.pi,81);response=np.array([[np.median(coherent_core(c,cr,h,g,a,d))-np.median((c+a*a*cr)/(1+a*a)) for a in aa] for d in dd])
    fig,axs=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
    im=axs[0].pcolormesh(aa,dd/np.pi,response*100,cmap='RdBu_r',shading='nearest',rasterized=True,vmin=-abs(response).max()*100,vmax=abs(response).max()*100)
    axs[0].set(xlabel='Copy amplitude weight a',ylabel='Relative phase / π',title='Core-local normalized prediction');fig.colorbar(im,ax=axs[0],label='Coherent − incoherent (percentage points)')
    for d,ls in [(0,'-'),(np.pi/2,':'),(np.pi,'--')]:
        pred=[100*(np.median(coherent_core(c,cr,h,g,a,d))-np.median((c+a*a*cr)/(1+a*a))) for a in aa]
        axs[1].plot(aa,pred,ls,label=f'δ={d/np.pi:.1f}π')
        rs=[r for r in coh['cases'] if abs(r['phase']-d)<1e-9]
        axs[1].plot([r['weight'] for r in rs],[100*(r['measurement']['median']-np.median((c+r['weight']**2*cr)/(1+r['weight']**2))) for r in rs],'o',ms=4)
    axs[1].set(xlabel='Copy amplitude weight a',ylabel='Coherent − incoherent (percentage points)',title='Curves: exact law; dots: direct propagation');axs[1].legend(frameon=False)
    save(fig,4,'coherence_response','Weight/phase map evaluated from the measured core-local cross integral and the input global overlap. Map pixels are analytical evaluations of these quantities, not independent simulations. Twelve separately normalized propagated superpositions test three phase slices on the right. Exact opposite phases need not produce equal opposite concentration changes.')
    fig,axs=plt.subplots(1,2,figsize=(9,3.6),layout='constrained')
    rs=coh['cases'];axs[0].semilogy(range(len(rs)),[max(r['maximum_error'],1e-16) for r in rs],'o');axs[0].set(xlabel='Held-out weight/phase case',ylabel='Maximum axial prediction error',title='Normalization identity check')
    pear=next(r for r in rs if r['weight']==.5 and r['phase']==0)
    axs[1].bar([0,1],[100*(pear['measurement']['median']-np.median(c)),100*(coh['control']['median']-coh['control_baseline'])],color=colors[:2])
    axs[1].set(xticks=[0,1],xticklabels=['Pearcey','Matched generic modes'],ylabel='Coherent gain (percentage points)',title='Same parity overlap and input second moment')
    save(fig,4,'coherence_control','Direct numerical verification of the normalized identity, followed by a Gaussian even/odd-mode control matched before propagation to global rotational overlap and input second moment. The control changes the spatial amplitude structure; it is not a phase-only random screen. Equal global overlap alone does not fix a core-local response.')
    (out/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
    return manifest
