"""Outer AI Scientist loop: choose -> preregister -> simulate -> criticize -> choose.

The model owns scientific decisions. This module owns budgets, typed interfaces,
trusted numerical execution and retention of negative/failed evidence.
"""
from __future__ import annotations
from dataclasses import asdict,replace
from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import platform
import re
import shutil
import signal
import time
import numpy as np
from ..paper_writing import reserve_paper_call
from ..physics import OpticalSetup
from ..designs import residual_phase
from ..discovery import Trial
from ..budgeted_search import optimize_arm
from .schemas import Hypothesis,Beam,Transformation,Environment,ResearchNode,Experiment,Evidence,Review
from .knowledge import KnowledgeAgent
from .composition import PhenomenonDiscoveryAgent
from .beams import normalize
from .research_experiment import ResearchBatch,ResearchExperiment,OBSERVABLES,COMPARISONS
from .journal import EvaluationJournal,BudgetStop
from .store import ResearchStore
from .dedup import candidate_record,find_duplicates,load_design_registry,prompt_history
from .planner import plan_research


def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()


def preserves_observable(primary,observable):
    """Require an exact registry observable, with only spelling normalization."""
    normalized=re.sub(r'[-\s]+','_',primary.lower())
    return observable.lower() in normalized


def run_loop(out: Path,*,hours=7.,max_api_calls=1500,backend='cuda',n=192,cases_per_cycle=5,
             max_cycles=1000,max_evaluations=200000,initial_plan: Path | None=None,
             model='deepseek-flash',baseline_budget=32,offline_batches: Path | None=None,prior_run: Path | None=None,
             continuation_context: dict | None=None,ledger_path: Path | None=None):
    if not 0<hours<=7 or not 1<=max_api_calls<=1500:raise ValueError('Maximum 7 hours and 1500 cumulative API calls')
    if n not in (64,128,192,256) or not 1<=cases_per_cycle<=20:raise ValueError('Invalid bounded grid/batch')
    if not 1<=max_cycles<=1000 or not 1<=max_evaluations<=200000:raise ValueError('Invalid loop ceiling')
    if not 32<=baseline_budget<=128:raise ValueError('Classical control fitting budget must be 32..128')
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    run_lock=(out/'.run.lock').open('a')
    try:fcntl.flock(run_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise RuntimeError('This outer loop is already running')
    if (out/'loop_state.json').exists():raise ValueError('Select a fresh outer-loop directory; completed cycles remain immutable')
    root=Path(__file__).resolve().parents[2]
    ledger=Path(ledger_path) if ledger_path is not None else out.parent/'paper_api_budget.json'
    sources=list((root/'autophotonics').rglob('*.py'))+[root/'scientist_v2_cli.py',root/'integrations/pgcd/knowledge.json']
    protocol={'strategy':'PGCD outer scientific loop','hours':hours,'max_api_calls':max_api_calls,
              'backend':backend,'n':n,'cases_per_cycle':cases_per_cycle,'max_cycles':max_cycles,
              'max_physics_evaluations':max_evaluations,'baseline_budget':baseline_budget,
              'model':model,'seed':7,'screening':'staged-v1','operator_selected_research_question':False,
              'continuation_context':continuation_context,
              'reproduction_enabled':False,'generated_code_execution':False,'gpu_memory_mb':512,
              'source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
    snapshot=out/'source_snapshot'
    for p in sources:
        target=snapshot/p.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    state={'status':'running','stage':'initializing','completed_cycles':0,'recorded_hypotheses':0,
           'started_at_utc':utc(),'api_calls_at_start':json.loads(ledger.read_text()).get('calls',0) if ledger.exists() else 0,
           'max_api_calls':max_api_calls,'max_hours':hours,'novelty_verified':False,
           'scientific_status':['SIMULATION_ONLY','NOVELTY_NOT_VERIFIED','NOT_PUBLICATION_READY']}
    started=time.monotonic();deadline=started+hours*3600
    journal=EvaluationJournal(out,max_evaluations,hours*3600)
    store=ResearchStore(out/'research.sqlite',protocol);knowledge=KnowledgeAgent()
    agent_state={'calls':state['api_calls_at_start'],'max_api_calls':max_api_calls}
    offline=json.loads(offline_batches.read_text()) if offline_batches else None
    client=None
    if not offline:
        from openai import OpenAI
        client=OpenAI(max_retries=0)
    feedback=None;plan=None;next_action='new_question';errors=0;duplicate_streak=0
    if initial_plan:
        plan=json.loads(initial_plan.read_text());shutil.copyfile(initial_plan,out/'initial_model_plan.json');next_action='continue'
    if prior_run:
        prior_run=Path(prior_run)
        prior_state=json.loads((prior_run/'loop_state.json').read_text())
        completed=sorted(prior_run.glob('cycle_*/scientific_critique.json'))
        if completed:feedback=json.loads(completed[-1].read_text())
        tested_designs=load_design_registry(prior_run)
        state['prior_run']=str(prior_run)
        state['original_started_at_utc']=prior_state.get('original_started_at_utc',prior_state['started_at_utc'])
        next_action='new_question'
    else:
        tested_designs=[]
    stop_requested=[False]
    def stop_signal(*_):stop_requested[0]=True
    old_signal=signal.signal(signal.SIGTERM,stop_signal)
    def used_calls():return json.loads(ledger.read_text()).get('calls',0) if ledger.exists() else 0
    def check():
        if stop_requested[0] or (out/'STOP').exists():raise BudgetStop('Stop requested')
        if time.monotonic()>=deadline:raise BudgetStop('7-hour wall-time allowance reached')
        if not offline and used_calls()>=max_api_calls:raise BudgetStop('Cumulative API-call ceiling reached')
        journal.check()
    def save(stage):
        state.update(stage=stage,updated_at_utc=utc(),elapsed_seconds=time.monotonic()-started,
                     physics_evaluations=journal.attempts,
                     cumulative_api_calls=json.loads(ledger.read_text()).get('calls',0) if ledger.exists() else 0)
        (out/'loop_state.json').write_text(json.dumps(state,indent=2))
        print('PGCD_LOOP',stage,'cycles',state['completed_cycles'],'hypotheses',state['recorded_hypotheses'],
              'api',state['cumulative_api_calls'],'physics',journal.attempts,flush=True)
    def call(cycle,role,prompt):
        check();call_id=reserve_paper_call(agent_state,ledger);save(role)
        audit={'id':call_id,'role':role,'model':model,'prompt':prompt,'status':'reserved','utc':utc()}
        path=cycle/f'call_{call_id:04d}_{role}.json';path.write_text(json.dumps(audit,indent=2))
        response=client.responses.create(model=model,instructions='You are an AI Scientist research agent. Make scientific decisions from evidence. Never invent results, citations or novelty. Output strict JSON only. No executable code.',
            input=[{'role':'user','content':prompt}],max_output_tokens=14000,reasoning={'effort':'low'},
            timeout=min(75.,max(1.,deadline-time.monotonic())))
        audit.update(status=response.status,response=response.output_text,usage=response.usage.model_dump() if response.usage else None)
        path.write_text(json.dumps(audit,indent=2));check()
        if response.status!='completed':raise ValueError('Incomplete model response')
        return json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',response.output_text.strip()))
    example_h=Hypothesis('C0001H001',Beam('pearcey',300e-6),(Transformation('quartic_xy',.2),),Environment('free_space'),
                         'Model must supply its own falsifiable prediction.','Model must supply its proposed mechanism.',minimum_gain=0.,metric='scientist_selected')
    example=ResearchBatch('Your own question','Your proposed mechanism','valley_filling','coherent_vs_single','ratio','>=',2.,
                          .03,.09,11,110e-6,.6e-3,.25,.02,.15,(example_h,)).record()
    try:
        save('starting_outer_loop')
        for cycle_index in range(1,max_cycles+1):
            check();cycle=out/f'cycle_{cycle_index:04d}';cycle.mkdir()
            try:
                if offline:
                    if cycle_index>len(offline):break
                    raw=offline[cycle_index-1]
                else:
                    if next_action in ('new_question','abandon') or plan is None:
                        save('ai_scientist_choosing_question')
                        context={'previous_evidence':feedback,'trusted_observables':OBSERVABLES,
                                 'trusted_comparisons':COMPARISONS,
                                 'previously_tested_designs':prompt_history(tested_designs),
                                 'continue_existing_branch':continuation_context,
                                 'instruction':'Choose your own next scientific question. You may deepen, replace or abandon earlier directions. Do not repeat a recorded physical design; identify what changes in the observable, composition or discriminating test. Use supported interfaces; no axial-floor target is imposed. Exploration does not require universal performance gains.'}
                        plan_dir=cycle/'model_plan'
                        try:
                            plan_research(plan_dir,model=model,max_calls=4,global_max_calls=max_api_calls,
                                          ledger_path=ledger,research_context=context,deadline_monotonic=deadline)
                        except Exception:
                            check()
                            if len(list(plan_dir.glob('call_*.json')))<4 and (plan_dir/'ideas.json').exists():
                                plan_research(plan_dir,model=model,max_calls=4,resume=True,global_max_calls=max_api_calls,
                                              ledger_path=ledger,research_context=context,deadline_monotonic=deadline)
                            else:raise
                        plan=json.loads((plan_dir/'research_plan.json').read_text())
                    (cycle/'adopted_model_plan.json').write_text(json.dumps(plan,indent=2))
                    prompt=json.dumps({'role':'AI Scientist experiment designer',
                       'task':f'Compile YOUR research question into exactly {cases_per_cycle} typed hypotheses for cycle {cycle_index}. IDs must be C{cycle_index:04d}H001 through C{cycle_index:04d}H{cases_per_cycle:03d}. Output one JSON object matching the schema example, with all keys. Preserve the load-bearing question and primary observable from your model-authored plan. If that observable is unsupported, return only {{"unsupported_measurement":"explanation"}}; do NOT replace nodal geometry, alignment, topological charge or another structural observable with a peak-intensity proxy. The example shows formatting, not a required research question. No executable code.',
                       'model_authored_plan':plan,'previous_evidence_and_critique':feedback,
                       'previously_tested_designs':prompt_history(tested_designs),
                       'deduplication_rule':'Do not return a candidate whose beam, transformations, composition, physical environment and registered measurement match any listed tested design. IDs, prose, and random seed changes do not make a new experiment. A changed physical parameter or a distinct registered observable/control can be a valid extension; state what it tests.',
                       'staged_screening':'Exploration requires trustworthy physics, not a universal 3% gain or all robustness. Negative and regime-specific results remain useful. Discovery claims need independent validation and prior-art review.',
                       'schema_example':example,'available_observables':OBSERVABLES,'available_comparisons':COMPARISONS,
                       'effect_formulas':{'ratio':'A/B, undefined if reference vanishes','difference':'A-B','relative_change':'(A-B)/abs(B)'},
                       'allowed_transformations':{'chirp':[-1.2,1.2],'quartic':[-.7,.7],'quartic_xy':[-.7,.7],
                           'ripple':[-1,1],'vortex':[-3,3],'rotate':[-3.141592653589793,3.141592653589793],'stretch':[.7,1.4],'coherent_pair':[-3.141592653589793,3.141592653589793]},
                       'transform_definition':'quartic=q*(x^2+y^2)^2/w^4; quartic_xy=q*(x^4+y^4)/w^4. Coefficients are dimensionless. All inputs finite-aperture, equal-power.',
                       'comparison_implementation':'Cases describe the SINGLE input source. The trusted engine separately creates its rotated, coherent and incoherent arms. Do not add coherent_pair or rotate simply to construct those arms again. A zero-phase coherent_pair followed by another zero-phase rotated-copy addition is an idempotent projection and is not a distinct interference test.',
                       'composition_interface':'Each hypothesis has composition={angle_rad,phase_rad,weight}. Rotation and relative phase are radians in [-pi,pi]; amplitude weight in [0,1]. The copy is combined as single + weight*exp(i*phase_rad)*rotated. The incoherent mixture uses weights 1 and weight^2, then equal total input power. Use this interface for phase/angle/unequal-weight tests, not a second coherent_pair in the source.',
                       'execution_contract':'environment.kind=free_space omits lens phase; thin_lens applies f=60mm. Use thin_lens explicitly for lens studies. phase_screen applies a pre-lens screen; environment.phase_rms is active only for phase_screen. Beam.charge is active for family=vortex; other families require a vortex transformation. Do not describe changing these inactive fields as experiments.',
                       'bounds':'z within .01.. .2m, 5..21 planes; core radius20..250um; marginal half width .2.. .6mm; prominence .1.. .5; noise0.. .1rad; max separation change null or0..1. Beam scale20..400um, Pearcey/Butterfly>=150um, apodization .05.. .5, integral charge -3..3. Up to3 transforms. One shared environment per batch. Metric field scientist_selected. max20 hypotheses. IDs unique alphanumeric; parent null or an existing ID. minimum_gain0 (unused; batch prediction is authoritative).',
                       'existing_parent_ids':[n['id'] for n in store.all_nodes()][-20:],
                       'verified_family_definitions':knowledge.data},ensure_ascii=False)
                    raw=call(cycle,'experiment_design',prompt)
                if isinstance(raw,dict) and raw.get('unsupported_measurement'):
                    feedback={'model_plan':plan,'unsupported_measurement':raw['unsupported_measurement'],
                              'instruction':'Choose an implementable scientific question; no surrogate observable was accepted.'}
                    (cycle/'unsupported_measurement.json').write_text(json.dumps(feedback,indent=2))
                    next_action='new_question';save('unsupported_question_parked');continue
                batch=ResearchBatch.from_dict(raw)
                if len(batch.cases)!=cases_per_cycle:raise ValueError('Model returned wrong hypothesis count')
                duplicates=find_duplicates(batch.record(),tested_designs)
                if duplicates:
                    duplicate_streak+=1
                    (cycle/'duplicate_proposal_rejected.json').write_text(json.dumps({
                        'status':'rejected_before_simulation','duplicates':duplicates,
                        'history_size':len(tested_designs),'attempt':duplicate_streak,
                        'same_batch_or_prior_physics_design':True},indent=2))
                    feedback={'model_plan':plan,'duplicate_proposal':duplicates,
                              'instruction':'This proposal repeats previously tested optical designs. No simulations were run. Keep the research question only if a physically distinct composition, observable, control or held-out test resolves a stated gap; otherwise select a different question.'}
                    next_action='new_question' if duplicate_streak>=2 else 'continue'
                    save('duplicate_proposal_rejected')
                    continue
                existing={node['id'] for node in store.all_nodes()}
                if any(h.id in existing or (h.parent_id is not None and h.parent_id not in existing) for h in batch.cases):raise ValueError('Invalid experiment lineage')
                if not offline:
                    primary=str((plan or {}).get('Execution Plan',{}).get('primary_observable',''))
                    if not preserves_observable(primary,batch.observable):
                        feedback={'unsupported_or_changed_primary_observable':primary,
                                  'proposed_observable':batch.observable,
                                  'instruction':'Choose a plan with an exactly supported primary observable; do not substitute a proxy.'}
                        (cycle/'unsupported_measurement.json').write_text(json.dumps(feedback,indent=2))
                        next_action='new_question';save('unsupported_question_parked');continue
                # Physics/schema invariants gate exploration. A language-model
                # opinion cannot veto engine-generated comparison arms or demand
                # publication-level confirmation before exploratory measurements.
                (cycle/'protocol_review.json').write_text(json.dumps({
                    'stage':'exploration','typed_schema_valid':True,
                    'primary_observable_preserved':True,
                    'arms_generated_by_engine':['single','rotated','coherent','incoherent','base','perturbed'],
                    'confirmation_pending':True,'scientific_critique':'after numerical evidence'},indent=2))
                # This immutable file is written before the first result.
                (cycle/'frozen_protocol.json').write_text(json.dumps(batch.record(),indent=2))
                tested_designs.extend(candidate_record(batch.record(),h.record()) for h in batch.cases)
                save('trusted_experiments')
                experiment=ResearchExperiment(batch,n=n,backend=backend)
                if not (out/'environment.json').exists():
                    sim=experiment.engine.sim
                    env={'python':platform.python_version(),'platform':platform.platform(),'numpy':np.__version__,'backend':backend,'n':n}
                    if backend=='cuda':
                        props=sim.xp.cuda.runtime.getDeviceProperties(0);name=props['name']
                        env.update(cupy=sim.xp.__version__,gpu=name.decode() if isinstance(name,bytes) else name)
                    (out/'environment.json').write_text(json.dumps(env,indent=2))
                summaries=[]
                for h in batch.cases:
                    check();node=ResearchNode(h.id,h.parent_id,h);store.node(node)
                    try:
                        record=journal.run(f'{cycle.name}/{h.id}',lambda h=h:experiment.evaluate(h,save=cycle/f'{h.id}.npz'))
                        node.state='simulated';store.node(node)
                        evidence=Evidence(h.id,{**record['checks'],'independent_observable_validation':False,
                                              'mesh_window_z_confirmation':False,'held_out_validation':False},
                            {'comparison':record['comparison'],
                            'confirmation_pending':['independent full-observable propagation','mesh/window/z convergence','held-out perturbations','technical prior-art comparison']},knowledge.citations(h.beam.family))
                        # Exploration only: no unperformed validation is set true.
                        valid=all(record['checks'].values());supported=record['comparison']['prediction_supported']
                        decision='exploratory' if valid else 'rejected'
                        equivalent=None
                        if valid and batch.comparison in ('coherent_vs_single','coherent_vs_incoherent') and record['equivalence']['known_identity']:
                            decision='known_control';equivalent='Coherent copy is the same normalized input up to global phase'
                        reasons=[] if valid else ['Input/sampling/boundary/quadrature gate failed; numerical evidence is unconfirmed.']
                        if not supported:reasons.append('Frozen scientific prediction unsupported or untestable; retain negative evidence.')
                        reasons.append('Candidate confirmation and novelty verification remain pending.')
                        node.evidence=asdict(evidence);node.review=asdict(Review(h.id,False,supported,equivalent,reasons,decision))
                        node.state='criticized';node.experiment_id='E_'+h.id
                        node.selection_score=float(valid)+.1*bool(supported)
                        m=record['arms']['single']['metrics'];node.descriptor=(int(m['qualifying_ridge_planes']>0),int(supported))
                        store.experiment(Experiment(node.experiment_id,h.id,h.environment.seed,
                            asdict(experiment.engine.sim.setup),m,1,0.,str(cycle.relative_to(out)/f'{h.id}.npz')))
                        store.node(node)
                        if valid:store.update_archive(node)
                        record['review']=node.review;record['confirmation_validated']=False
                    except BudgetStop:raise
                    except Exception as exc:
                        node.state='failed';node.review={'decision':'rejected','numerical_valid':False,'reasons':[type(exc).__name__+': '+str(exc)]};store.node(node)
                        record={'hypothesis':h.record(),'error':type(exc).__name__+': '+str(exc),'confirmation_validated':False}
                    (cycle/f'{h.id}.json').write_text(json.dumps(record,indent=2));summaries.append(record);state['recorded_hypotheses']+=1
                    save('hypothesis_'+h.id)
                # Optimize familiar Gaussian controls for the MODEL'S observable,
                # never for a fixed operator-selected axial-floor objective.
                controls={};adapter=experiment.engine.sim
                base_h=replace(batch.cases[0],beam=Beam('gaussian',300e-6),transformations=(),id=f'B{cycle_index:04d}')
                base_field=experiment.engine.input(base_h)[1]
                for arm,names in [('defocus',['q2']),('quadratic_quartic',['q2','q4']),('four_parameter',['q2','q4','q3','ripple'])]:
                    counter=[0]
                    def score_control(sim,candidate,reference_peak):
                        index=counter[0];counter[0]+=1
                        def compute():
                            record=experiment.evaluate(base_h,field_override=base_field*np.exp(1j*residual_phase(candidate,adapter)))
                            return {'parameters':candidate.record(),'comparison':record['comparison'],'checks':record['checks'],
                                    'absolute_observable':record['arms']['single']['metrics'][batch.observable],
                                    'minimum_retention':record['minimum_retention']}
                        row=journal.run(f'{cycle.name}/control/{arm}/{index}',compute)
                        effect=row['absolute_observable'] if continuation_context else row['comparison']['effect']
                        valid=all(row['checks'].values()) and effect is not None
                        score=float(effect if batch.direction=='>=' else -effect) if valid else -1e12
                        return Trial(candidate.family,candidate.q2,candidate.q3,candidate.q4,candidate.ripple,score,score,0.,row['minimum_retention'],bool(valid))
                    trials=optimize_arm(adapter,1.,budget=baseline_budget,family=arm,names=names,seed=7+cycle_index,trial_evaluator=score_control)
                    good=[t for t in trials if t.admissible]
                    best=max(good,key=lambda t:t.normalized_floor) if good else None
                    controls[arm]={'attempts':baseline_budget,'best':{
                                       'parameters':best.candidate().record(),
                                       'primary_effect':best.normalized_floor if batch.direction=='>=' else -best.normalized_floor,
                                       'effect_formula':'absolute_observable' if continuation_context else batch.effect,'observable':batch.observable,
                                       'minimum_retained_power':best.minimum_retained_power} if best else None,
                                   'note':'No testable/admissible control is not evidence of novelty. Scores optimize the frozen model-selected comparison.'}
                    if continuation_context and best:
                        def best_measurement():
                            rr=experiment.evaluate(base_h,field_override=base_field*np.exp(1j*residual_phase(best.candidate(),adapter)))
                            return {'metrics':{a:v['metrics'] for a,v in rr['arms'].items()},'checks':rr['checks'],
                                    'executed_setup':rr['executed_setup']}
                        controls[arm]['measurement']=journal.run(f'{cycle.name}/control/{arm}/best_absolute',best_measurement)
                        controls[arm]['note']='Optimized absolute registered observable of the single classical input, with identical power, aperture, lens and grid. Comparison effects are reported separately.'
                    save('control_'+arm)
                (cycle/'optimized_controls.json').write_text(json.dumps(controls,indent=2))
                (cycle/'experiment_summary.json').write_text(json.dumps(summaries,indent=2))
                if offline:
                    critique={'next_action':'new_question','analysis':'Offline engineering test; no model scientific assessment.'}
                else:
                    critique=call(cycle,'scientific_critic',json.dumps({'role':'AI Scientist scientific critic and research evolution manager',
                       'task':'Attempt to disprove the proposed mechanism and specificity. Analyze positive AND negative results, inadequate sampling, known equivalence and optimized controls. Decide continue, new_question or abandon. You own the next scientific decision, not the operator. Do not force a performance gain. Return JSON with next_action, analysis, disproving_evidence, promising_branches, required_discriminating_tests, next_research_direction. No novelty or discovery acceptance without actual validation and verified prior art.',
                       'model_plan':plan,'frozen_protocol':batch.record(),'actual_experiments':summaries,'optimized_classical_controls':controls,
                       'validation_scope':'These are exploratory scalar measurements. Full independent-observable and convergence/robustness confirmation is pending; do not call them validated discoveries.',
                       'interpretation_contract':'Control best.primary_effect is the literal frozen comparison effect, NOT a negated optimizer score. known_identity means single vs coherent input equivalence, never vortex vs untransformed base. Conjugating an arbitrary complex input does NOT prove identical intensity at the same positive propagation distance. Do not invent symmetry proofs. Separate tested negative predictions, unsupported original mechanisms and confirmed numerical facts.',
                       'available_measurements':OBSERVABLES},ensure_ascii=False))
                    if not isinstance(critique,dict) or critique.get('next_action') not in ('continue','new_question','abandon'):raise ValueError('Invalid scientific-critic decision')
                (cycle/'scientific_critique.json').write_text(json.dumps(critique,indent=2))
                feedback={'cycle':cycle_index,'question':batch.question,'measurements':[
                    {'hypothesis':r['hypothesis'],'comparison':r.get('comparison'),'checks':r.get('checks'),'error':r.get('error')} for r in summaries],
                    'optimized_controls':controls,'critique':critique}
                next_action=critique['next_action'];state['completed_cycles']+=1;errors=0;duplicate_streak=0
                report_lines=['# AI Scientist research cycle','',batch.question,'',
                    'SIMULATION_ONLY · NOVELTY_NOT_VERIFIED · NOT_PUBLICATION_READY','',
                    'Exploratory evidence; full numerical confirmation is pending.','',
                    '| Hypothesis | Testable | Prediction supported | Stage |','|---|---|---|---|']
                for r in summaries:
                    comp=r.get('comparison',{});report_lines.append(f"| {r['hypothesis']['id']} | {comp.get('testable',False)} | {comp.get('prediction_supported',False)} | {r.get('review',{}).get('decision','failed')} |")
                report_lines+=['','## Model scientific critique','',json.dumps(critique,indent=2,ensure_ascii=False)]
                (cycle/'research_report.md').write_text('\n'.join(report_lines)+'\n')
                store.export(out);save('cycle_completed')
                if continuation_context and next_action=='abandon':
                    state['status']='branch_closed_by_scientist';break
            except BudgetStop:raise
            except Exception as exc:
                errors+=1
                error={'utc':utc(),'cycle':cycle_index,'error':type(exc).__name__+': '+str(exc)}
                (cycle/'cycle_error.json').write_text(json.dumps(error,indent=2))
                feedback={'technical_error':error,'instruction':'Correct your structured protocol; do not invent evidence.'}
                next_action='continue' if plan else 'new_question';save('cycle_failed_recorded')
                if getattr(exc,'status_code',None) in (401,402,403):
                    state.update(status='provider_blocked',provider_http_status=exc.status_code);break
                if offline:raise
                # Bound repeated provider/schema failures without spinning.
                time.sleep(min(5.*min(errors,6),max(0.,deadline-time.monotonic())))
        if state['status']=='running':state['status']='completed_cycle_limit'
    except BudgetStop as exc:state.update(status='stopped_at_limit',stop_reason=str(exc))
    except KeyboardInterrupt:state.update(status='interrupted',stop_reason='User interrupt')
    finally:
        store.export(out);save('finished' if state['status']!='running' else 'failed');store.db.close()
        signal.signal(signal.SIGTERM,old_signal);fcntl.flock(run_lock,fcntl.LOCK_UN);run_lock.close()
    return state
