"""Bounded, trusted numerical follow-up to an AI Scientist research plan.

No generated code, model calls, automatic metric changes or outcome selection.
"""
from __future__ import annotations

from dataclasses import asdict, replace
import json
from pathlib import Path
import platform
import shutil
import subprocess
import time

import numpy as np

from .budgeted_search import optimize_arm, BOUNDS
from .designs import Candidate, residual_phase
from .discovery import evaluate
from .physics import AngularSpectrum, OpticalSetup


class TimeBudgetExceeded(RuntimeError):
    pass


def gaussian_fresnel_intensity(setup: OpticalSetup, z_m):
    """Analytical on-axis Gaussian + thin-lens Fresnel integral, infinite window.

    Integral: A*pi/[w0**-2 - i*pi/lambda*(1/z-1/f)] / (i*lambda*z).
    This is a paraxial analytical check for the Gaussian, not an independent
    nonparaxial propagation validation of every optimized mask.
    """
    z = np.asarray(z_m, dtype=float)
    if np.any(z <= 0):
        raise ValueError('Analytical Fresnel check requires positive z')
    w, lam, f = setup.waist_m, setup.wavelength_m, setup.focal_length_m
    return 2*setup.power_w*np.pi*w*w / (
        lam*lam*z*z*(1+(np.pi*w*w/lam*(1/z-1/f))**2))


def run_followup(source: Path, out: Path, *, backend='cuda', seconds=300,
                 gpu_memory_mb=512, seeds=(7,17,29), search_budget=1024, smoke=False):
    if out.exists():
        raise ValueError('Refusing to overwrite a follow-up run')
    if not 1 <= seconds <= 600 or not 32 <= search_budget <= 2048:
        raise ValueError('Time must be 1–600 seconds and search budget 32–2048')
    if not seeds or len(seeds)>5 or len(set(seeds))!=len(seeds):
        raise ValueError('Provide 1–5 distinct seeds')
    evidence = json.loads((source/'experiment.json').read_text(encoding='utf-8'))
    setup = OpticalSetup(**evidence['setup'])
    if smoke:
        setup = replace(setup,n=64)
    masks = {name:Candidate(**{key:row[key] for key in ('family','q2','q3','q4','ripple')})
             for name in ('gaussian','best_defocus','best_known_quartic','best_candidate')
             for row in [evidence[name]]}
    z_train = np.asarray(evidence['z_m'])
    dense_count = 7 if smoke else 61
    z_dense = np.linspace(z_train.min(),z_train.max(),dense_count)
    scan = 3 if smoke else 9
    protocol = {
        'status':['SIMULATION_ONLY','NOVELTY_NOT_VERIFIED','NOT_PUBLICATION_READY'],
        'purpose':'Informed follow-up, not a fresh preregistered discovery',
        'source':str(source.resolve()),'setup':asdict(setup),'backend':backend,
        'seconds':seconds,'gpu_memory_mb':gpu_memory_mb,'api_calls':0,
        'seeds':list(seeds),'search_budget_per_arm':search_budget,
        'search_arms':['defocus','quadratic_quartic','numeric_four_parameter'],
        'expected_search_attempts':len(seeds)*3*search_budget,
        'objective':evidence.get('objective'),'z_train_m':z_train.tolist(),
        'z_validation_m':z_dense.tolist(),'bounds':BOUNDS,
        'frozen_masks':{k:v.record() for k,v in masks.items()},
        'ablations':['q3_zero','ripple_zero','both_zero'],
        'scan_q3':np.linspace(*BOUNDS['q3'],scan).tolist(),
        'scan_ripple':np.linspace(*BOUNDS['ripple'],scan).tolist(),
        'mesh_sizes':[setup.n,int(setup.n*1.5)//2*2,setup.n*2],
        'window_factors':[1.,1.25,1.5],'window_sampling':'keep dx fixed; n scales with L',
        'z_counts':[len(z_train),dense_count,13 if smoke else 121],
        'wavelengths_m':[532e-9,780e-9],
        'wavelength_semantics':'fixed ideal optical path difference: residual phase scales lambda0/lambda; no material dispersion; ideal lens recomputed at each lambda',
        'focal_factors':[.9,1.1],
        'holdout_windows':'wavelength: original window; focal length: original endpoints multiplied by f/f0; no mask reoptimization',
        'normalization':'each condition uses its own Gaussian peak on the same sampled planes for every mask',
        'quantization_bits':[4,6,8],'phase_noise_radians':[.01,.03,.05],
        'perturbation_seeds':[101] if smoke else [101,103,107,109,113],
        'analytical_check':'infinite-window Gaussian thin-lens Fresnel integral; paraxial and Gaussian-only scope',
        'engineering_smoke':smoke,
        'reoptimization':'none in frozen masks/ablations/scans/convergence/holdout/perturbations; repeat searches use original training samples',
    }
    out.mkdir(parents=True)
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    started = time.monotonic()
    state = {'status':'running','stage':'initializing','evaluations':0,'search_attempts':0,
             'api_calls':0,'engineering_smoke':smoke}
    records = []
    traces = {}
    repeat = []
    def save():
        state['elapsed_seconds']=time.monotonic()-started
        (out/'state.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
    def check_time():
        if time.monotonic()-started>=seconds:
            raise TimeBudgetExceeded('Elapsed-time budget exhausted')
    def stage(name):
        check_time();state['stage']=name;save();print('FOLLOWUP_STAGE',name,flush=True)
    def record(row, search=False):
        records.append(row)
        with (out/'evaluations.jsonl').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(row)+'\n')
        state['evaluations']+=1
        state['search_attempts']+=int(search)
        if state['evaluations']%64==0:save()
        check_time()
    def simulator(settings=setup,z=z_dense):
        check_time()
        return AngularSpectrum(settings,z,backend=backend,gpu_memory_mb=gpu_memory_mb)
    def score(sim,c,label,phase=None,keep_trace=False):
        check_time()
        phi=residual_phase(c,sim) if phase is None else phase
        spectrum=sim.fft2(sim.input_field(phi))
        trace=sim.center_trace_from_spectrum(spectrum)
        reference=float(sim.center_trace().max())
        retention=float(np.min(sim.input_spectral_retention(spectrum)))
        row={'stage':state['stage'],'label':label,'candidate':c.record(),
             'setup':asdict(sim.setup),'z_count':len(sim.z_m),
             'floor':float(trace.min()/reference),'peak':float(trace.max()/reference),
             'uniformity':float(trace.min()/trace.max()),'retention':retention,
             'admissible':bool(retention>=.995)}
        record(row)
        if keep_trace:
            traces[label]={'z_m':sim.z_m.tolist(),'normalized_trace':(trace/reference).tolist()}
        return row,spectrum
    save()
    try:
        # Environment and source provenance, before any new outcome is inspected.
        try:
            commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
        except subprocess.CalledProcessError:commit=None
        versions={'python':platform.python_version(),'platform':platform.platform(),
                  'numpy':np.__version__,'commit':commit,'source_files':['autophotonics/followup.py','autophotonics/physics.py','autophotonics/designs.py','autophotonics/budgeted_search.py']}
        (out/'environment.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
        for name in ('followup.py','physics.py','designs.py','discovery.py','budgeted_search.py'):
            snapshot=out/'source_snapshot'/name
            snapshot.parent.mkdir(exist_ok=True)
            shutil.copy2(Path(__file__).parent/name,snapshot)
        stage('frozen_masks_and_ablations')
        sim=simulator()
        if backend=='cuda':
            props=sim.xp.cuda.runtime.getDeviceProperties(0)
            versions['gpu']=str(props['name']);versions['cupy']=sim.xp.__version__
            (out/'environment.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
        longitudinal={}
        for name,c in masks.items():
            _,spec=score(sim,c,name,keep_trace=True)
            ref=float(sim.center_trace().max())
            longitudinal[name]=np.asarray([abs(sim.field(spec,j)[setup.n//2,:])**2/ref for j in range(len(z_dense))])
        best=masks['best_candidate']
        for name,c in [('q3_zero',replace(best,q3=0)),('ripple_zero',replace(best,ripple=0)),
                       ('both_zero',replace(best,q3=0,ripple=0))]:
            score(sim,c,name,keep_trace=True)
        stage('phase_parameter_scan')
        for q3 in protocol['scan_q3']:
            score(sim,replace(best,q3=q3),'q3_sweep')
        for eta in protocol['scan_ripple']:
            score(sim,replace(best,ripple=eta),'ripple_sweep')
        for q3 in protocol['scan_q3']:
            for eta in protocol['scan_ripple']:
                score(sim,replace(best,q3=q3,ripple=eta),'q3_ripple_scan')
        stage('three_arm_repeated_search')
        train=simulator(z=z_train)
        ref=float(train.center_trace().max())
        for seed in seeds:
            for label,names in [('defocus',['q2']),('quadratic_quartic',['q2','q4']),
                                ('numeric_four_parameter',['q2','q4','q3','ripple'])]:
                stage('search_'+str(seed)+'_'+label)
                def callback(trial):
                    record({'stage':state['stage'],'seed':seed,'arm':label,**trial.record()},search=True)
                trials=optimize_arm(train,ref,budget=search_budget,family=label,names=names,seed=seed,on_trial=callback)
                admissible=[t for t in trials if t.admissible]
                winner=max(admissible,key=lambda t:t.normalized_floor)
                dense,_=score(sim,winner.candidate(),'repeat_'+str(seed)+'_'+label)
                repeat.append({'seed':seed,'arm':label,'attempts':len(trials),'training':winner.record(),'dense_validation':dense})
                (out/'repeat_search.json').write_text(json.dumps(repeat,indent=2),encoding='utf-8')
        stage('convergence')
        variants=[]
        for n in protocol['mesh_sizes']:variants.append(('mesh_'+str(n),replace(setup,n=n),z_dense))
        for factor in protocol['window_factors']:
            n=int(round(setup.n*factor/2))*2
            variants.append(('window_'+str(factor),replace(setup,n=n,extent_m=setup.extent_m*factor),z_dense))
        for count in protocol['z_counts']:variants.append(('z_'+str(count),setup,np.linspace(z_train.min(),z_train.max(),count)))
        for name,settings,z in variants:
            other=simulator(settings,z)
            for label,c in masks.items():score(other,c,name+'_'+label)
        stage('held_out_conditions')
        for lam in protocol['wavelengths_m']:
            other=simulator(replace(setup,wavelength_m=lam))
            scale=setup.wavelength_m/lam
            for label,c in masks.items():
                scaled=replace(c,**{key:getattr(c,key)*scale for key in ('q2','q3','q4','ripple')})
                score(other,scaled,'lambda_'+str(lam)+'_'+label)
        for factor in protocol['focal_factors']:
            other=simulator(replace(setup,focal_length_m=setup.focal_length_m*factor),z_dense*factor)
            for label,c in masks.items():score(other,c,'focal_'+str(factor)+'_'+label)
        stage('phase_perturbations')
        for label,c in masks.items():
            phase=residual_phase(c,sim)
            for bits in protocol['quantization_bits']:
                levels=2**bits-1
                quant=np.round(np.mod(phase,2*np.pi)/(2*np.pi)*levels)/levels*2*np.pi
                score(sim,c,label+'_bits_'+str(bits),phase=quant)
            for sigma in protocol['phase_noise_radians']:
                for seed in protocol['perturbation_seeds']:
                    noise=np.random.default_rng(seed).normal(0,sigma,phase.shape)
                    score(sim,c,label+'_noise_'+str(sigma)+'_'+str(seed),phase=phase+noise)
        stage('analytical_gaussian_check')
        analytical=gaussian_fresnel_intensity(setup,z_dense)
        actual=sim.center_trace()
        check={'scope':'Gaussian + ideal lens only; paraxial infinite-window reference',
               'maximum_relative_intensity_error':float(np.max(abs(actual/analytical-1))),
               'z_m':z_dense.tolist(),'analytical_intensity':analytical.tolist(),'asm_intensity':actual.tolist(),
               'validates_optimized_masks_independently':False}
        (out/'analytical_check.json').write_text(json.dumps(check,indent=2),encoding='utf-8')
        (out/'traces.json').write_text(json.dumps(traces,indent=2),encoding='utf-8')
        np.savez_compressed(out/'longitudinal_maps.npz',z_m=z_dense,x_m=sim.x[0],**longitudinal)
        stage('figures')
        _figures(out,traces,records)
        state['status']='completed';state['stage']='finished'
    except TimeBudgetExceeded as exc:
        state.update(status='budget_exhausted',error=str(exc))
    except BaseException as exc:
        state.update(status='failed',error=str(exc));save();raise
    finally:
        (out/'repeat_search.json').write_text(json.dumps(repeat,indent=2),encoding='utf-8')
        (out/'traces.json').write_text(json.dumps(traces,indent=2),encoding='utf-8')
        save()
    return state


def _figures(out,traces,records):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8,4.8))
    for name,row in traces.items():
        ax.plot(np.asarray(row['z_m'])*1000,row['normalized_trace'],label=name)
    ax.set(xlabel='z (mm)',ylabel='On-axis intensity / Gaussian peak')
    ax.legend(fontsize=7);fig.tight_layout();fig.savefig(out/'frozen_masks_ablations.png',dpi=150);plt.close(fig)
    scan=[r for r in records if r.get('label')=='q3_ripple_scan']
    fig,axes=plt.subplots(1,3,figsize=(14,4.2))
    for ax,label,key in zip(axes[:2],('q3_sweep','ripple_sweep'),('q3','ripple')):
        rows=[r for r in records if r.get('label')==label]
        ax.plot([r['candidate'][key] for r in rows],[r['floor'] for r in rows],'-o')
        ax.set(xlabel=key,ylabel='Sampled axial floor')
    ax=axes[2]
    plot=ax.scatter([r['candidate']['q3'] for r in scan],[r['candidate']['ripple'] for r in scan],
                    c=[r['floor'] for r in scan],s=100,cmap='viridis')
    ax.set(xlabel='Cubic coefficient q3',ylabel='Radial ripple coefficient')
    fig.colorbar(plot,ax=ax,label='Sampled axial floor');fig.tight_layout();fig.savefig(out/'phase_response.png',dpi=150);plt.close(fig)
    with np.load(out/'longitudinal_maps.npz') as maps:
        names=[name for name in maps.files if name not in ('z_m','x_m')]
        vmax=max(float(maps[name].max()) for name in names)
        fig,axes=plt.subplots(2,2,figsize=(10,7),layout='constrained')
        for ax,name in zip(axes.flat,names):
            image=ax.imshow(maps[name].T,origin='lower',aspect='auto',vmin=0,vmax=vmax,
                            extent=[maps['z_m'][0]*1000,maps['z_m'][-1]*1000,maps['x_m'][0]*1000,maps['x_m'][-1]*1000],cmap='inferno')
            ax.set(xlabel='z (mm)',ylabel='x at y=0 (mm)',title=name,ylim=(-.3,.3))
        fig.colorbar(image,ax=list(axes.flat),label='Intensity / common Gaussian peak')
        fig.savefig(out/'longitudinal_maps.png',dpi=150);plt.close(fig)
