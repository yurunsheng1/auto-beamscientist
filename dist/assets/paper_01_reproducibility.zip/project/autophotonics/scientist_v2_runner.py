"""AI Scientist-v2 ParallelAgent.step adapter for trusted optical experiments.

Upstream Node.code holds JSON data here. The upstream interpreter is never called.
Stage management, manuscript generation and LLM literature review are not enabled.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
import sys
import time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from .scientist_v2 import INTEGRATION, STATUS, prepare
from .physics import AngularSpectrum, OpticalSetup
from .discovery import evaluate, run_search, save_csv
from .agents import propose_llm, validate_proposal
from .report import check_candidate, write_figures, write_report, write_json


def run_v2(out: Path, *, upstream: Path = INTEGRATION/'upstream', backend='cuda',
           model='deepseek-flash', n=128, steps=3, proposal=None, evaluations_per_arm=0):
    if not 1 <= steps <= 25:
        raise ValueError('steps must be between 1 and 25')
    if evaluations_per_arm and not 32 <= evaluations_per_arm <= 2048:
        raise ValueError('evaluations_per_arm must be 0 or 32–2048')
    if evaluations_per_arm and evaluations_per_arm <= steps:
        raise ValueError('per-arm budget must exceed LLM steps')
    if (out/'engine_run.json').exists():
        raise ValueError('Output already contains a run; select a new output directory')
    config = prepare(out, upstream, model)
    (out/'protocol.json').write_text(json.dumps({
        'objective':'minimum on-axis intensity / Gaussian peak', 'z_m':[.049,.071],
        'n':n, 'seed':7, 'evaluations_per_arm':evaluations_per_arm,
        'llm_attempts':steps, 'metric_changes_after_results':False,
        'minimum_retention':.995, 'performance_margin':.03,
        'note':'Engineering follow-up informed by previous runs; no novelty preregistration claim.'
    },indent=2))
    sys.path.insert(0, str(upstream.resolve()))
    from ai_scientist.treesearch.parallel_agent import ParallelAgent
    from ai_scientist.treesearch.journal import Journal, Node
    from ai_scientist.treesearch.utils.metric import MetricValue
    from omegaconf import OmegaConf

    class FixedSummaryJournal(Journal):
        def generate_summary(self, include_code=False, **kwargs):
            # No hidden LLM summary calls: preserve the fixed API budget.
            return json.dumps([{'id':x.id, 'plan':x.plan, 'analysis':x.analysis}
                               for x in self.nodes][-5:])

    class StructuredOpticsAgent(ParallelAgent):
        def __init__(self):
            # Parent initialization requests model-defined metrics and configures
            # arbitrary-code workers. Replace those setup steps explicitly.
            self.cfg = OmegaConf.create({'agent':{'num_workers':1}})
            self.journal = FixedSummaryJournal()
            self.task_desc = 'Fixed-power phase-only masks, fixed 49–71 mm observation window'
            self.stage_name = 'optics'
            self.best_stage1_node = self.best_stage2_node = self.best_stage3_node = None
            self.num_workers = 1
            self.gpu_manager = None
            self.timeout = 60
            self._is_shutdown = False
            self.evaluation_metrics = 'maximize minimum on-axis intensity / Gaussian peak'
            self.executor = ThreadPoolExecutor(max_workers=1)
            self.sim = AngularSpectrum(OpticalSetup(n=n), np.linspace(.049,.071,15), backend=backend)
            if evaluations_per_arm:
                from .budgeted_search import matched_search
                self.result = matched_search(self.sim,evaluations_per_arm,steps,seed=7)
                self.scores = list(self.result['all'])
                save_csv(out/'numeric_trials.csv',self.scores)
                save_csv(out/'control_trials.csv',self.result['control_trials'])
            else:
                self.result = run_search(self.sim, seed=7, trials=1)
                self.scores = []
            self.attempts = 0

        def _select_parallel_nodes(self):
            if len(self.journal) < 2:
                return [None]
            return [self.journal.get_best_node(use_val_metric_only=True)]

        def _process_node_wrapper(self, node_data, *args):
            started = time.monotonic()
            parent = None
            node = Node(code='', plan='', is_buggy=True, is_buggy_plots=False,
                        metric=MetricValue(None, maximize=True))
            self.attempts += 1
            try:
                if node_data:
                    parent, _ = validate_proposal(json.loads(node_data['code']))
                top = [x.record() for x in sorted(self.scores,key=lambda t:t.normalized_floor,reverse=True)[:5]]
                candidate, hypothesis = (proposal(parent,top,self.attempts-1,model)
                                         if proposal else propose_llm(parent,top,self.attempts-1,model,
                                             baseline_context={
                                                 'gaussian':self.result['gaussian'].record(),
                                                 'optimized_defocus':self.result['best_defocus'].record(),
                                                 'optimized_quartic':self.result['best_known_quartic'].record(),
                                                 'recent_attempts':[x.analysis for x in self.journal.nodes[-3:]],
                                                 'search_protocol':self.result.get('search_protocol')
                                             }))
                candidate, _ = validate_proposal(candidate.record())
                node.code = json.dumps(candidate.record())
                node.plan = hypothesis
                score = evaluate(self.sim,candidate,self.result['reference_peak'])
                self.scores.append(score)
                node.metric = MetricValue(score.normalized_floor if score.admissible else None,
                                          maximize=True, name='axial_floor')
                node.is_buggy = not score.admissible
                node.analysis = json.dumps({'trial':score.record(), 'strong_control':self.result['best_known_quartic'].record(),'status':STATUS})
            except Exception as exc:
                node.exc_type = type(exc).__name__
                node.analysis = str(exc)
            node.exec_time = time.monotonic()-started
            node._term_out = [node.analysis]
            data = node.to_dict()
            data['parent_id'] = node_data['id'] if node_data else None
            (out/f'attempt_{self.attempts:03d}.json').write_text(json.dumps(data,indent=2))
            return data

        def cleanup(self):
            if not self._is_shutdown:
                self.executor.shutdown(wait=True,cancel_futures=True)
                self._is_shutdown = True

    # Explicitly block every route into the upstream arbitrary-code interpreter.
    def forbidden_executor(*args, **kwargs):
        raise RuntimeError('Generated Python execution is forbidden in the optical adapter')

    meta = {'status':'running','engine':'AI Scientist-v2 ParallelAgent.step',
            'upstream_commit':config['upstream']['commit'], 'backend':backend,
            'model':model, 'seed':7, 'n':n, 'steps':steps, 'max_api_attempts':steps,
            'generated_code_execution':False,'manuscript_generation':False,
            'adaptations':['single trusted worker','fixed metric','metric-based selection','deterministic progress summary'],
            'scientific_status':STATUS}
    (out/'engine_run.json').write_text(json.dumps(meta,indent=2))
    config.update({'integration_status':'adapted_upstream_tree_search',
                   'api_calls_enabled':proposal is None, 'max_api_calls':steps if proposal is None else 0})
    (out/'integration.json').write_text(json.dumps(config,indent=2))
    agent = StructuredOpticsAgent()
    try:
        for _ in range(steps):
            # Calls the actual pinned upstream manager's step implementation.
            agent.step(forbidden_executor)
            (out/'upstream_journal.json').write_text(json.dumps([x.to_dict() for x in agent.journal.nodes],indent=2))
        good = [x for x in agent.scores if x.admissible]
        if not good:
            raise RuntimeError('No admissible optical candidate; inspect recorded attempts')
        result = agent.result
        result['all'] = agent.scores
        result['ranked'] = sorted(good,key=lambda t:t.normalized_floor,reverse=True)
        result['best'] = result['ranked'][0]
        checks = check_candidate(agent.sim,result)
        save_csv(out/'all_trials.csv',result['all'])
        save_csv(out/'control_trials.csv',result['control_trials'])
        write_figures(agent.sim,result,out)
        write_report(agent.sim,result,checks,out,7,len(agent.scores))
        write_json(agent.sim,result,checks,out,7,len(agent.scores))
        meta['status']='completed'
        meta['attempts']=agent.attempts
        meta['performance_gates_pass']=checks['performance_gates_pass']
        meta['search_protocol']=result.get('search_protocol')
        meta['evaluated_hybrid_trials']=len(agent.scores)
        meta['llm_errors']=sum(bool(x.exc_type) for x in agent.journal.nodes)
    except BaseException as exc:
        meta['status']='failed';meta['error']=str(exc)
        raise
    finally:
        agent.cleanup()
        (out/'engine_run.json').write_text(json.dumps(meta,indent=2))
    return meta
