"""Deterministic bounded numerical search with explicit per-arm trial budgets."""
from __future__ import annotations
import numpy as np
from .designs import Candidate
from .discovery import evaluate

BOUNDS = {'q2':(-1.2,1.2),'q3':(-.4,.4),'q4':(-.7,.7),'ripple':(-1.,1.)}


def optimize_arm(sim, reference_peak, *, budget, family, names, seed=7, on_trial=None, trial_evaluator=None):
    if budget < 1:
        raise ValueError('budget must be positive')
    rng = np.random.default_rng(seed)
    trials = []
    population = []
    for i in range(budget):
        values = {k:0. for k in BOUNDS}
        # Identical nested-family starting points for the quartic and hybrid arms.
        if i < 25:
            if 'q4' in names:
                values['q2'] = float(np.linspace(-1.2,1.2,5)[i//5])
                values['q4'] = float(np.linspace(-.7,.7,5)[i%5])
            else:
                values['q2'] = float(np.linspace(-1.2,1.2,25)[i])
            if i == 0:
                values = {k:0. for k in BOUNDS}
        else:
            good = [x for x in trials if x.admissible]
            best = max(good,key=lambda x:x.normalized_floor) if good else trials[0]
            values.update({k:getattr(best,k) for k in BOUNDS})
            if i % 16 == 0:
                for k in names:
                    values[k] = float(rng.uniform(*BOUNDS[k]))
            else:
                # Best/1 differential mutation captures coupled q2/q4/ripple changes.
                a,b = rng.choice(len(population),size=2,replace=False)
                forced = names[int(rng.integers(len(names)))]
                for k in names:
                    lo,hi=BOUNDS[k]
                    if rng.random()<.8 or k==forced:
                        values[k] += .7*(getattr(population[a],k)-getattr(population[b],k))
                    # Preserve exploration in dimensions initially zero in nested controls.
                    values[k] += rng.normal(0,(hi-lo)*.01/(1+i/128)**.5)
                    values[k] = float(np.clip(values[k],lo,hi))
        trial=(trial_evaluator or evaluate)(sim,Candidate(family,**values),reference_peak)
        if on_trial is not None:
            on_trial(trial)
        trials.append(trial)
        if len(population)<25:
            population.append(trial)
        else:
            target=(i-25)%25
            old=population[target]
            if trial.admissible and (not old.admissible or trial.normalized_floor>=old.normalized_floor):
                population[target]=trial
    return trials


def matched_search(sim, budget, llm_steps, seed=7):
    if not 32 <= budget <= 2048 or not 1 <= llm_steps < budget:
        raise ValueError('per-arm budget must be 32–2048 and exceed LLM steps')
    trace = sim.center_trace()
    peak = float(trace.max())
    gaussian = evaluate(sim,Candidate('gaussian_lens'),peak)
    defocus = optimize_arm(sim,peak,budget=budget,family='defocus_control',names=['q2'],seed=seed)
    quartic = optimize_arm(sim,peak,budget=budget,family='known_quadratic_quartic_control',names=['q2','q4'],seed=seed)
    numeric = optimize_arm(sim,peak,budget=budget-llm_steps,family='mixed',names=['q2','q4','q3','ripple'],seed=seed)
    def best(rows):
        return max((x for x in rows if x.admissible),key=lambda x:x.normalized_floor)
    return {'gaussian':gaussian,'best_defocus':best(defocus),'best_known_quartic':best(quartic),
            'all':numeric,'ranked':sorted(numeric,key=lambda x:x.normalized_floor,reverse=True),
            'best':best(numeric),'control_trials':defocus+quartic,'baseline_trace':trace,'reference_peak':peak,
            'search_protocol':{'budget_per_optimized_arm':budget,'seed':seed,'hybrid_numerical_attempts':budget-llm_steps,
                               'hybrid_llm_attempts':llm_steps,'defocus_attempts':budget,'quartic_attempts':budget,
                               'comparison':'Matched proposal-attempt budgets. Hybrid LLM additionally sees control outcomes; this is informed augmentation, not an equal-information comparison.',
                               'optimizer':'shared nested-family initialization then bounded differential mutation, jitter and seeded restarts',
                               'common_bounds':BOUNDS}}
