"""Optional OpenAlex metadata search. Candidate novelty cannot be proven by this.

Network is used ONLY if explicitly requested. No external model is needed.
"""
import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from .designs import FAMILY_PRIOR_ART


def openalex_prior_art(family, per_page=5, timeout=10):
    query = FAMILY_PRIOR_ART.get(family, family)
    base = 'https://api.openalex.org/works'
    url = base + '?' + urlencode({
        'search': query,
        'per-page': min(int(per_page), 10),
        'select': 'id,title,publication_year,doi,primary_location',
    })
    request = Request(url, headers={'User-Agent': 'AutoPhotonicsScientist/0.1 (research prototype)'})
    with urlopen(request, timeout=timeout) as response:
        data = json.load(response)
    return [{'title': row.get('title'), 'year': row.get('publication_year'),
             'doi': row.get('doi'), 'openalex': row.get('id')}
            for row in data.get('results', [])]
