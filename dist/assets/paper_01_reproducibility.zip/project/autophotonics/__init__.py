"""AutoPhotonics Scientist: a reproducible computational discovery MVP."""
__version__ = '0.1.0'
