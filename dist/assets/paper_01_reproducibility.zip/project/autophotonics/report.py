"""Render candidate figures and a conservative, audit-ready research brief."""
import csv
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from .designs import residual_phase, FAMILY_PRIOR_ART
from .physics import OpticalSetup, AngularSpectrum


def _number(v):
    return float(v)


def check_candidate(sim, experiment):
    """Higher-grid check, quantized phase check, and leakage/energy diagnostics."""
    best = experiment['best']
    baseline = experiment['gaussian']
    control = experiment['best_defocus']
    known_control = experiment['best_known_quartic']
    phase = residual_phase(best.candidate(), sim)
    spectrum = sim.fft2(sim.input_field(phase))
    focus_idx = int(np.argmin(abs(sim.z_m - sim.setup.focal_length_m)))
    sample_field = sim.field(spectrum, focus_idx)
    zmax_field = sim.field(spectrum, len(sim.z_m) - 1)
    # 8-bit phase setting is an idealization; real SLM needs wavelength calibration.
    wrapped = np.mod(phase, 2*np.pi)
    wrapped_quant = np.round(wrapped/(2*np.pi)*255)/255*2*np.pi
    quant_trace = sim.center_trace(wrapped_quant)
    quant_floor = quant_trace.min()/experiment['reference_peak']
    high_setup = OpticalSetup(n=int(round(sim.setup.n * 1.5 / 2)) * 2,
                              extent_m=sim.setup.extent_m,
                              wavelength_m=sim.setup.wavelength_m,
                              waist_m=sim.setup.waist_m,
                              focal_length_m=sim.setup.focal_length_m,
                              power_w=sim.setup.power_w)
    high_sim = AngularSpectrum(high_setup, sim.z_m, backend=sim.backend, gpu_memory_mb=sim.gpu_memory_mb)
    high_b = high_sim.center_trace()
    high_c = high_sim.center_trace(residual_phase(best.candidate(), high_sim))
    high_score = high_c.min()/high_b.max()
    ratio = (best.normalized_floor / control.normalized_floor) - 1
    ratio_known = (best.normalized_floor / known_control.normalized_floor) - 1
    return {
        'grid_check_n': high_setup.n,
        'grid_refined_floor': _number(high_score),
        'grid_relative_change': _number((high_score / best.normalized_floor) - 1),
        'quantized_floor': _number(quant_floor),
        'quantization_relative_change': _number(quant_floor / best.normalized_floor - 1),
        'edge_leakage_at_last_z': sim.edge_fraction(zmax_field),
        'focused_power_in_110um_radius': sim.encircled_fraction(sample_field),
        'net_improvement_over_defocus_control': _number(ratio),
        'net_improvement_over_optimized_known_quartic': _number(ratio_known),
        'performance_gates_pass': bool(
            best.admissible and ratio > 0.03 and ratio_known > 0.03
            and abs(high_score / best.normalized_floor - 1) <= 0.05
            and abs(quant_floor / best.normalized_floor - 1) <= 0.05
            and sim.edge_fraction(zmax_field) <= 0.01
        ),
        # Numerical performance alone does not establish scientific novelty.
        'literature_novelty_verified': False,
        'ready_for_submission': False,
    }


def write_figures(sim, experiment, out):
    out = Path(out)
    best = experiment['best'].candidate()
    control = experiment['best_defocus'].candidate()
    quartic = experiment['best_known_quartic'].candidate()
    baseline_peak = experiment['reference_peak']
    curves = {
        'Gaussian + lens': sim.center_trace(),
        'Optimized defocus (simple control)': sim.center_trace(residual_phase(control, sim)),
        'Known quadratic + quartic control': sim.center_trace(residual_phase(quartic, sim)),
        'Best automated candidate': sim.center_trace(residual_phase(best, sim)),
    }
    with open(out / 'axial_profiles.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['z_mm', 'Gaussian_norm', 'Defocus_control_norm', 'Known_quartic_control_norm', 'Candidate_norm'])
        for idx, z in enumerate(sim.z_m):
            writer.writerow([_number(z*1e3)] + [_number(v[idx]/baseline_peak) for v in curves.values()])
    fig, ax = plt.subplots(figsize=(8.8, 4.9))
    for label, value in curves.items():
        ax.plot(sim.z_m*1e3, value / baseline_peak, label=label, linewidth=2)
    ax.set(xlabel='Propagation distance z (mm)', ylabel='On-axis intensity / Gaussian peak',
           title='Axial intensity: common input power and equal observation window')
    ax.grid(alpha=.25)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(out / 'axial_profile.png', dpi=175)
    plt.close(fig)
    j = int(np.argmin(abs(sim.z_m - sim.setup.focal_length_m)))
    field_ref = sim.field(sim.fft2(sim.input_field()), j)
    residual = residual_phase(best, sim)
    field_candidate = sim.field(sim.fft2(sim.input_field(residual)), j)
    images = [np.mod(residual, 2*np.pi), abs(field_ref)**2/baseline_peak,
              abs(field_candidate)**2/baseline_peak]
    titles = ['Residual phase (wrapped, rad)', 'Gaussian focus', 'Candidate focus']
    ext = [-sim.setup.extent_m*500, sim.setup.extent_m*500]*2
    fig, axes = plt.subplots(1, 3, figsize=(12.2, 3.7))
    for k, (ax, image, title) in enumerate(zip(axes, images, titles)):
        vmax = 2*np.pi if k == 0 else max(images[1].max(), images[2].max())
        im = ax.imshow(image, cmap='viridis' if k == 0 else 'inferno',
                       origin='lower', extent=ext, vmin=0, vmax=vmax)
        ax.set(xlabel='x (mm)', ylabel='y (mm)', title=title, xlim=(-0.35,0.35), ylim=(-0.35,0.35))
        fig.colorbar(im, ax=ax, fraction=.04, pad=.03)
    fig.suptitle(f'Equal-power focal-plane comparison at z = {sim.z_m[j]*1e3:.1f} mm')
    fig.tight_layout()
    fig.savefig(out / 'phase_and_focal_planes.png', dpi=175)
    plt.close(fig)


def write_report(sim, experiment, diagnostics, out, seed, trials, references=None, lit_error=None):
    out = Path(out)
    g, c, q, b = (experiment['gaussian'], experiment['best_defocus'],
                  experiment['best_known_quartic'], experiment['best'])
    setting = sim.setup
    improvement = 100 * diagnostics['net_improvement_over_defocus_control']
    known_improvement = 100 * diagnostics['net_improvement_over_optimized_known_quartic']
    gate_str = 'PASS (numerical screening only)' if diagnostics['performance_gates_pass'] else 'FAIL / INCONCLUSIVE'
    report = f'''# AutoPhotonics Scientist — numerical research brief

## Status

**Scientific discovery status: UNVERIFIED. Publication-ready: NO.**
This document reports automated numerical screening, not peer-reviewed discovery,
not an experiment, and not a manuscript.

## Research question

Can a passive phase-only modulation of an equal-power Gaussian input beam increase
the *minimum on-axis intensity* within the fixed observation range
{sim.z_m[0]*1e3:.1f}–{sim.z_m[-1]*1e3:.1f} mm compared with an ideal focusing lens?

## Model and experimental settings

- Scalar, single-wavelength ideal thin-lens model (no polarization/nonlinear optics).
- Wavelength: {setting.wavelength_m*1e9:.1f} nm.
- Gaussian waist: {setting.waist_m*1e3:.3f} mm.
- Ideal lens focal length: {setting.focal_length_m*1e3:.1f} mm.
- Computational width: {setting.extent_m*1e3:.2f} mm; grid: {setting.n} × {setting.n}.
- Input power: {setting.power_w:.3f} W. Intensity figures normalized to Gaussian peak.
- Band-limited scalar angular-spectrum propagation, with a conservative circular mask.
- Automated search seed {seed}, {trials} random candidate phase masks.
- Optimize worst-case *on-axis* intensity (not total peak brightness or energy delivery).

## Compared with honest controls

| Design | Minimum on-axis intensity (relative to Gaussian peak) | Relative peak | Retained spectrum |
| --- | ---: | ---: | ---: |
| Gaussian + fixed ideal lens | {g.normalized_floor:.5f} | {g.normalized_peak:.5f} | {g.minimum_retained_power:.6f} |
| Best 1-parameter defocus (optimized control) | {c.normalized_floor:.5f} | {c.normalized_peak:.5f} | {c.minimum_retained_power:.6f} |
| Best known quadratic + quartic control (2 parameters) | {q.normalized_floor:.5f} | {q.normalized_peak:.5f} | {q.minimum_retained_power:.6f} |
| Best automated candidate | {b.normalized_floor:.5f} | {b.normalized_peak:.5f} | {b.minimum_retained_power:.6f} |

Candidate family: **{b.family}**. Coefficients (radians, in normalized coordinates):
q2={b.q2:.5f}, q3={b.q3:.5f}, q4={b.q4:.5f}, ripple={b.ripple:.5f}.

Increase in the declared objective over optimized trivial defocus: **{improvement:+.2f}%**.
Change relative to the **stronger optimized known quartic control**: **{known_improvement:+.2f}%**.
When the latter is negative, the candidate is **not even performance-superior to a
standard known phase family** on this metric, and should be rejected as a purported
new discovery. The target metric and ranges were fixed before screening.
This does NOT mean a {improvement:.2f}% improvement in total transmitted power,
spot size, trapping force, resolution, or overall research impact.

## Numerical checks

| Check | Observed |
| --- | ---: |
| Higher-grid n | {diagnostics['grid_check_n']} |
| Relative worst-case-intensity change with grid refinement | {100*diagnostics['grid_relative_change']:+.3f}% |
| Relative change after idealized 8-bit phase quantization | {100*diagnostics['quantization_relative_change']:+.3f}% |
| Power fraction at window edges on the final propagation plane | {100*diagnostics['edge_leakage_at_last_z']:.4f}% |
| Focused power fraction within radius 110 µm (at nominal focus) | {100*diagnostics['focused_power_in_110um_radius']:.3f}% |
| Gain relative to optimized known phase control | {known_improvement:+.2f}% |
| Numerical performance gates | {gate_str} |

## Scientifically critical caveats

1. **Prior-art novelty is NOT established**. The candidate design components (defocus,
   quartic aberrations, cubic masks, ripple masks) are familiar in wavefront coding,
   focusing and extended-depth-of-focus literature. Search and read the closest prior
   papers before formulating any original discovery claim.
2. The searched figures optimize *one metric on a chosen z interval*. The gains may
   not survive other z windows or more realistic experimental constraints. This is
   particularly vulnerable to cherry-picking, so the z window and metric were fixed
   before the search and must be disclosed unchanged.
3. Scalar linear propagation says nothing about optical trapping performance unless
   optical forces and material response are calculated.
4. The ideal thin-lens phase and 8-bit phase are not realistic SLM hardware models.
   Phase calibration, fill factor, pixel pitch, aperture, noise, aberrations, and
   photodamage/power constraints need independent studies.
5. The radial bandlimit is conservative. Cross-check interesting candidates with
   a truly independent propagation implementation or analytical limiting case.
6. A known quadratic+quartic control was optimized separately over a 21×25 grid.
   It is a strong negative control, not a complete survey of published state of the art.
7. If improvements are inferior to these optimized controls, do not present this
   as a novel beam discovery.

## Outputs

- `all_trials.csv`: every sampled design, including rejected numerical candidates.
- `control_trials.csv`: 101 optimized defocus scans + 525 known quadr./quartic scans.
- `top_candidates.csv`: top admissible designs, ranked by fixed objective.
- `axial_profiles.csv`: numeric plot data with normalizing reference.
- `axial_profile.png`: axial performance and the optimized trivial control.
- `phase_and_focal_planes.png`: phase and fair common-scale intensity comparison.
- `experiment.json`: assumptions, best hypothesis and automated diagnostics.

## Literature queries required next

- `{FAMILY_PRIOR_ART.get(b.family, b.family)}`
- `phase-only mask depth of focus axial intensity optimization optical focus`
- `wavefront coding quartic mask autofocus enhanced axial intensity`
'''
    if references:
        report += '\n### OpenAlex metadata candidates (NOT a complete novelty review)\n\n'
        for i, item in enumerate(references, 1):
            report += f"{i}. {item.get('title')} ({item.get('year')}) — {item.get('doi') or item.get('openalex')}\n"
    elif lit_error:
        report += f'\nOpenAlex metadata retrieval not completed: {lit_error}.\n'
    else:
        report += '\nLive literature search was not requested or performed.\n'
    report += '''
## Method references

- Matsushima & Shimobaba, “Band-limited angular spectrum method for numerical
  simulation of free-space propagation in far and near fields,” *Optics Express*
  **17**, 19662 (2009). DOI: https://doi.org/10.1364/OE.17.019662
- *Optics Letters* review criteria:
  https://opg.optica.org/resources/author/Optics_Letters_Letter_criteria_Sept_2021.pdf

## Required next experiments to advance beyond MVP

Independent wave-optics solver, expanded baseline set (axicons, cubic phase plates,
known EDOF beams), parameter ablation, perturbation tests, device-in-the-loop SLM
measurement, and human verified comparison with the closest 10–20 papers.
**Never claim experimental verification from these simulations.**
'''
    protocol = experiment.get('search_protocol')
    if protocol:
        budget = protocol['budget_per_optimized_arm']
        report = report.replace('101 optimized defocus scans + 525 known quadr./quartic scans',
                                f'{budget} defocus and {budget} known quadratic/quartic attempts')
        report = report.replace('A known quadratic+quartic control was optimized separately over a 21×25 grid.',
                                f'A known quadratic+quartic control was optimized with {budget} bounded numerical attempts.')
        report = report.replace(f'{trials} random candidate phase masks',
                                f'{trials} evaluated candidates from numerical optimization and LLM proposals')
        report += '\n## Fixed search protocol\n\n' + json.dumps(protocol,indent=2) + '\n'
    (out / 'research_brief.md').write_text(report, encoding='utf-8')


def write_json(sim, experiment, diagnostics, out, seed, trials):
    data = {
        'system': 'AutoPhotonicsScientist-MVP', 'version': '0.1.0',
        'status': 'simulation_only_not_novelty_verified',
        'seed': seed, 'trials': trials,
        'backend': sim.backend, 'gpu_memory_mb': sim.gpu_memory_mb,
        'z_m': [float(z) for z in sim.z_m],
        'setup': dict(sim.setup.__dict__),
        'objective': 'maximize min_z on-axis intensity / Gaussian peak',
        'gaussian': experiment['gaussian'].record(),
        'best_defocus': experiment['best_defocus'].record(),
        'best_known_quartic': experiment['best_known_quartic'].record(),
        'best_candidate': experiment['best'].record(),
        'diagnostics': diagnostics,
        'search_protocol': experiment.get('search_protocol'),
    }
    (out / 'experiment.json').write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
