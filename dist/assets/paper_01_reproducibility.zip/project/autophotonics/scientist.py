"""Audit-first AI-Scientist-like search-tree loop.

One run: optimized controls -> constrained hypotheses -> numerical experiments
-> per-node critique -> stronger validation -> research brief. Never claims
novelty without a manual prior-art review and independent verification.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import csv
import json
import numpy as np
from .physics import OpticalSetup, AngularSpectrum
from .discovery import evaluate, run_search, save_csv
from .agents import propose_heuristic, propose_llm
from .report import check_candidate, write_figures, write_report, write_json
from .designs import FAMILY_PRIOR_ART


def _fingerprint(candidate):
    return tuple(round(float(getattr(candidate, v)), 5) for v in ('q2', 'q3', 'q4', 'ripple'))


def _critic(score, baseline):
    if not score.admissible:
        return 'INVALID_NUMERICAL_BANDLIMIT'
    if score.normalized_floor > 1.03 * baseline.normalized_floor:
        return 'PASSED_STRONG_BASELINE_NUMERIC_ONLY'
    return 'REJECT_BELOW_OPTIMIZED_KNOWN_BASELINE'


def run_scientist(out: Path, *, n: int = 96, steps: int = 25,
                  seed: int = 7, agent: str = 'heuristic',
                  model: str | None = None, initial_trials: int = 8,
                  literature: bool = False, backend: str = "numpy", gpu_memory_mb: int = 512):
    if steps < 1 or initial_trials < 1:
        raise ValueError('steps and initial_trials must be >= 1')
    if agent not in ('heuristic', 'llm'):
        raise ValueError('agent must be heuristic or llm')
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    sim = AngularSpectrum(OpticalSetup(n=n), np.linspace(.049, .071, 15), backend=backend, gpu_memory_mb=gpu_memory_mb)
    # Reuses old prototype for optimized control scans; previous fair controls
    # must not be retuned on the held-out numerical grid-check.
    result = run_search(sim, seed=seed, trials=initial_trials)
    reference = result['reference_peak']
    strong_control = result['best_known_quartic']
    all_evaluated = list(result['all'])
    scored = [t for t in result['all'] if t.admissible]
    nodes = []
    seen = set(_fingerprint(t.candidate()) for t in all_evaluated)

    # Seed nodes get distinct, root parent_ids; future expansions cite a parent.
    for i, trial in enumerate(result['all']):
        nodes.append({
            'id': f'H{i+1:05d}', 'parent_id': None, 'method': 'seed',
            'hypothesis': 'Initial seeded physical search hypothesis',
            'candidate': trial.candidate().record(), 'trial': trial.record(),
            'critic': _critic(trial, strong_control),
        })

    for step in range(steps):
        ranked = sorted(scored, key=lambda t: t.normalized_floor, reverse=True)
        parent = None
        parent_id = None
        if ranked and rng.random() < .8:
            selected = ranked[int(rng.integers(0, min(4, len(ranked))))]
            parent = selected.candidate()
            target = _fingerprint(parent)
            for node in reversed(nodes):
                x = node['candidate']
                if tuple(round(x[k], 5) for k in ('q2', 'q3', 'q4', 'ripple')) == target:
                    parent_id = node['id']
                    break
        if agent == 'llm':
            leading = [t.record() for t in ranked[:5]]
            proposal, hypothesis = propose_llm(parent, leading, step, model)
        else:
            proposal, hypothesis = propose_heuristic(rng, parent, step)

        signature = _fingerprint(proposal)
        if signature in seen:
            # Duplicate proposals are not double-counted. Record them, so no
            # silently dropped model behavior or manipulated run statistics.
            nodes.append({
                'id': f'H{len(nodes)+1:05d}', 'parent_id': parent_id,
                'method': agent, 'hypothesis': hypothesis,
                'candidate': proposal.record(), 'trial': None,
                'critic': 'DUPLICATE_OF_TESTED_DESIGN',
            })
            continue
        seen.add(signature)
        trial = evaluate(sim, proposal, reference)
        all_evaluated.append(trial)
        if trial.admissible:
            scored.append(trial)
        nodes.append({
            'id': f'H{len(nodes)+1:05d}', 'parent_id': parent_id,
            'method': agent, 'hypothesis': hypothesis,
            'candidate': proposal.record(), 'trial': trial.record(),
            'critic': _critic(trial, strong_control),
        })

    # Use exactly the same control/normalization/validity criteria throughout.
    result['all'] = all_evaluated
    result['ranked'] = sorted(scored, key=lambda t: t.normalized_floor, reverse=True)
    result['best'] = result['ranked'][0]
    checks = check_candidate(sim, result)
    save_csv(out / 'all_trials.csv', result['all'])
    save_csv(out / 'top_candidates.csv', result['ranked'][:20])
    save_csv(out / 'control_trials.csv', result['control_trials'])
    write_figures(sim, result, out)
    refs = None
    lit_error = None
    if literature:
        from .literature import openalex_prior_art
        try:
            refs = openalex_prior_art(result['best'].family)
        except Exception as exc:
            lit_error = str(exc)
    write_report(sim, result, checks, out, seed, len(all_evaluated), refs, lit_error)
    write_json(sim, result, checks, out, seed, len(all_evaluated))
    (out / 'research_tree.json').write_text(json.dumps(nodes, ensure_ascii=False, indent=2), encoding='utf-8')
    with (out / 'research_tree.jsonl').open('w', encoding='utf-8') as f:
        for node in nodes:
            f.write(json.dumps(node, ensure_ascii=False) + '\n')
    winning = result['best']
    summary = f'''# Autonomous structured-light research cycle

**NOT peer reviewed; purely numerical. Novelty: NOT VERIFIED. Publication-ready: NO.**

- Agent: {agent}; seed: {seed}; grid: {n}x{n}; tree nodes: {len(nodes)}.
- Tested unique designs: {len(all_evaluated)}; strong quadratic+quartic control: {strong_control.normalized_floor:.5f}.
- Best candidate: {winning.family} with {winning.normalized_floor:.5f} worst-case normalized on-axis intensity.
- Gain over strong known control: {(winning.normalized_floor/strong_control.normalized_floor-1)*100:+.2f}%.
- Performance gate (including grid refinement/quantization/edge constraints): {checks['performance_gates_pass']}.
- Literature novelty established: **False**, including when optional metadata search is performed.

## Machine critique

{_critic(winning, strong_control)}

## Interpretive caution

A parameter improvement is not a scientific discovery. These simulations are scalar, linear,
idealized and tied to a predeclared metric; peer review and experimental proof are absent.
The top candidate still needs independent numerical validation, nontrivial literature review,
and physically meaningful task metrics before any paper claim.

## Literature search starters

- {FAMILY_PRIOR_ART.get(winning.family, winning.family)}
- Structured light axial intensity mask finite aperture baseline

## Artifacts

See `research_tree.json`, `research_tree.jsonl`, `experiment.json`, `research_brief.md`,
`all_trials.csv`, `control_trials.csv`, `axial_profile.png` and
`phase_and_focal_planes.png`.
'''
    (out / 'agent_research_summary.md').write_text(summary, encoding='utf-8')
    return {
        'best': winning.record(), 'strong_baseline': strong_control.record(),
        'checks': checks, 'nodes': len(nodes), 'trials': len(all_evaluated),
        'summary': str(out/'agent_research_summary.md'),
    }
