"""Parameterized research hypotheses; names intentionally make no novelty claim."""
from dataclasses import dataclass, asdict
import numpy as np


@dataclass(frozen=True)
class Candidate:
    family: str
    q2: float = 0.0
    q3: float = 0.0
    q4: float = 0.0
    ripple: float = 0.0

    def record(self):
        return asdict(self)


def residual_phase(candidate: Candidate, sim):
    u = sim.x / sim.setup.waist_m
    v = sim.y / sim.setup.waist_m
    r2 = u * u + v * v
    return (candidate.q2 * r2
            + candidate.q3 * (u**3 + v**3)
            + candidate.q4 * r2**2
            + candidate.ripple * np.sin(2 * r2))


def sample_candidates(seed, trials):
    """Fixed family inventory; replace with optimizer/agent without touching physics."""
    rng = np.random.default_rng(seed)
    families = ('quartic', 'cubic', 'ripple', 'quadratic_quartic',
                'quadratic_cubic', 'mixed')
    for _ in range(trials):
        family = families[int(rng.integers(len(families)))]
        q2 = q3 = q4 = ripple = 0.0
        if family in ('quadratic_quartic', 'quadratic_cubic', 'mixed'):
            q2 = float(rng.uniform(-0.85, 0.85))
        if family in ('cubic', 'quadratic_cubic', 'mixed'):
            q3 = float(rng.uniform(-0.30, 0.30))
        if family in ('quartic', 'quadratic_quartic', 'mixed'):
            q4 = float(rng.uniform(-0.50, 0.50))
        if family == 'ripple':
            ripple = float(rng.uniform(-0.90, 0.90))
        yield Candidate(family, q2, q3, q4, ripple)


FAMILY_PRIOR_ART = {
    'quartic': 'spherical aberration; quartic phase beam; extended depth of focus',
    'cubic': 'Airy beam; cubic phase mask; wavefront coding',
    'ripple': 'sinusoidal phase mask; multifocal diffractive lens',
    'quadratic_quartic': 'defocus spherical aberration wavefront coding depth of focus',
    'quadratic_cubic': 'cubic phase plate with defocus extended depth of focus',
    'mixed': 'hybrid higher-order phase mask extended depth of focus',
}
