"""Evidence-bound optics writing context, shared by drafting and reflection.

Preparing this context makes no API calls and never builds or edits a manuscript.
"""
from __future__ import annotations

from contextlib import contextmanager
import datetime
import json
from pathlib import Path
import re
import shutil
import subprocess

from .scientist_v2 import INTEGRATION

WRITING = INTEGRATION / 'writing'
TEMPLATE = INTEGRATION / 'preprint1'
AUTHOR = 'AutoPhotonics Project'
SYSTEM = 'AutoPhotonics Scientist'
EDITORIAL_METHOD = WRITING / 'editorial_method.md'
EDITORIAL_METHOD_VERSION = 1


def load_editorial_method() -> str:
    """Read the current project feedback for every new manuscript context."""
    return EDITORIAL_METHOD.read_text(encoding='utf-8')


def load_revision_feedback() -> str:
    """Project-owned assessment shared by the research manager and writer."""
    path = WRITING / 'revision_feedback.md'
    feedback = path.read_text(encoding='utf-8') if path.exists() else ''
    return feedback + '\n\n' + load_editorial_method()


def reserve_paper_call(state: dict, ledger_path: Path) -> int:
    """Share the existing cap with the sequential research-feedback handoff."""
    ledger = json.loads(ledger_path.read_text(encoding='utf-8')) if ledger_path.exists() else {}
    used = max(state['calls'], ledger.get('calls', 0))
    if used >= state['max_api_calls']:
        raise RuntimeError('Paper API budget exhausted')
    state['calls'] = used + 1
    ledger_path.write_text(json.dumps({'calls': state['calls'],
                                     'max_api_calls': max(state['max_api_calls'],ledger.get('max_api_calls',0))}, indent=2), encoding='utf-8')
    return state['calls']

# These equations describe the trusted implementations, not the exemplar papers.
# Numerical regression tests must be updated if physics.py/designs.py change.
EQUATIONS = {
    'eq:input': r'''A_{jk}=\sqrt{\frac{P}{\Delta x^2\sum_{a,b}\exp(-2r_{ab}^2/w_0^2)}}
\exp(-r_{jk}^2/w_0^2),\qquad
U_0(x_j,y_k)=A_{jk}\exp\!\left[i\left(-\frac{k_0r_{jk}^2}{2f}+\phi_{jk}\right)\right]''',
    'eq:phase': r'''u=x/w_0,\quad v=y/w_0,\quad \rho^2=u^2+v^2,\qquad
\phi=q_2\rho^2+q_3(u^3+v^3)+q_4\rho^4+\eta\sin(2\rho^2)''',
    'eq:transfer': r'''H_z(\nu_x,\nu_y)=B_z\exp\!\left[i2\pi z\sqrt{\lambda^{-2}-\nu_x^2-\nu_y^2}\right],\qquad
B_z=\mathbf{1}_{\nu_x^2+\nu_y^2\leq\min(\nu_c^2,\lambda^{-2})},\quad
\nu_c=\frac{\lambda^{-1}}{\sqrt{1+(2z/L)^2}}''',
    'eq:propagation': r'''U_z=\mathcal{F}^{-1}\!\left[\mathcal{F}[U_0]H_z\right],\qquad
I(z)=|U_z(0,0)|^2''',
    'eq:objective': r'''I_{\mathrm{ref}}=\max_{z\in\mathcal{Z}}I_{\mathrm{G}}(z),\qquad
J=\frac{\min_{z\in\mathcal{Z}}I(z)}{I_{\mathrm{ref}}},\quad
J_{\mathrm{peak}}=\frac{\max_{z\in\mathcal{Z}}I(z)}{I_{\mathrm{ref}}},\quad
V=\frac{J}{J_{\mathrm{peak}}}''',
    'eq:retention': r'''R=\min_{z\in\mathcal{Z}}\frac{\sum_{a,b}|\widehat{U}_{0,ab}|^2B_{z,ab}}
{\sum_{a,b}|\widehat{U}_{0,ab}|^2}''',
    'eq:quantization': r'''\phi_{8}=\frac{2\pi}{255}\operatorname{round}\!\left[
\frac{255}{2\pi}(\phi\bmod 2\pi)\right]''',
}


def build_context(evidence: dict, previous_review: dict | None = None) -> tuple[str, dict]:
    """Load the selected, full-text-verified simulation exemplars and run facts."""
    registry = json.loads((WRITING / 'sources.json').read_text(encoding='utf-8'))
    cards = []
    for source in registry['sources']:
        if source['evidence_type'] != 'theory_and_numerical_only' or not source['full_text_checked']:
            raise ValueError('Writing exemplars must be full-text-checked pure simulation/theory papers')
        cards.append((WRITING / source['card']).read_text(encoding='utf-8'))
    rules = (WRITING / 'writing_rules.md').read_text(encoding='utf-8')
    feedback = load_revision_feedback()
    if feedback:
        rules += '\n\n' + feedback
    equations = '\n\n'.join(
        '\\begin{equation}\n' + body + '\n\\label{' + label + '}\n\\end{equation}'
        for label, body in EQUATIONS.items()
    )
    facts = {key: evidence[key] for key in (
        'setup', 'z_m', 'seed', 'objective', 'gaussian', 'best_defocus',
        'best_known_quartic', 'best_candidate', 'diagnostics', 'search_protocol',
    ) if key in evidence}
    # Keep precision so retained spectrum close to one is not described as exactly one.
    for name in ('gaussian', 'best_defocus', 'best_known_quartic', 'best_candidate'):
        if name in facts and 'minimum_retained_power' in facts[name]:
            facts[name] = dict(facts[name])
            facts[name]['lost_spectral_fraction'] = 1 - facts[name]['minimum_retained_power']
    context = (
        rules + '\n\n## Verified writing exemplars (style references, not result evidence)\n\n'
        + '\n\n'.join(cards)
        + '\n\n## Trusted solver equations\n'
        'Source: autophotonics/physics.py, designs.py, discovery.py and report.py. '
        'Use these equations with the listed labels; explain every variable and unit. '
        'They describe a power-normalized scalar field on a finite square grid. '
        'Here k_0=2*pi/lambda, r^2=x^2+y^2, Delta x=L/n; eta is the ripple coefficient. '
        'The square root in H is evaluated on the propagating passband; the kernel is zero outside it. '
        'F is the discrete FFT with its matching inverse. The radial bandwidth truncation is '
        'conservative, not the complete Matsushima passband construction. '
        'Z is the actual finite set of sampled z_m values, not a continuous interval minimization. '
        'Quantization applies to the wrapped residual phase; the lens remains ideal.\n\n'
        + equations + '\n\n## Exact recorded run facts\n'
        + json.dumps(facts, indent=2, ensure_ascii=False)
    )
    if previous_review:
        context += ('\n\n## Previous automatic review to address\n'
                    'Treat missing experiments as missing; writing cannot manufacture them.\n'
                    + json.dumps(previous_review, indent=2, ensure_ascii=False))
    manifest = {
        'author': AUTHOR, 'system_name': SYSTEM, 'template': 'preprint1 / unbranded article',
        'sources': registry['sources'], 'required_equation_labels': list(EQUATIONS),
        'skill_adaptations': ['ccf-humanization', 'ccf-paper-writer', 'ccf-paper-to-exemplar'],
        'solver_sources': ['autophotonics/physics.py', 'autophotonics/designs.py',
                           'autophotonics/discovery.py', 'autophotonics/report.py'],
        'previous_review_included': bool(previous_review),
        'revision_feedback_included': bool(feedback),
        'editorial_method': EDITORIAL_METHOD.name,
        'editorial_method_version': EDITORIAL_METHOD_VERSION,
        'prepared_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    return context, manifest


def prepare_context(run: Path, out: Path, previous: Path | None = None) -> dict:
    """Write auditable future-writer inputs; no models, propagation or TeX."""
    evidence = json.loads((run / 'experiment.json').read_text(encoding='utf-8'))
    # Failed build attempts still consume calls but may have no new review.
    review = None
    visited = set()
    while previous and previous.resolve() not in visited:
        visited.add(previous.resolve())
        review_path = previous / 'automatic_review.json'
        if review_path.exists():
            review = json.loads(review_path.read_text(encoding='utf-8'))
            break
        state_path = previous / 'paper_pipeline.json'
        parent = json.loads(state_path.read_text(encoding='utf-8')).get('previous_paper_run') if state_path.exists() else None
        previous = Path(parent) if parent else None
    if evidence.get('schema')=='pgcd_manuscript_v1':
        from .pgcd.manuscript import build_manuscript_context
        context,manifest=build_manuscript_context(evidence,review)
    else:
        context, manifest = build_context(evidence, review)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'writing_context.md').write_text(context, encoding='utf-8')
    (out / 'writing_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    return manifest


def writing_system_message(context: str) -> str:
    # Upstream calls .format(page_limit=...). Escape literal LaTeX/JSON braces.
    message = (
        'You are the optics manuscript writer for the research system declared below. '
        'Write in the supplied preprint1 template, an unbranded article preprint. '
        'Keep its single-column layout; no ICML style, ML-conference framing, or Impact Statement. '
        'Use only supplied evidence and verified citation keys. Return complete compilable LaTeX '
        'inside a latex code fence. The same requirements apply during every reflection. '
        'The drafting length target is {page_limit} pages; do not pad to reach it.\n\n'
    )
    return message + context.replace('{', '{{').replace('}', '}}')


@contextmanager
def optics_writer(writer, context: str):
    """Select the preprint template without modifying the pinned upstream checkout."""
    original_shutil = writer.shutil
    original_prompt = writer.writeup_system_message_template

    def copytree(src, dst, *args, **kwargs):
        if Path(src).as_posix().rstrip('/').endswith('ai_scientist/blank_icml_latex'):
            src = TEMPLATE
        return original_shutil.copytree(src, dst, *args, **kwargs)

    class ShutilProxy:
        def __getattr__(self, name):
            return getattr(original_shutil, name)

    proxy = ShutilProxy()
    proxy.copytree = copytree
    try:
        writer.shutil = proxy
        writer.writeup_system_message_template = writing_system_message(context)
        yield
    finally:
        writer.shutil = original_shutil
        writer.writeup_system_message_template = original_prompt


def check_writing_contract(tex: str, *, author=AUTHOR, system=SYSTEM, equations=None, related_work=False) -> None:
    """Reject missing author/model definitions instead of silently editing a paper."""
    # Remove ordinary comments while preserving escaped percent characters.
    source = re.sub(r'(?<!\\)%[^\n]*', '', tex)
    failures = []
    if not re.search(r'\\documentclass(?:\[[^]]*\])?\{article\}', source):
        failures.append('Use the supplied unbranded article document class')
    if re.search(r'Optics\s+Express|\\journal\s*\{', source, re.IGNORECASE):
        failures.append('Remove journal branding from this preprint')
    if not re.search(r'\\author\{\s*'+re.escape(author)+r'\s*\}', source):
        failures.append('Set the author to '+author)
    if not re.search(r'pdfauthor\s*=\s*\{'+re.escape(author)+r'\}', source):
        failures.append('Set PDF author metadata to '+author)
    if re.search(r'\\(?:address|email)\s*\{', source):
        failures.append('Omit affiliation and email: none were supplied')
    labels = set(re.findall(r'\\label\{([^}]+)\}', source))
    missing = set(EQUATIONS if equations is None else equations) - labels
    if missing:
        failures.append('Include and explain the trusted solver equations: ' + ', '.join(sorted(missing)))
    if system not in source:
        failures.append('Use '+system+' as the presented system name')
    if related_work and not re.search(r'\\section\*?\{Related [Ww]orks?\}',source):
        failures.append('Include an independent Related Work section with verified citations')
    if re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ufffd]', source):
        failures.append('Repair invalid control characters or corrupted Unicode')
    if failures:
        raise ValueError('\n'.join(failures))


def check_tex_environment() -> None:
    """Fail before spending API calls when the preprint toolchain is incomplete."""
    for command in ('pdflatex', 'bibtex', 'kpsewhich'):
        if not shutil.which(command):
            raise RuntimeError('Missing preprint build tool: ' + command)
    for name in ('article.cls', 'geometry.sty', 'amsmath.sty', 'amssymb.sty',
                 'graphicx.sty', 'booktabs.sty', 'hyperref.sty', 'microtype.sty',
                 'plain.bst', 'cmr10.tfm'):
        result = subprocess.run(['kpsewhich', name], capture_output=True, text=True, timeout=10)
        if result.returncode or not result.stdout.strip():
            raise RuntimeError('Missing preprint build dependency: ' + name)
