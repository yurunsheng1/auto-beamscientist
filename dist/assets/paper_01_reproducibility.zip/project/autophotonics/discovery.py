"""Unbiased baseline-gated screening and reproducible controls."""
import csv
from dataclasses import dataclass, asdict
import numpy as np
from .designs import Candidate, residual_phase, sample_candidates


@dataclass
class Trial:
    family: str
    q2: float
    q3: float
    q4: float
    ripple: float
    normalized_floor: float
    normalized_peak: float
    uniformity: float
    minimum_retained_power: float
    admissible: bool

    def candidate(self):
        return Candidate(self.family, self.q2, self.q3, self.q4, self.ripple)

    def record(self):
        return asdict(self)


def evaluate(sim, candidate, reference_peak, minimum_retention=0.995):
    phase = residual_phase(candidate, sim)
    spectrum = sim.fft2(sim.input_field(phase))
    trace = sim.center_trace_from_spectrum(spectrum)
    keep = float(np.min(sim.input_spectral_retention(spectrum)))
    minimum = float(trace.min() / reference_peak)
    maximum = float(trace.max() / reference_peak)
    return Trial(candidate.family, candidate.q2, candidate.q3, candidate.q4,
                 candidate.ripple, minimum, maximum,
                 minimum / maximum if maximum > 0 else 0.0,
                 keep, bool(keep >= minimum_retention))


def run_search(sim, seed=7, trials=180, minimum_retention=0.995):
    gaussian = Candidate('gaussian_lens')
    reference_trace = sim.center_trace()
    reference_peak = float(reference_trace.max())
    reference_trial = evaluate(sim, gaussian, reference_peak, minimum_retention)
    # Important: allow the elementary defocus-only control to optimize the SAME metric.
    defocus_trials = [evaluate(sim, Candidate('defocus_control', q2=float(q)),
                               reference_peak, minimum_retention)
                      for q in np.linspace(-1.0, 1.0, 101)]
    admissible_defocus = [t for t in defocus_trials if t.admissible]
    best_defocus = max(admissible_defocus, key=lambda t: t.normalized_floor)
    # Harder known-design control: optimized defocus + quartic spherical aberration.
    # This familiar family can already produce extended-depth-of-focus behavior.
    # A candidate must outperform it, not merely an unmodified Gaussian lens.
    quartic_controls = [
        evaluate(sim, Candidate('known_quadratic_quartic_control',
                                q2=float(q2), q4=float(q4)),
                 reference_peak, minimum_retention)
        for q2 in np.linspace(-1.2, 1.2, 21)
        for q4 in np.linspace(-0.6, 0.6, 25)
    ]
    good_quartic = [t for t in quartic_controls if t.admissible]
    best_quartic = max(good_quartic, key=lambda t: t.normalized_floor)
    all_trials = [evaluate(sim, candidate, reference_peak, minimum_retention)
                  for candidate in sample_candidates(seed, trials)]
    eligible = [t for t in all_trials if t.admissible]
    eligible.sort(key=lambda t: t.normalized_floor, reverse=True)
    if not eligible:
        raise RuntimeError('All candidates failed propagation spectrum retention gate')
    return {
        'gaussian': reference_trial,
        'best_defocus': best_defocus,
        'best_known_quartic': best_quartic,
        'best': eligible[0],
        'ranked': eligible,
        'all': all_trials,
        'control_trials': defocus_trials + quartic_controls,
        'baseline_trace': reference_trace,
        'reference_peak': reference_peak,
    }


def save_csv(path, rows):
    if not rows:
        return
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].record().keys()))
        writer.writeheader()
        writer.writerows([row.record() for row in rows])
