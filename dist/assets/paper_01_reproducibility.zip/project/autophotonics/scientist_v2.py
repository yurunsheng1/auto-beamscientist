"""Preparation and structured evaluator boundary for AI Scientist-v2.

This does not launch upstream BFTS or execute any generated program.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess

STATUS = ['SIMULATION_ONLY', 'NOVELTY_NOT_VERIFIED', 'NOT_PUBLICATION_READY']
INTEGRATION = Path(__file__).resolve().parent.parent / 'integrations' / 'ai_scientist_v2'


def prepare(out: Path, upstream: Path, model: str | None = None) -> dict:
    lock = json.loads((INTEGRATION / 'upstream.lock.json').read_text())
    actual = subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != lock['commit']:
        raise ValueError('Upstream commit differs from pinned source')
    if subprocess.check_output(['git', '-C', str(upstream), 'status', '--porcelain'], text=True).strip():
        raise ValueError('Upstream checkout has local changes; review before preparing')
    for name in ['LICENSE', 'launch_scientist_bfts.py', 'bfts_config.yaml']:
        if not (upstream / name).is_file():
            raise ValueError(f'Missing upstream file: {name}')
    idea = {
        'Name': 'finite_aperture_phase_mask_axial_floor',
        'Title': 'Testing phase-only axial intensity shaping against optimized optical controls',
        'Short Hypothesis': 'A bounded phase-mask candidate may improve the minimum on-axis intensity in a fixed 49–71 mm interval over optimized quadratic-plus-quartic controls.',
        'Related Work': 'NOVELTY_NOT_VERIFIED. Prior-art retrieval and human verification remain required.',
        'Abstract': 'Proposed simulation study; no outcomes claimed. Compare phase masks using fixed input power, aperture, wavelength, observation interval and objective. Reject candidates that fail numerical checks or strong optimized controls.',
        'Experiments': [
            'Fix seed, grid, candidate bounds, objective and budgets before outcomes are inspected.',
            'Evaluate Gaussian lens, optimized defocus, and optimized quadratic-plus-quartic controls.',
            'Evaluate validated JSON hypotheses through the trusted AutoPhotonics CUDA simulator.',
            'Require independent propagation checks, mesh/window/z convergence, quantization, perturbations and held-out geometry/wavelength before headline claims.'
        ],
        'Risk Factors and Limitations': [
            'Scalar idealized simulation only; no experimental measurements.',
            'Polynomial phases are not normalized Airy or Pearcey beam generators.',
            'Current validation is incomplete; no publication-readiness claim.',
            'The upstream generated-code executor is not connected to this evaluator.'
        ],
    }
    config = {
        'upstream': lock, 'status': STATUS,
        'integration_status': 'prepared_not_end_to_end_connected',
        'model': model, 'backend': 'cuda', 'n': 128, 'seed': 7,
        'max_hypotheses': 25, 'api_calls_enabled': False,
        'max_api_calls': 0, 'automatic_manuscript_enabled': False,
        'proposal_keys': ['family', 'q2', 'q3', 'q4', 'ripple', 'hypothesis'],
        'disclosure': 'Any future manuscript using AI Scientist-v2 must prominently disclose its use under the upstream license.',
    }
    out.mkdir(parents=True, exist_ok=True)
    (out/'ideas.json').write_text(json.dumps([idea], indent=2)+'\n')
    (out/'integration.json').write_text(json.dumps(config, indent=2)+'\n')
    return config


def evaluate_proposal(proposal: dict, *, n=64, backend='numpy') -> dict:
    """Evaluate one JSON proposal against fixed controls; never accept source code."""
    from .agents import validate_proposal
    from .physics import AngularSpectrum, OpticalSetup
    from .discovery import evaluate, run_search
    import numpy as np
    if not isinstance(proposal, dict) or set(proposal) - {'family', 'q2', 'q3', 'q4', 'ripple', 'hypothesis'}:
        raise ValueError('Only structured hypothesis keys are accepted; code is forbidden')
    candidate, hypothesis = validate_proposal(proposal)
    sim = AngularSpectrum(OpticalSetup(n=n), np.linspace(.049, .071, 15), backend=backend)
    controls = run_search(sim, seed=7, trials=1)
    score = evaluate(sim, candidate, controls['reference_peak'])
    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in Path(__file__).parent.glob('*.py')}
    return {'status': STATUS, 'backend': backend, 'seed': 7, 'n': n,
            'objective': 'minimum on-axis intensity at 49–71 mm / Gaussian peak',
            'hypothesis': hypothesis, 'trial': score.record(),
            'gaussian': controls['gaussian'].record(),
            'optimized_defocus': controls['best_defocus'].record(),
            'optimized_quartic': controls['best_known_quartic'].record(),
            'source_sha256': source_hashes,
            'headline_validation_complete': False}
