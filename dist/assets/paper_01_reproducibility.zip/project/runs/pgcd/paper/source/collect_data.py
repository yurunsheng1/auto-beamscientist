"""Collect existing PGCD arrays and public bibliography; run on the GPU host.

This does not propagate fields, call a language model, or modify experiment data.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import base64
import datetime
import hashlib
import io
import json
import signal
import zipfile
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[4]
RUN = ROOT / 'runs/pgcd_experiments_20261023T185327Z'
DOIS = ['10.1364/OE.20.018955', '10.1088/1367-2630/aa6ecd',
        '10.1364/OE.17.019662']


def metadata(doi):
    url = 'https://api.crossref.org/works/' + doi
    row = {'doi': doi, 'retrieved_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'url': url}
    try:
        req = Request(url, headers={'User-Agent': 'AutoPhotonics-Preprint/0.1'})
        with urlopen(req, timeout=20) as response:
            row['metadata'] = json.load(response)['message']
    except Exception as exc:
        row['error'] = str(exc)
    return row


def main():
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    payload = io.BytesIO()
    provenance = {'source_run': RUN.name, 'files': {}}
    with zipfile.ZipFile(payload, 'w', zipfile.ZIP_DEFLATED) as archive:
        for hid in ('C0096H001', 'C0096H002'):
            q = RUN / 'cycle_0096' / (hid + '.npz')
            raw = q.read_bytes()
            archive.writestr('assets/' + q.name, raw)
            provenance['files'][str(q.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
        for name in ('physics.py', 'pgcd/physics.py', 'pgcd/beams.py', 'pgcd/research_experiment.py'):
            q = RUN / 'source_snapshot/autophotonics' / name
            raw = q.read_bytes()
            archive.writestr('cache/solver_snapshot/' + name, raw)
            provenance['files'][str(q.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
        archive.writestr('cache/source_provenance.json', json.dumps(provenance, indent=2))
        with ThreadPoolExecutor(max_workers=3) as pool:
            refs = list(pool.map(metadata, DOIS))
        archive.writestr('cache/citation_metadata.json', json.dumps(refs, indent=2))
    print('PAPER_ASSETS_ZIP ' + base64.b64encode(payload.getvalue()).decode(), flush=True)


if __name__ == '__main__':
    main()
