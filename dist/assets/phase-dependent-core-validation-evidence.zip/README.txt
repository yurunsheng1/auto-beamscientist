Evidence accompanying Phase-dependent core collection and window sensitivity.
Original summaries are unchanged. Actual follow-up is in confirmation/measurements.json and assessment.json.
The source snapshot records numerical follow-up; the report renderer was subsequently revised for clarity. Its current hash is in report_manifest.json.
Simulation validation only; novelty and mechanism acceptance remain unverified. No model API call logs or credentials are included.
