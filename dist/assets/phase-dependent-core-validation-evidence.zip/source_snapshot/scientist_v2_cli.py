"""Prepare AI Scientist-v2 inputs or evaluate a single structured hypothesis."""
import argparse
import json
import os
from pathlib import Path
from autophotonics.scientist_v2 import prepare, evaluate_proposal, INTEGRATION


def main():
    default_model = os.environ.get('AUTOPHOTONICS_LLM_MODEL', 'deepseek-flash')
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--upstream', type=Path, default=INTEGRATION/'upstream')
    p.add_argument('--out', type=Path, default=Path('runs/scientist_v2_prepared'))
    p.add_argument('--model', default=default_model)
    p = sub.add_parser('evaluate')
    p.add_argument('--proposal', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--backend', choices=['numpy', 'cuda'], default='numpy')
    p.add_argument('--n', type=int, default=64)
    p = sub.add_parser('run')
    p.add_argument('--upstream', type=Path, default=INTEGRATION/'upstream')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--backend', choices=['numpy','cuda'], default='cuda')
    p.add_argument('--model', default=default_model)
    p.add_argument('--n', type=int, default=128)
    p.add_argument('--steps', type=int, default=3)
    p.add_argument('--evaluations-per-arm',type=int,default=0,help='0 for legacy smoke; 32–2048 for matched numerical+LLM search')
    p = sub.add_parser('paper')
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--model',default=default_model)
    p.add_argument('--max-calls',type=int,default=50)
    p.add_argument('--previous-paper-run',type=Path)
    p = sub.add_parser('paper-context', help='Prepare writing instructions only; no API calls or PDF compilation')
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--previous-paper-run', type=Path)
    p = sub.add_parser('followup', help='Run trusted numerical follow-up without model calls')
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--backend',choices=['numpy','cuda'],default='cuda')
    p.add_argument('--seconds',type=int,default=300)
    p.add_argument('--gpu-memory-mb',type=int,default=512)
    p.add_argument('--seeds',type=int,nargs='+',default=[7,17,29])
    p.add_argument('--search-budget',type=int,default=1024)
    p.add_argument('--smoke',action='store_true',help='Engineering test only; not paper evidence')
    p = sub.add_parser('pgcd', help='Bounded compositional research; no publication reproduction')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--backend',choices=['numpy','cuda'],default='numpy')
    p.add_argument('--n',type=int,default=128)
    p.add_argument('--hypotheses',type=int,default=20)
    p.add_argument('--budget',type=int,default=64,help='Fitting attempts per composition and optimized control')
    p.add_argument('--seconds',type=int,default=180)
    p.add_argument('--max-evaluations',type=int,default=3000)
    p.add_argument('--gpu-memory-mb',type=int,default=512)
    p.add_argument('--seed',type=int,default=7)
    p.add_argument('--proposals',type=Path,help='Strict JSON hypotheses; executable content is rejected')
    p.add_argument('--retrieve-literature',action='store_true',help='Refresh known DOI metadata; not novelty verification')
    p.add_argument('--agent',choices=['heuristic','llm'],default='heuristic')
    p.add_argument('--model',default=default_model)
    p = sub.add_parser('pgcd-plan', help='Let the pinned AI Scientist-v2 ideation pipeline choose its own research question')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--model',default=default_model)
    p.add_argument('--max-calls',type=int,default=4)
    p.add_argument('--resume',action='store_true',help='Repair an unfinished model proposal within its existing call allowance')
    p = sub.add_parser('pgcd-loop', help='Outer AI Scientist question/experiment/critic/evolution loop')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--hours',type=float,default=7.)
    p.add_argument('--max-api-calls',type=int,default=1500,help='Cumulative API call limit; 0 disables this limit')
    p.add_argument('--backend',choices=['numpy','cuda'],default='cuda')
    p.add_argument('--n',type=int,default=192)
    p.add_argument('--cases-per-cycle',type=int,default=5)
    p.add_argument('--max-cycles',type=int,default=1000)
    p.add_argument('--max-evaluations',type=int,default=200000)
    p.add_argument('--baseline-budget',type=int,default=32)
    p.add_argument('--initial-plan',type=Path)
    p.add_argument('--model',default=default_model)
    p.add_argument('--offline-batches',type=Path,help='Engineering verification only; no model research assessment')
    p.add_argument('--prior-confirmation',type=Path,help='Completed audited follow-up whose actual results guide the next model-owned question')
    p.add_argument('--prior-run',type=Path,help='Preserve feedback/provenance across a reviewed implementation repair')
    p = sub.add_parser('pgcd-confirm',help='Confirm archived frozen hypotheses and build an evidence PDF; no model calls')
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--backend',choices=['numpy','cuda'],default='cuda')
    p.add_argument('--seconds',type=float,default=900)
    p.add_argument('--max-evaluations',type=int,default=2000)
    p = sub.add_parser('pgcd-deepen',help='AI Scientist continues promising branches through numerical follow-up, writeup and review')
    p.add_argument('--model', default=default_model)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--target-papers',type=int,default=3)
    p.add_argument('--seconds',type=int,default=1800)
    p.add_argument('--max-new-calls',type=int,default=60)
    p.add_argument('--backend',choices=['numpy','cuda'],default='cuda')
    p.add_argument('--n',type=int,default=192)
    p.add_argument('--depth-cycles',type=int,default=2)
    p.add_argument('--initial-plan',type=Path)
    p.add_argument('--resume',action='store_true')
    args = parser.parse_args()
    if args.command == 'pgcd-confirm':
        from autophotonics.pgcd.confirmation import confirm_run
        result=confirm_run(args.source,args.out,backend=args.backend,seconds=args.seconds,max_evaluations=args.max_evaluations)
    elif args.command == 'prepare':
        result = prepare(args.out, args.upstream, args.model)
    elif args.command == 'pgcd-deepen':
        from autophotonics.pgcd.deepening import deepen
        result=deepen(args.source,args.out,target_papers=args.target_papers,seconds=args.seconds,
                      max_new_calls=args.max_new_calls,backend=args.backend,n=args.n,
                      depth_cycles=args.depth_cycles,initial_plan=args.initial_plan,resume=args.resume,model=args.model)
    elif args.command == 'pgcd-loop':
        from autophotonics.pgcd.loop import run_loop
        result=run_loop(args.out,hours=args.hours,max_api_calls=args.max_api_calls,backend=args.backend,
                        n=args.n,cases_per_cycle=args.cases_per_cycle,max_cycles=args.max_cycles,
                        max_evaluations=args.max_evaluations,initial_plan=args.initial_plan,model=args.model,
                        baseline_budget=args.baseline_budget,offline_batches=args.offline_batches,prior_run=args.prior_run,prior_confirmation=args.prior_confirmation)
    elif args.command == 'pgcd-plan':
        from autophotonics.pgcd.planner import plan_research
        result=plan_research(args.out,model=args.model,max_calls=args.max_calls,resume=args.resume)
    elif args.command == 'pgcd':
        from autophotonics.pgcd.runner import run_pgcd
        result=run_pgcd(args.out,backend=args.backend,n=args.n,hypotheses=args.hypotheses,
                        budget=args.budget,seed=args.seed,seconds=args.seconds,
                        max_evaluations=args.max_evaluations,gpu_memory_mb=args.gpu_memory_mb,
                        proposals=args.proposals,retrieve_literature=args.retrieve_literature,
                        agent=args.agent,model=args.model)
    elif args.command == 'followup':
        from autophotonics.followup import run_followup
        result=run_followup(args.run,args.out,backend=args.backend,seconds=args.seconds,
                            gpu_memory_mb=args.gpu_memory_mb,seeds=tuple(args.seeds),
                            search_budget=args.search_budget,smoke=args.smoke)
    elif args.command == 'paper-context':
        from autophotonics.paper_writing import prepare_context
        result=prepare_context(args.run,args.out,args.previous_paper_run)
    elif args.command == 'paper':
        from autophotonics.auto_paper import run_paper
        result=run_paper(args.run,args.out,model=args.model,max_calls=args.max_calls,previous=args.previous_paper_run)
    elif args.command == 'run':
        from autophotonics.scientist_v2_runner import run_v2
        result = run_v2(args.out, upstream=args.upstream, backend=args.backend,
                        model=args.model, n=args.n, steps=args.steps, evaluations_per_arm=args.evaluations_per_arm)
    else:
        result = evaluate_proposal(json.loads(args.proposal.read_text()), n=args.n, backend=args.backend)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
