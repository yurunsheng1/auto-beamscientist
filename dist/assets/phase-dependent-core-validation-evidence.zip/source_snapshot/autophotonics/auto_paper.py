"""Bounded AI Scientist-v2 evidence -> model decision -> writeup -> review pipeline."""
from __future__ import annotations
import contextlib
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import urllib.request
from .scientist_v2 import INTEGRATION, STATUS
from .llm_config import reasoning_options
from .paper_writing import prepare_context, optics_writer, check_writing_contract, check_tex_environment, load_revision_feedback, reserve_paper_call


def check_tex(text, *, require_status=True):
    if re.search(r'\\(?:input|include|openin|openout|write(?:18)?|read|catcode|csname|directlua)\b',text):
        raise ValueError('Unsupported TeX file/process primitive')
    if re.search(r'\\(?:includegraphics|graphicspath)[^\n]*(?:\.\./|/home/|/etc/)',text):
        raise ValueError('Figure paths must remain inside the build directory')
    if 'AI Scientist' not in text or (require_status and 'SIMULATION' not in text):
        raise ValueError('AI and simulation disclosures are missing')


def model_json(text):
    """Decode a complete model JSON value; never invent missing content."""
    value=re.sub(r'^```(?:json)?\s*|\s*```$','',text.strip())
    result,_=json.JSONDecoder().raw_decode(value)
    if not isinstance(result,dict):raise ValueError('Expected one JSON decision object')
    return result


def compile_with_repair(build, repair, *, max_repairs=2):
    """Retry a failed trusted TeX build with bounded model formatting repairs."""
    for attempt in range(max_repairs+1):
        try:
            return build()
        except RuntimeError as exc:
            if attempt==max_repairs:raise
            repair(str(exc))


def run_paper(run: Path, out: Path, *, upstream=INTEGRATION/'upstream', model='deepseek-flash', max_calls=50, previous=None,
              ledger_path=None, global_max_calls=None, deadline_monotonic=None):
    from openai import OpenAI
    if not 1 <= max_calls <= 50:
        raise ValueError('max_calls must be between 1 and 50')
    if out.exists():
        raise ValueError('Use a fresh paper output directory')
    check_tex_environment()
    out.mkdir(parents=True)
    run=run.resolve();out=out.resolve();upstream=upstream.resolve()
    sys.path.insert(0,str(upstream))
    prior=json.loads((Path(previous)/'paper_pipeline.json').read_text()) if previous else {}
    ledger_path=Path(ledger_path) if ledger_path else out.parent/'paper_api_budget.json'
    ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else {}
    cap=global_max_calls if global_max_calls is not None else ledger.get('max_api_calls',max_calls)
    state={'status':'running','stage':'evidence','model':model,'max_api_calls':cap,
           'local_call_limit':max_calls,'local_calls':0,
           'calls':max(prior.get('calls',0),ledger.get('calls',0)),'previous_paper_run':str(previous) if previous else None,'scientific_status':STATUS,'source_run':str(run),
           'components':['upstream writeup.perform_writeup','upstream perform_llm_review.perform_review'],
           'adaptations':['bounded DeepSeek Responses routing','restricted TeX compiler','verified metadata citations','single reflection/review']}
    def save():
        state['updated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (out/'paper_pipeline.json').write_text(json.dumps(state,indent=2))
        print('PIPELINE_STAGE',state['stage'],'calls',state['calls'],flush=True)
    save()
    evidence=json.loads((run/'experiment.json').read_text())
    pgcd=evidence.get('schema')=='pgcd_manuscript_v1'
    brief=(run/'research_brief.md').read_text()
    state['writing']=prepare_context(run,out,Path(previous) if previous else None)
    writing_context=(out/'writing_context.md').read_text(encoding='utf-8')
    save()
    client=OpenAI(timeout=75,max_retries=0)
    def contract(text):
        check_tex(text,require_status=not pgcd)
        if pgcd:
            check_writing_contract(text,author=state['writing']['author'],system=state['writing']['system_name'],
                                   equations=state['writing']['required_equation_labels'],related_work=True)
        else:check_writing_contract(text)
    def call(prompt,system='',history=None,tokens=24000):
        if state['local_calls']>=max_calls:raise RuntimeError('This manuscript reached its local API-call ceiling')
        if deadline_monotonic is not None and time.monotonic()>=deadline_monotonic:raise RuntimeError('Research-to-paper time ceiling reached')
        state['local_calls']+=1
        reserve_paper_call(state,ledger_path);save()
        inputs=list(history or [])+[{'role':'user','content':prompt}]
        response=client.responses.create(model=model,instructions=system,input=inputs,
                                        max_output_tokens=tokens,reasoning=reasoning_options(),
                                        timeout=min(75.,max(1.,deadline_monotonic-time.monotonic())) if deadline_monotonic else 75.)
        text=response.output_text
        (out/f'call_{state["calls"]:02d}.json').write_text(json.dumps({'stage':state['stage'],'model':model,
            'prompt':prompt,'system':system,'response':text,'response_status':response.status,'usage':response.usage.model_dump() if response.usage else None},indent=2))
        if response.status=='incomplete':
            if tokens<32000:
                return call(prompt+'\nYour previous output was truncated. Return a complete but concise document, including all closing delimiters.',system,history,tokens=32000)
            raise RuntimeError('Model response still truncated at maximum output budget')
        return text,inputs+[{'role':'assistant','content':text}]
    try:
        state['stage']='automatic_decision';save()
        decision_text,_=call('Evaluate this real optical simulation evidence. Choose whether to write an honest draft now or stop. '
            'A draft can report preliminary numerical findings and missing evidence; it is not a publication-readiness decision. '
            'Return only JSON with action (write_draft or stop), reasons (list), required_followup (list).\n'+brief
            +('\nFor this PGCD portfolio, assess whether the central scientific question is distinct from other_manuscripts in the evidence. Include independent_question (boolean) in your JSON. A target manuscript count must not force duplicate manuscripts or fabricate positive findings. Write directly from the physical problem and observed results.' if pgcd else '')
            +'\nProject revision feedback: distinguish prose improvements from missing research evidence.\n'+load_revision_feedback(),
            'You are the AI Scientist research manager. Decide from evidence, not user pressure. Never invent results or novelty.',tokens=2048)
        for repair in range(3):
            try:
                decision=model_json(decision_text);break
            except (ValueError,TypeError):
                if repair==2:raise
                decision_text,_=call('Repair ONLY the JSON formatting of your manuscript decision below. Preserve its action, scientific reasons and independent_question assessment. Return one complete concise JSON object, with no surrounding prose. Do not change an unfavorable result to satisfy the manuscript target.\n'+decision_text,
                                     'You repair structured output without changing scientific decisions.',tokens=8192)
        (out/'automatic_decision.json').write_text(json.dumps(decision,indent=2))
        if decision.get('action')!='write_draft' or (pgcd and decision.get('independent_question') is not True):
            state.update(status='stopped_by_model',stage='finished');save();return state
        state['stage']='citation_metadata';save()
        refs=[]
        queries=['phase only mask extended depth of focus quartic spherical aberration','wavefront coding extended depth of field cubic phase']
        urls=[] if pgcd else ['https://api.crossref.org/works/10.1364/OE.17.019662']
        from urllib.parse import urlencode
        if not pgcd:urls += ['https://api.crossref.org/works?'+urlencode({'query':q,'rows':2}) for q in queries]
        retrieval=[]
        for url in urls:
            try:
                req=urllib.request.Request(url,headers={'User-Agent':'AutoPhotonics-research-prototype/0.1'})
                with urllib.request.urlopen(req,timeout=15) as response:data=json.load(response)
                rows=data['message'].get('items',[data['message']])
                for row in rows:
                    if row.get('DOI') and row.get('title') and row['DOI'] not in {r['DOI'] for r in refs}:refs.append(row)
                retrieval.append({'url':url,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'retrieved'})
            except Exception as exc:retrieval.append({'url':url,'error':str(exc)})
        (out/'retrieved_references.json').write_text(json.dumps({'records':refs,'retrieval':retrieval,'scope':'metadata only, not full-text verification'},indent=2))
        def esc(s):return str(s).replace('&',r'\&').replace('_',r'\_').replace('%',r'\%')
        bib=[]
        for i,row in enumerate(refs):
            authors=' and '.join(esc(x.get('family','')+', '+x.get('given','')) for x in row.get('author',[]))
            year=row.get('published',row.get('issued',{})).get('date-parts',[[None]])[0][0]
            bib.append('@article{ref'+str(i)+',\n title={'+esc(row['title'][0])+'},\n author={'+authors+'},\n year={'+str(year or '')+'},\n doi={'+row['DOI']+'}\n}')
        bib.append('@misc{aiscientistv2, title={The AI Scientist-v2}, howpublished={https://github.com/SakanaAI/AI-Scientist-v2}}')
        if pgcd:
            bib=[(run/'verified_metadata.bib').read_text()]
        (out/'verified_metadata.bib').write_text('\n'.join(bib))
        allowed=set(re.findall(r'@\w+\{([^,]+),','\n'.join(bib)))
        logs=out/'logs/0-run';logs.mkdir(parents=True)
        baselines={'optimized_classical_controls':evidence['controls']} if pgcd else {k:evidence[k] for k in ['gaussian','best_defocus','best_known_quartic','search_protocol']}
        for name,data in [('baseline_summary',{'best node':{'analysis':json.dumps(baselines)}}),
                          ('research_summary',{'best node':{'analysis':brief,'overall_plan':json.dumps(decision)}}),('ablation_summary',[])]:
            (logs/(name+'.json')).write_text(json.dumps(data,indent=2))
        idea=('Model-selected PGCD research question: '+evidence['question'] if pgcd else 'Optical simulation study of phase-only axial intensity shaping.')+'\n'+brief+'\nAutomatic manager decision:\n'+json.dumps(decision)+'\nVerified citation metadata (not full-text review):\n'+'\n'.join(bib)
        (out/'idea.md').write_text(idea)
        figures=out/'figures';figures.mkdir()
        for name in evidence.get('figure_files',['axial_profile.png','phase_and_focal_planes.png']):
            if Path(name).name!=name:raise ValueError('Figure must be a local basename')
            shutil.copy2(run/name,figures/name)
        from ai_scientist import perform_writeup as writer
        from ai_scientist import perform_llm_review as reviewer
        def response_adapter(*args,**kwargs):
            prompt=kwargs.get('prompt',kwargs.get('msg',args[0] if args else ''))
            system=kwargs.get('system_message','')
            result=call(prompt,system,kwargs.get('msg_history'))
            if state['stage']=='upstream_writeup':
                # Ask the writer to fix omissions; never hand-edit its paper.
                for attempt in range(3):
                    match=re.search(r'```latex(.*?)```',result[0],re.DOTALL)
                    if not match:
                        if 'I am done' in result[0] and kwargs.get('msg_history'):
                            return result
                        error='Return the entire manuscript inside a latex code fence.'
                    else:
                        try:
                            contract(match[1])
                            return result
                        except ValueError as exc:error=str(exc)
                    if attempt==2:
                        raise ValueError('Writer contract still fails after two repairs: '+error)
                    result=call('Repair these manuscript contract issues and return complete LaTeX:\n'+error,
                                system,result[1])
            return result
        def factory(*args,**kwargs):return client,model
        def compile_safe(cwd,pdf_file,timeout=30):
            cwd=Path(cwd)
            shutil.copytree(figures,cwd/'figures',dirs_exist_ok=True)
            # Upstream reflections sometimes use a supplied figure's basename.
            # Both supported relative layouts refer only to verified local figures.
            for figure in figures.iterdir():
                if figure.is_file():shutil.copy2(figure,cwd/figure.name)
            env=os.environ.copy();env['openin_any']='p';env['openout_any']='p'
            def build():
                text=(cwd/'template.tex').read_text().replace('../figures/','figures/')
                (cwd/'template.tex').write_text(text)
                contract(text)
                cited={key.strip() for group in re.findall(r'\\cite[a-zA-Z]*\*?(?:\[[^]]*\])?\{([^}]+)\}',text) for key in group.split(',')}
                if cited-allowed:
                    raise ValueError('Unverified citation keys: '+','.join(sorted(cited-allowed)))
                for cmd in [['pdflatex','-no-shell-escape','-halt-on-error','-interaction=nonstopmode','template.tex'],['bibtex','template'],['pdflatex','-no-shell-escape','-halt-on-error','-interaction=nonstopmode','template.tex'],['pdflatex','-no-shell-escape','-halt-on-error','-interaction=nonstopmode','template.tex']]:
                    result=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True,timeout=timeout)
                    with (out/'latex_build.log').open('a') as f:f.write(result.stdout+result.stderr)
                    if result.returncode:raise RuntimeError('TeX build failed:\n'+(result.stdout+result.stderr)[-6000:])
                shutil.copy2(cwd/'template.pdf',pdf_file)
            def repair(error):
                text=(cwd/'template.tex').read_text()
                fixed,_=call('Repair ONLY the LaTeX compilation error below. Preserve all scientific claims, numbers, equations, citations and conclusions. Use only supplied figure files; a figure may be addressed as figures/<basename> or <basename>. Return the complete corrected document inside a latex code fence.\nError:\n'+error+'\nManuscript:\n'+text,
                             'You repair TeX formatting without changing scientific evidence.')
                match=re.search(r'```latex(.*?)```',fixed,re.DOTALL)
                if not match:raise ValueError('Compiler repair omitted complete LaTeX')
                contract(match[1])
                (cwd/'template.tex').write_text(match[1])
            compile_with_repair(build,repair)
        writer.create_client=factory
        writer.get_response_from_llm=response_adapter
        writer.create_vlm_client=factory
        writer.generate_vlm_img_review=lambda img,*a:{'Img_description': 'Trusted simulation figure '+Path(img['images'][0]).name+'. Values and interpretation must follow the supplied numerical report.'}
        writer.compile_latex=compile_safe
        writer.detect_pages_before_impact=lambda *a,**k:None
        reviewer.get_response_from_llm=response_adapter
        state['stage']='upstream_writeup';save()
        original_cwd=Path.cwd()
        try:
            os.chdir(upstream)
            with optics_writer(writer,writing_context):
                success=writer.perform_writeup(str(out),num_cite_rounds=0,small_model=model,big_model=model,n_writeup_reflections=1,page_limit=6)
        finally:os.chdir(original_cwd)
        if not success:raise RuntimeError('Upstream writeup did not produce a PDF; inspect logs')
        pdfs=sorted(out.glob('*.pdf'),key=lambda p:p.stat().st_mtime)
        pdf=pdfs[-1];shutil.copy2(pdf,out/'preprint1.pdf')
        shutil.copy2(pdf,out/'manuscript.pdf')  # compatibility with existing consumers
        shutil.copy2(out/'latex/template.tex',out/'preprint1.tex')
        shutil.copy2(out/'latex/template.tex',out/'manuscript.tex')
        state['stage']='upstream_automatic_review';save()
        paper=reviewer.load_paper(str(out/'preprint1.pdf'))
        review=reviewer.perform_review(paper,model,client,num_reflections=1,num_fs_examples=0,num_reviews_ensemble=1,
            reviewer_system_prompt='You are an automated optical research reviewer. Attempt to disprove the claims. Your recommendation is an AI assessment, not a venue decision. Compare the supplied evidence to the manuscript, especially the equations, normalization and numerical protocol. Treat exemplar papers as style references, not evidence for this run. Require honest novelty and simulation disclosures.\n'+brief+'\n'+writing_context)
        if not isinstance(review,dict):raise RuntimeError('Automatic review was not valid JSON')
        (out/'automatic_review.json').write_text(json.dumps({'kind':'AI recommendation, not a real venue decision','review':review},indent=2))
        state.update(status='completed',stage='finished',model_review_decision=review.get('Decision'),manuscript=str(out/'preprint1.pdf'))
        save();return state
    except BaseException as exc:
        state.update(status='failed',error=str(exc));save();raise
