"""Constrained idea agents for light-field parameter search.

Agent outputs are finite numeric coefficients in an allowlisted phase DSL.
They are never treated as executable Python code. The deterministic agent
requires no API key; the optional language-model agent requires `openai`.
"""
from __future__ import annotations
import json
import os
from dataclasses import asdict
from typing import Optional
import numpy as np
from .designs import Candidate, sample_candidates
from .llm_config import reasoning_options

BOUNDS = {
    'q2': (-1.2, 1.2),
    'q3': (-0.4, 0.4),
    'q4': (-0.7, 0.7),
    'ripple': (-1.0, 1.0),
}
FAMILIES = ('quartic', 'cubic', 'ripple', 'quadratic_quartic', 'quadratic_cubic', 'mixed')


def validate_proposal(data: dict) -> tuple[Candidate, str]:
    if not isinstance(data, dict):
        raise ValueError('Proposal must be a JSON object')
    family = str(data.get('family', 'mixed'))
    if family not in FAMILIES:
        raise ValueError('Unknown phase family')
    values = {}
    for name, (lo, hi) in BOUNDS.items():
        raw = data.get(name, 0.0)
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f'{name} must be numeric')
        val = float(raw)
        if not np.isfinite(val) or not lo <= val <= hi:
            raise ValueError(f'{name} outside safe configured bounds')
        values[name] = val
    hypothesis = str(data.get('hypothesis', 'Test a constrained phase-only beam modulation.'))
    return Candidate(family, **values), hypothesis[:320]


def propose_heuristic(rng: np.random.Generator, parent: Optional[Candidate],
                      step: int) -> tuple[Candidate, str]:
    if parent is None or (step % 5 == 0):
        seed = int(rng.integers(0, 2**31 - 1))
        candidate = next(sample_candidates(seed, 1))
        return candidate, 'Explore an independent, physically bounded phase-mask family.'
    coeffs = asdict(parent)
    # Evolve a parent by mutating one or two coefficients. Include a 20% chance
    # to mutate a coefficient previously equal to zero (family crossover).
    names = rng.choice(list(BOUNDS), size=int(rng.integers(1, 3)), replace=False)
    scale = max(.025, .22 / (1 + step / 35))
    for name in names:
        lo, hi = BOUNDS[str(name)]
        coeffs[str(name)] = float(np.clip(coeffs[str(name)] + rng.normal(0, scale), lo, hi))
    if rng.random() < .2:
        coeffs['family'] = 'mixed'
    return Candidate(**coeffs), 'Modify a promising ancestor; compare against optimized known controls.'


def propose_llm(parent: Optional[Candidate], top_trials: list[dict],
                step: int, model: Optional[str] = None, *, baseline_context: dict | None = None) -> tuple[Candidate, str]:
    """Call the Responses API once to propose a JSON hypothesis, never Python.

    This path is opt-in: requires OPENAI_API_KEY + package `openai`.
    API/model expenses are the user's responsibility.
    """
    if not os.environ.get('OPENAI_API_KEY'):
        raise RuntimeError('OPENAI_API_KEY is needed for --agent llm')
    if not (model or os.environ.get('AUTOPHOTONICS_LLM_MODEL')):
        raise RuntimeError('Set AUTOPHOTONICS_LLM_MODEL or pass --model')
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError('Install optional extra with: pip install openai') from exc
    system = (
        'You are a skeptical optics research ideation assistant. Propose exactly '
        'one testable phase-only design in JSON: keys family, q2, q3, q4, '
        'ripple, hypothesis. Use ONLY allowed family names and numeric bounds. '
        'Do not claim novelty, experimental verification, or publication readiness. '
        'No code, shell commands, imports, citations, markdown, or prose outside JSON.'
    )
    prompt = json.dumps({
        'step': step,
        'family_choices': FAMILIES,
        'bounds': BOUNDS,
        'parent': asdict(parent) if parent else None,
        'leading_results': top_trials[:5],
        'fixed_baselines_and_feedback': baseline_context,
        'strategy': 'Use actual measured scores. Avoid repeating poor candidates; explain a physical reason for the proposed change.',
        'objective': 'maximize worst-case on-axis intensity over fixed 49–71 mm z-window, at fixed power',
        'requirement': 'Recommend a physically distinguishable testable hypothesis, not a conclusion.'
    })
    response = OpenAI(timeout=45.0, max_retries=0).responses.create(
        model=(model or os.environ['AUTOPHOTONICS_LLM_MODEL']),
        instructions=system,
        input=prompt,
        max_output_tokens=4096,
        reasoning=reasoning_options(),
    )
    raw = response.output_text.strip()
    if raw.startswith('```'):
        raw = raw.split('\n', 1)[-1].rsplit('```', 1)[0].strip()
    return validate_proposal(json.loads(raw))
