"""Fixed numerical follow-up of frozen hypotheses; never a novelty decision."""
from __future__ import annotations
from dataclasses import asdict, replace
from pathlib import Path
import hashlib
import json
import time
import numpy as np
from ..designs import Candidate, residual_phase
from .journal import BudgetStop, EvaluationJournal
from .research_experiment import ResearchBatch, ResearchExperiment
from .schemas import Beam


POLICY = {
    'version': 1, 'max_cases_per_cycle': 20,
    'reference_n': 384, 'mesh_n': 256,
    'relative_tolerance': .02, 'fraction_absolute_tolerance': .002,
    'ratio_absolute_tolerance': .01, 'distance_absolute_tolerance_m': 3.125e-6,
    'window_extent_m': .0036, 'second_window_extent_m': .0048,
    'quantization_levels': 256, 'held_out_wavelength_m': 640e-9,
    'noise_seeds': [107, 109], 'noise_rms_rad': .02,
    'purpose': 'Numerical reproducibility and robustness, not novelty or mechanism acceptance.',
}


def write(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def compact(record):
    return {k: record[k] for k in ('hypothesis', 'comparison', 'checks', 'executed_setup',
            'coherent_cancellation', 'equivalence', 'error') if k in record} | {
        'arm_metrics': {a: v['metrics'] for a, v in record.get('arms', {}).items()}}


def absolute_tolerance(batch, policy, *,arm_value=False):
    if batch.effect != 'difference' and not arm_value:
        return policy['ratio_absolute_tolerance']
    if batch.observable.endswith('_m'):
        return policy['distance_absolute_tolerance_m']
    return policy['fraction_absolute_tolerance']


def stable(a, b, batch, policy):
    """Require finite, testable effects AND the actual compared observables."""
    if not a or not b or not all(a.get('checks', {}).values()) or not all(b.get('checks', {}).values()):
        return False
    ca, cb = a.get('comparison', {}), b.get('comparison', {})
    if not ca.get('testable') or not cb.get('testable'):
        return False
    pairs = [(ca.get('effect'), cb.get('effect'), absolute_tolerance(batch, policy))]
    va, vb = ca.get('comparison_values', []), cb.get('comparison_values', [])
    if len(va) != 2 or len(vb) != 2:
        return False
    pairs += [(x, y, absolute_tolerance(batch, policy, arm_value=True)) for x, y in zip(va, vb)]
    return all(x is not None and y is not None and np.isfinite([x, y]).all() and
               abs(x-y) <= atol + policy['relative_tolerance'] * max(abs(x), abs(y))
               for x, y, atol in pairs)


def assess(batch, measurements, policy=POLICY):
    """Turn performed measurements into gates; missing/failed probes never pass."""
    ref = measurements.get('reference')
    pairs = {'mesh_convergence': ('mesh', 'reference'),
             'window_convergence': ('reference', 'window'),
             'second_window_convergence': ('window', 'second_window'),
             'z_convergence': ('reference', 'z_grid'),
             'independent_observable_validation': ('reference', 'fresnel')}
    checks = {name: stable(measurements.get(a), measurements.get(b), batch, policy)
              for name, (a, b) in pairs.items()}
    checks['reference_physics'] = bool(ref and ref.get('checks') and all(ref['checks'].values()) and
                                       ref.get('comparison', {}).get('testable'))
    robustness = {name: stable(ref, measurements.get(name), batch, policy)
                  for name in ('quantization', 'held_out_wavelength', 'noise_107', 'noise_109')}
    checks['coupled_stochastic_realization'] = not (
        (batch.comparison=='perturbed_vs_clean' and batch.phase_noise_rms>0) or
        any(h.environment.kind=='phase_screen' and h.environment.phase_rms>0 for h in batch.cases))
    numerical_valid = all(checks.values())
    effect = ref.get('comparison', {}).get('effect') if ref else None
    errors = [abs(effect-m['comparison']['effect']) for label, m in measurements.items()
              if label in ('mesh', 'window', 'second_window', 'z_grid', 'fresnel') and effect is not None
              and m.get('comparison', {}).get('effect') is not None]
    uncertainty = max([absolute_tolerance(batch, policy)] + errors)
    margin = None if effect is None else (effect-batch.threshold if batch.direction == '>=' else batch.threshold-effect)
    # The error floor prevents a zero effect satisfying >=0 from becoming a discovery candidate.
    supported = bool(numerical_valid and margin is not None and margin > uncertainty)
    null = 1. if batch.effect == 'ratio' else 0.
    resolved = bool(numerical_valid and effect is not None and abs(effect-null) > uncertainty)
    return {'checks': checks, 'robustness_checks': robustness, 'numerical_valid': numerical_valid,
            'robustness_validated': all(robustness.values()), 'prediction_supported_with_error_margin': supported,
            'resolved_nonnull_effect': resolved, 'effect': effect,
            'numerical_error_floor': uncertainty, 'prediction_margin': margin,
            'status': 'numerically_reproduced' if numerical_valid else 'unconfirmed',
            'novelty_verified': False, 'mechanism_confirmed': False,
            'scope': 'Numerical reproduction of the frozen scalar comparison. Robustness is reported separately; no discovery acceptance.'}


def confirm_cycle(cycle, journal, *,backend='cuda', check=lambda: None, policy=None, progress=lambda _: None):
    """Execute a persistent queue before the model can move to another question."""
    cycle = Path(cycle); policy = dict(POLICY if policy is None else policy)
    batch = ResearchBatch.from_dict(json.loads((cycle/'frozen_protocol.json').read_text()))
    records = json.loads((cycle/'experiment_summary.json').read_text())
    directory = cycle/'confirmation'; directory.mkdir(exist_ok=True)
    protocol = {'policy': policy, 'source_protocol_sha256': hashlib.sha256((cycle/'frozen_protocol.json').read_bytes()).hexdigest(),
                'frozen_science': batch.record(), 'selection': 'Source order, testable nonidentity effects or failed numerical gates; all supported source cases up to the interface maximum of twenty. Negative predictions remain eligible.',
                'no_reoptimization': True}
    protocol=json.loads(json.dumps(protocol))
    protocol_path = directory/'validation_protocol.json'
    if protocol_path.exists() and json.loads(protocol_path.read_text()) != protocol:
        raise ValueError('Confirmation configuration differs from its frozen protocol')
    if not protocol_path.exists(): write(protocol_path, protocol)
    queue = []
    for record in records:
        comp = record.get('comparison', {})
        coherent_comparison = batch.comparison.startswith('coherent_')
        failed_basics = bool(record.get('checks')) and not all(record['checks'].values())
        if record.get('error') or (coherent_comparison and record.get('coherent_cancellation')):
            reason = 'execution_error_or_zero_power_comparison'
        elif coherent_comparison and record.get('equivalence', {}).get('known_identity'):
            reason = 'known_identity'
        elif not comp.get('testable') and not failed_basics:
            reason = 'untestable_observable'
        elif all(record.get('checks', {}).values()) and abs(comp['effect']-(1. if batch.effect=='ratio' else 0.)) <= absolute_tolerance(batch, policy):
            reason = 'unresolved_null_control'
        else:
            reason = None
        queue.append({'hypothesis_id': record['hypothesis']['id'], 'status': 'skipped' if reason else 'pending', 'reason': reason})
    eligible = [q for q in queue if q['status']=='pending']
    for q in eligible[policy['max_cases_per_cycle']:]:q.update(status='deferred',reason='per_cycle_confirmation_allowance')
    queue_path = directory/'queue.json'; write(queue_path, queue)
    results = []
    controls = json.loads((cycle/'optimized_controls.json').read_text()) if (cycle/'optimized_controls.json').exists() else {}
    rn = policy['reference_n']; dx = .0024/rn
    for item in queue:
        if item['status']!='pending':continue
        hid = item['hypothesis_id']; h = next(h for h in batch.cases if h.id==hid)
        target = directory/hid; target.mkdir(exist_ok=True)
        measurements = {}; item['status']='running'; write(queue_path, queue)
        conditions = [('mesh', policy['mesh_n'], .0024, 'asm', {}),
                      ('reference', rn, .0024, 'asm', {}),
                      ('window', int(round(policy['window_extent_m']/dx)), policy['window_extent_m'], 'asm', {}),
                      ('second_window', int(round(policy['second_window_extent_m']/dx)), policy['second_window_extent_m'], 'asm', {}),
                      ('fresnel', rn, .0024, 'fresnel', {}),
                      ('z_grid', rn, .0024, 'asm', {}),
                      ('quantization', rn, .0024, 'asm', {'quantize': True}),
                      ('held_out_wavelength', rn, .0024, 'asm', {'phase_wavelength_ratio':633/640}),
                      ('noise_107', rn, .0024, 'asm', {}), ('noise_109', rn, .0024, 'asm', {})]
        for label, n, extent, solver, options in conditions:
            check(); progress('confirmation_'+label)
            def compute(label=label,n=n,extent=extent,solver=solver,options=options):
                try:
                    e = ResearchExperiment(batch,n=n,extent=extent,backend=backend,
                          wavelength=policy['held_out_wavelength_m'] if label=='held_out_wavelength' else 633e-9)
                    if label=='z_grid':e.engine=e.engine.variant(z_m=np.linspace(batch.z_start_m,batch.z_end_m,2*batch.z_planes-1))
                    kwargs = dict(options)
                    if label.startswith('noise_'):
                        field=e.engine.input(h)[1]
                        noise=np.random.default_rng(int(label.split('_')[1])).normal(size=field.shape)
                        kwargs['field_override']=field*np.exp(1j*policy['noise_rms_rad']*noise)
                    return compact(e.evaluate(h,save=target/(label+'.npz'),propagator=solver,**kwargs))
                except (ValueError, FloatingPointError) as exc:
                    return {'error':type(exc).__name__+': '+str(exc),'checks':{'execution':False},'comparison':{'testable':False,'effect':None}}
            row=journal.run(f'{cycle.name}/confirmation/{hid}/{label}',compute)
            measurements[label]=row;write(target/'measurements.json',measurements)
        assessment=assess(batch,measurements,policy)
        # Re-evaluate each frozen optimized control at the reference grid: no refitting.
        verified_controls={}
        for name,control in controls.items():
            if not control.get('best'):continue
            check()
            def compute_control(control=control):
                e=ResearchExperiment(batch,n=rn,backend=backend)
                base=replace(h,beam=Beam('gaussian',300e-6),transformations=())
                field=e.engine.input(base)[1]*np.exp(1j*residual_phase(Candidate(**control['best']['parameters']),e.engine.sim))
                return compact(e.evaluate(base,field_override=field))
            verified_controls[name]=journal.run(f'{cycle.name}/confirmation/{hid}/control/{name}',compute_control)
        write(target/'controls.json',verified_controls)
        assessment.update(hypothesis_id=hid,control_checks_passed=bool(verified_controls) and all(
            c.get('comparison',{}).get('testable') and all(c.get('checks',{}).values()) for c in verified_controls.values()),
            control_scope='Frozen previously optimized parameters, re-evaluated under this hypothesis composition and environment. No superiority or mechanism conclusion is inferred.')
        write(target/'assessment.json',assessment)
        item.update(status='completed',result=assessment['status']);write(queue_path,queue)
        results.append(assessment)
    summary={'policy_version':policy['version'],'queue':queue,'results':results,
             'completed':len(results),'numerically_reproduced':sum(r['numerical_valid'] for r in results),
             'novelty_verified':False}
    write(directory/'summary.json',summary)
    return summary


def confirm_run(source, out, *,backend='cuda',seconds=900,max_evaluations=2000):
    """Revisit archived cycles without editing their original measurements."""
    source=Path(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    if (out/'confirmation_run.json').exists():raise ValueError('Use a fresh confirmation output directory')
    import platform,shutil,subprocess
    root=Path(__file__).resolve().parents[2]
    sources=list((root/'autophotonics').rglob('*.py'))+[root/'scientist_v2_cli.py']
    code={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
    for p in sources:
        dest=out/'source_snapshot'/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
    write(out/'environment.json',{'python':platform.python_version(),'numpy':np.__version__,'backend':backend,'commit':commit,'source_sha256':code})
    journal=EvaluationJournal(out,max_evaluations,seconds);started=time.monotonic()
    write(out/'confirmation_run.json',{'source':str(source.resolve()),'policy':POLICY,'status':'running'})
    summaries=[]
    def check():
        if (out/'STOP').exists():raise BudgetStop('Stop requested')
        journal.check()
    try:
        for cycle in sorted(source.glob('cycle_*')):
            if not (cycle/'experiment_summary.json').exists():continue
            import shutil
            dest=out/cycle.name;dest.mkdir()
            for name in ('frozen_protocol.json','experiment_summary.json','optimized_controls.json','scientific_critique.json','adopted_model_plan.json'):
                if (cycle/name).exists():shutil.copyfile(cycle/name,dest/name)
            check();summary=confirm_cycle(dest,journal,backend=backend,check=check)
            summaries.append({'cycle':cycle.name,**summary})
        status='completed'
    except BudgetStop as exc:status='stopped: '+str(exc)
    result={'source':str(source.resolve()),'policy':POLICY,'status':status,'cycles':summaries,
            'physics_evaluations':journal.attempts,'elapsed_seconds':time.monotonic()-started,
            'novelty_verified':False}
    write(out/'confirmation_run.json',result)
    from .evidence_report import build_evidence_pdf
    result['pdf']=str(build_evidence_pdf(out))
    write(out/'confirmation_run.json',result)
    return result
