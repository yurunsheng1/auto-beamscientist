"""Build an evidence-only research PDF from performed numerical measurements."""
from __future__ import annotations
from pathlib import Path
import datetime
import json
import textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from .confirmation import POLICY, write
from .research_experiment import COMPARISONS


COLORS = {'ink':'#172c43','blue':'#176b95','green':'#13795b','red':'#ad343e','gray':'#5a6674'}


def number(value):
    return 'not defined' if value is None else f'{value:.6g}'


def page(pdf, title, paragraphs, *, subtitle=None):
    """Flow paragraphs across pages, retaining full text rather than clipping."""
    fig=None; y=0
    def start(continued=False):
        nonlocal fig,y
        fig=plt.figure(figsize=(8.27,11.69),facecolor='white')
        fig.text(.085,.945,title+(' (continued)' if continued else ''),size=17,weight='bold',color=COLORS['ink'])
        if subtitle:fig.text(.085,.914,subtitle,size=9,color=COLORS['gray'])
        fig.text(.085,.035,'AutoPhotonics | Simulation evidence | Novelty not verified',size=8,color=COLORS['gray'])
        y=.875
    start()
    for text in paragraphs:
        for line in textwrap.wrap(str(text),width=94,replace_whitespace=True) or ['']:
            if y<.09:
                pdf.savefig(fig);plt.close(fig);start(True)
            fig.text(.085,y,line,size=10,color=COLORS['ink']);y-=.0195
        y-=.016
    pdf.savefig(fig);plt.close(fig)


def build_evidence_pdf(root):
    root=Path(root);target=root/'validated_research_report.pdf'
    temporary=root/'validated_research_report.tmp.pdf'
    cycles=[]
    for cycle in sorted(root.glob('cycle_*')):
        summary=cycle/'confirmation/summary.json'
        if not summary.exists():continue
        cycles.append((cycle,json.loads((cycle/'frozen_protocol.json').read_text()),json.loads(summary.read_text())))
    reproduced=[(c,r) for c,_,s in cycles for r in s['results'] if r['numerical_valid']]
    attempts=sum(s['completed'] for _,_,s in cycles)
    manifest={'title':'Structured-light research: numerical evidence and falsification',
              'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'batches':len(cycles),'confirmed_numerical_observations':len(reproduced),
              'confirmation_attempts':attempts,'novelty_verified':False,
              'scientific_status':['SIMULATION_ONLY','NOVELTY_NOT_VERIFIED','NOT_PUBLICATION_READY'],
              'includes_credentials':False,'source_artifacts':[c.name+'/confirmation/summary.json' for c,_,_ in cycles]}
    with PdfPages(temporary,metadata={'Title':manifest['title'],'Author':'AutoPhotonics Project',
                  'Subject':'Frozen hypotheses, independent propagation and convergence; no novelty claim',
                  'Keywords':'structured light, Pearcey, Airy, reproducibility, negative evidence'}) as pdf:
        overview=[
            'Purpose. This report separates reproducible numerical observations from invalid comparisons, numerical artifacts, known identities and untested scientific claims. It is a technical research report, not a claim of experimental discovery.',
            f'Evidence available. {len(cycles)} frozen experiment batches were inspected. {attempts} hypotheses received numerical follow-up; {len(reproduced)} passed the performed mesh, two-window, longitudinal-sampling and independent-propagation agreement gates. Robustness is assessed separately and can fail even when a scalar observation is reproduced.',
            'What was actually run. Monochromatic scalar angular-spectrum propagation, compared with independent real-space Fresnel quadrature. Source power, aperture, wavelength, observation window and the registered observable are retained for convergence tests. No model-generated executable code is run. Previously optimized controls are re-evaluated without refitting.',
            'Interpretation. A nonzero scalar difference alone is not a new physical mechanism. Coherent interference, Gaussian identities and vortex parity are known effects. Negative predictions and failed numerical tests are retained. Numerical reproduction is not novelty verification, a full Maxwell calculation, an experimental result or a publication decision.',
        ]
        for c,r in reproduced[:8]:
            overview.append(f"Reproduced observation: {c.name}/{r['hypothesis_id']}, signed effect {number(r['effect'])}; error floor {number(r['numerical_error_floor'])}; robust under all tested perturbations: {r['robustness_validated']}; registered prediction resolved with margin: {r['prediction_supported_with_error_margin']}.")
        page(pdf,'Structured-light research evidence',overview,subtitle='Verified computations, controls, numerical failures and remaining scientific questions')
        page(pdf,'Measurement and validation contract',[
            'A source is normalized to 1 W within a fixed circular aperture of radius 0.9 mm. The original computational window is 2.4 mm; wavelength is 633 nm unless a held-out wavelength is explicitly identified. The Gaussian envelope waist is 300 micrometres. Beam scale has family-specific meaning: it does not change the Gaussian waist in the present field generator.',
            'For the supplied Pearcey source, C4(u,v) is the canonical integral of exp[i(t^4 + v*t^2 + u*t)] over the real contour, evaluated by a convergent contour deformation, then multiplied by an explicit Gaussian envelope and circular aperture. The Butterfly source fixes two higher control parameters to zero. No polynomial phase mask is renamed as a canonical beam.',
            'Core efficiency is the median over the frozen observation planes of power inside a fixed on-axis circular disk, divided by input power. Valley filling is a midpoint-to-ridge intensity statistic in a transverse marginal profile and requires matched qualifying ridge pairs. It is not a direct phase measurement. Brightest-pixel trajectories are ambiguous when there are degenerate maxima.',
            'Fixed follow-up: 256 and 384 grids at 2.4 mm, windows of 3.6 and 4.8 mm at the fine grid spacing, doubled longitudinal intervals, and a separate real-space Fresnel calculation at the reference grid. Agreement is required both for the signed comparison effect and for the two actual arm observables. All solver, boundary and power gates must pass.',
            f"Tolerances fixed by policy v{POLICY['version']}: relative tolerance {POLICY['relative_tolerance']:.1%}; dimensionless absolute floor {POLICY['fraction_absolute_tolerance']}; ratio floor {POLICY['ratio_absolute_tolerance']}; position floor {POLICY['distance_absolute_tolerance_m']*1e6:g} micrometres. A signed prediction is resolved only if its margin exceeds the larger of the observed refinement discrepancy and the fixed floor. Meeting a weak >=0 inequality at zero is insufficient.",
            'Separate robustness probes: 256-level phase quantization; a fixed 640 nm wavelength hold-out with residual optical-path scaling; two fixed 0.02 rad input phase-noise realizations. No parameters are optimized on these probes. These tests are limited diagnostics, not statistical confidence intervals. Random pixel-noise screens are not a continuous stochastic field coupled across grids; their mesh interpretation requires caution.',
            'Controls: defocus, quadratic-plus-quartic and four-parameter Gaussian residual phases were optimized under equal original search budgets. The stored best parameters are re-evaluated at the reference grid under the same composition and environment as each candidate. This is not a proof of superiority over an exhaustive classical family.',
        ])
        for cycle,batch,summary in cycles:
            paragraphs=[batch['question'],
                'Registered proposed mechanism: '+batch['mechanism'],
                f"Observable: {batch['observable']}. Comparison: {batch['comparison']} ({COMPARISONS[batch['comparison']][0]} versus {COMPARISONS[batch['comparison']][1]}). Effect: {batch['effect']}; frozen prediction: {batch['direction']} {batch['threshold']}. A comparison across different source cases is not implicit in this interface.",
                f"Window: {batch['z_start_m']:.4g} to {batch['z_end_m']:.4g} m, {batch['z_planes']} planes; core radius {batch['core_radius_m']*1e6:.4g} micrometres. Source artifact: {cycle.name}/frozen_protocol.json."]
            original=json.loads((cycle/'experiment_summary.json').read_text())
            for r in original:
                h=r['hypothesis'];p=h['composition'];comp=r.get('comparison',{})
                failed=', '.join(k for k,v in r.get('checks',{}).items() if not v) or 'none'
                paragraphs.append(f"{h['id']}: {h['beam']['family']}, scale {h['beam']['scale_m']*1e6:g} micrometres, source transformations {h['transformations']}; copy angle {p['angle_rad']:.4g}, phase {p['phase_rad']:.4g} rad, amplitude weight {p['weight']:.4g}; environment {h['environment']['kind']}. Original effect {number(comp.get('effect'))}, testable {comp.get('testable',False)}; failed basic checks: {failed}.")
            for q in summary['queue']:
                paragraphs.append(f"Follow-up routing: {q['hypothesis_id']} -> {q['status']}; {q.get('reason') or q.get('result') or ''}.")
            for a in summary['results']:
                failures=', '.join(k for k,v in a['checks'].items() if not v) or 'none'
                robust=', '.join(k for k,v in a['robustness_checks'].items() if not v) or 'none'
                paragraphs.append(f"{a['hypothesis_id']}: {a['status']}; reference effect {number(a['effect'])}; numerical error floor {number(a['numerical_error_floor'])}. Failed confirmation gates: {failures}. Failed robustness probes: {robust}. Registered direction supported beyond error: {a['prediction_supported_with_error_margin']}. Frozen optimized controls passed basic checks: {a['control_checks_passed']}.")
            page(pdf,'Evidence batch '+cycle.name,paragraphs)
            for a in summary['results']:
                folder=cycle/'confirmation'/a['hypothesis_id']
                measurements=json.loads((folder/'measurements.json').read_text())
                labels=list(measurements);values=[measurements[k].get('comparison',{}).get('effect') for k in labels]
                fig,axes=plt.subplots(2,1,figsize=(8.27,11.69),gridspec_kw={'height_ratios':[1,1]})
                fig.subplots_adjust(left=.13,right=.94,top=.91,bottom=.11,hspace=.6)
                fig.suptitle(cycle.name+' / '+a['hypothesis_id'],size=16,weight='bold',color=COLORS['ink'])
                y=np.array([np.nan if v is None else v for v in values],float)
                colors=[COLORS['blue'] if all(measurements[k].get('checks',{}).values()) else COLORS['red'] for k in labels]
                axes[0].bar(range(len(labels)),y,color=colors)
                axes[0].axhline(batch['threshold'],color=COLORS['gray'],linestyle='--',label='Frozen prediction threshold')
                axes[0].set_xticks(range(len(labels)),labels,rotation=55,ha='right',fontsize=8)
                axes[0].set_ylabel(batch['observable']+' / '+batch['effect']);axes[0].legend(fontsize=8)
                axes[0].set_title('Performed confirmation and robustness probes',size=11)
                ref=measurements.get('reference',{}).get('comparison',{}).get('comparison_values',[])
                controls=json.loads((folder/'controls.json').read_text())
                names=[a['hypothesis_id']]+list(controls)
                pairs=[ref]+[controls[k].get('comparison',{}).get('comparison_values',[]) for k in controls]
                xx=np.arange(len(names))
                axes[1].bar(xx-.18,[v[0] if len(v)==2 else np.nan for v in pairs],width=.35,color=COLORS['blue'],label=COMPARISONS[batch['comparison']][0])
                axes[1].bar(xx+.18,[v[1] if len(v)==2 else np.nan for v in pairs],width=.35,color=COLORS['green'],label=COMPARISONS[batch['comparison']][1])
                axes[1].set_xticks(xx,names,rotation=25,ha='right',fontsize=8);axes[1].set_ylabel(batch['observable']);axes[1].legend(fontsize=8)
                axes[1].set_title('Reference-grid candidate and frozen optimized controls',size=11)
                fig.text(.13,.035,'Red bars fail at least one numerical gate. Missing measurements are not zero.\nControls are re-evaluations of frozen parameters, not exhaustive optima or a novelty test.',size=8,color=COLORS['gray'])
                figure=folder/'validation_figure.png';fig.savefig(figure,dpi=160)
                pdf.savefig(fig);plt.close(fig)
        page(pdf,'Physical interpretation and falsification',[
            'Coherent composition changes both local intensity and its equal-power normalization. If each constituent has power P, define input overlap S = integral(conj(E1)*E2)/P and the propagated core cross term C(z) = integral_core(conj(U1)*U2)/P. For amplitude weight w and phase phi, coherent core efficiency is [A(z)+w^2 B(z)+2w Re(exp(i phi) C(z))] / [1+w^2+2w Re(exp(i phi) S)]. The incoherent value is [A(z)+w^2 B(z)]/(1+w^2). The report statistic takes the registered median over z.',
            'This familiar interference identity explains why changing phase can redistribute core power without creating optical power. It does not establish a Pearcey-specific mechanism. A mechanism study must isolate overlap and normalization, use matched Gaussian and asymmetric controls, and test frozen held-out settings. Opposite-phase negative effects can falsify an overly broad nonnegative prediction while remaining reproducible observations.',
            'Known or invalid situations must remain explicit: a Gaussian and its half-turn copy can be identical up to global phase; odd-charge vortex fields can cancel exactly. Equal-power renormalization of a zero field is undefined. A transformed-versus-base comparison preserves the declared environment, including any lens. The explicit lens-versus-free-space comparison is required to test the same source with and without the lens.',
            'Boundary tests matter for long Airy tails and ridge identification. A large apparent valley-filling effect that changes under window enlargement cannot support a stable quantitative claim. Spatial refinement alone is insufficient. The available windows and tolerance checks are finite diagnostics and do not prove an asymptotic convergence theorem.',
            'Next discriminating experiment. Freeze a complete charge-by-phase or family-by-phase factorial design with balanced controls, a common observable and hold-out parameters. Execute it through the trusted structured interface, retain all failures and signs, then compare with specific prior results. Do not select a favorable core radius, propagation window, prediction direction or phase after inspecting the same data.',
        ])
        from .knowledge import KnowledgeAgent
        sources=KnowledgeAgent().data['sources']
        references=['The following are source-library references with project-recorded provenance. This run does not revalidate their full text, and they do not constitute an exhaustive novelty search. No new citation or DOI is invented.']
        for doi,source in sources.items():
            references.append(f"{source['title']} ({source.get('year','year unrecorded')}). DOI: {doi}. Source-library verification: {source.get('verification','not recorded')}.")
        references += ['Reproducibility. Each batch directory contains its frozen protocol, original measurements, a frozen validation protocol, persistent queue, reference/variant measurements, solver settings, per-hypothesis assessment and re-evaluated controls. The run evaluation journal records started, completed and failed attempts. The PDF is rebuilt deterministically from these records; JSON files remain authoritative.',
                       'Limitations. Scalar and paraxial models have finite applicability; high-angle vector and nonlinear effects are outside scope. Robustness probes are limited fixed tests, not population statistics. Source-library metadata is not an exhaustive technical prior-art review. Human scientific review remains necessary before a research or publication claim.']
        page(pdf,'References, provenance and limitations',references)
    temporary.replace(target)
    manifest['pdf']=target.name;manifest['bytes']=target.stat().st_size
    write(root/'report_manifest.json',manifest)
    return target
