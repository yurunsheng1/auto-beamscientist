"""Optional budgeted LLM ideation. The sole output interface is hypothesis JSON."""
from __future__ import annotations
import json
import re
from ..paper_writing import reserve_paper_call
from ..llm_config import reasoning_options
from .schemas import Hypothesis


class PGCDProposalAgent:
    def __init__(self,out,knowledge,strategy,model,ledger):
        from openai import OpenAI
        # Endpoint/auth are supplied by the already configured process. Do not
        # read, copy, serialize or print credentials into research artifacts.
        self.client=OpenAI(timeout=65,max_retries=0)
        self.out=out;self.knowledge=knowledge;self.strategy=strategy;self.model=model;self.ledger=ledger
        self.state={'calls':0,'max_api_calls':50};self.local_calls=len(list(out.glob('proposal_call_*.json')))

    def propose_batch(self,index,count,nodes,baselines,example,journal):
        journal.check()
        if self.local_calls>=4:raise RuntimeError('PGCD batch proposal call ceiling reached')
        parents=[n['id'] for n in nodes if n['state'] in ('criticized','candidate')]
        summary=[{'id':n['id'],'composition':n['hypothesis'],'review':n.get('review'),
                  'evidence':n.get('evidence'),'selection_score':n.get('selection_score')} for n in nodes[-5:]]
        system=('You are the AutoPhotonics / AI Scientist PGCD composition agent. '
                'Return only a JSON array of validated scientific hypotheses, never executable code.\n'+self.strategy)
        prompt=json.dumps({'task':f'Propose {count} distinct falsifiable compositions, IDs H{index+1:03d} through H{index+count:03d}. '
                          'Use only the supplied mathematical families and transformations. When completed nodes exist, evolve their discrete structures using failures and discriminating tests. '
                          'Use all five families across the first batch. Known-family provenance and a new composition are not verified novelty. '
                          'Prediction must use metric axial_floor and minimum_gain 0.03. Do not change the observation window. '
                          'Do not propose code, fabricate effects, add unsupported nonlinear environments or cite unverifiable papers.',
                          'knowledge':self.knowledge.data,'schema_example':example.record(),
                          'allowlisted_transformations':{'chirp':[-1.2,1.2],'quartic':[-.7,.7],'ripple':[-1.,1.],
                            'vortex':[-3,3],'rotate':[-3.141592653589793,3.141592653589793],
                            'stretch':[.7,1.4],'coherent_pair':[-3.141592653589793,3.141592653589793]},
                          'allowed_environments':['thin_lens','free_space','phase_screen'],
                          'allowed_parent_ids':parents,'recent_experiments':summary,
                          'optimized_baselines':baselines},ensure_ascii=False)
        call_id=reserve_paper_call(self.state,self.ledger);self.local_calls+=1
        path=self.out/f'proposal_call_{call_id:02d}.json'
        audit={'call':call_id,'model':self.model,'system':system,'prompt':prompt,'status':'reserved'}
        path.write_text(json.dumps(audit,indent=2,ensure_ascii=False))
        try:
            response=self.client.responses.create(model=self.model,instructions=system,
                input=[{'role':'user','content':prompt}],max_output_tokens=12000,reasoning=reasoning_options())
            audit.update(status=response.status,response=response.output_text,
                         usage=response.usage.model_dump() if response.usage else None)
            path.write_text(json.dumps(audit,indent=2,ensure_ascii=False))
            if response.status!='completed':raise ValueError('Incomplete proposal response; no partial hypotheses accepted')
            text=re.sub(r'^```(?:json)?\s*|\s*```$','',response.output_text.strip())
            raw=json.loads(text)
            if not isinstance(raw,list) or len(raw)!=count:raise ValueError('Expected exact-size hypothesis array')
            hypotheses=[Hypothesis.from_dict(row) for row in raw]
            for offset,h in enumerate(hypotheses):
                if h.id!=f'H{index+offset+1:03d}' or (h.parent_id is not None and h.parent_id not in parents):
                    raise ValueError('Unrecognized hypothesis ID or parent lineage')
                if h.minimum_gain!=.03:raise ValueError('Prediction margin must remain 3%')
                if h.beam.family in ('pearcey','butterfly') and h.beam.scale_m<150e-6:
                    raise ValueError('Catastrophe field scale too small for this bounded quadrature protocol')
                if parents and h.parent_id is None:raise ValueError('Evolution batch must identify its evidence parent')
            return hypotheses
        except Exception as exc:
            audit.update(validation_error=type(exc).__name__+': '+str(exc))
            path.write_text(json.dumps(audit,indent=2,ensure_ascii=False))
            raise
