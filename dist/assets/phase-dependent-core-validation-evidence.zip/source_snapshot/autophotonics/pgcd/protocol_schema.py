"""API schema for the existing trusted experiment interface; no solver changes."""
import math
from .research_experiment import OBSERVABLES, COMPARISONS, ResearchBatch
from .schemas import TRANSFORMS


def object_schema(properties):
    return {'type': 'object', 'properties': properties,
            'required': list(properties), 'additionalProperties': False}


def experiment_response_format(cycle_index, count):
    text = {'type': 'string'}
    number = {'type': 'number'}
    beam = object_schema({
        'family': {'type': 'string', 'enum': ['gaussian', 'airy', 'pearcey', 'butterfly', 'vortex']},
        'scale_m': {'type': 'number', 'minimum': 20e-6, 'maximum': 400e-6},
        'apodization': {'type': 'number', 'minimum': .05, 'maximum': .5},
        'charge': {'type': 'integer', 'minimum': -3, 'maximum': 3},
    })
    transformation = object_schema({
        'kind': {'type': 'string', 'enum': sorted(TRANSFORMS)}, 'amount': number,
    })
    environment = object_schema({
        'kind': {'type': 'string', 'enum': ['free_space', 'thin_lens', 'phase_screen']},
        'phase_rms': {'type': 'number', 'minimum': 0, 'maximum': .1},
        'seed': {'type': 'integer', 'minimum': 0, 'maximum': 2**31-1},
    })
    angle = {'type': 'number', 'minimum': -math.pi, 'maximum': math.pi}
    composition = object_schema({
        'angle_rad': angle, 'phase_rad': angle,
        'weight': {'type': 'number', 'minimum': 0, 'maximum': 1},
    })
    hypothesis = object_schema({
        'id': {'type': 'string', 'enum': [f'C{cycle_index:04d}H{i:03d}' for i in range(1, count+1)]},
        'beam': beam,
        'transformations': {'type': 'array', 'items': transformation, 'maxItems': 3},
        'environment': environment, 'prediction': text, 'mechanism': text,
        'minimum_gain': {'type': 'number', 'enum': [0]},
        'metric': {'type': 'string', 'enum': ['scientist_selected']},
        'parent_id': {'type': ['string', 'null']}, 'composition': composition,
    })
    batch = object_schema({
        'question': text, 'mechanism': text,
        'observable': {'type': 'string', 'enum': list(OBSERVABLES)},
        'comparison': {'type': 'string', 'enum': list(COMPARISONS)},
        'effect': {'type': 'string', 'enum': ['ratio', 'difference', 'relative_change']},
        'direction': {'type': 'string', 'enum': ['>=', '<=']},
        'threshold': {'type': 'number', 'minimum': -1e6, 'maximum': 1e6},
        'z_start_m': {'type': 'number', 'minimum': .01, 'maximum': .19},
        'z_end_m': {'type': 'number', 'minimum': .011, 'maximum': .2},
        'z_planes': {'type': 'integer', 'minimum': 5, 'maximum': 21},
        'core_radius_m': {'type': 'number', 'minimum': 20e-6, 'maximum': 250e-6},
        'marginal_half_width_m': {'type': 'number', 'minimum': .2e-3, 'maximum': .6e-3},
        'ridge_prominence': {'type': 'number', 'minimum': .1, 'maximum': .5},
        'phase_noise_rms': {'type': 'number', 'minimum': 0, 'maximum': .1},
        'max_separation_change': {'type': ['number', 'null'], 'minimum': 0, 'maximum': 1},
        'cases': {'type': 'array', 'items': hypothesis, 'minItems': count, 'maxItems': count},
    })
    schema = object_schema({'protocol': {'anyOf': [batch, object_schema({'unsupported_measurement': text})]}})
    return {'format': {'type': 'json_schema', 'name': 'trusted_research_protocol',
                       'strict': True, 'schema': schema}}


def validate_design(raw, count, existing):
    """Reject invalid model data before any numerical outcomes are inspected."""
    if isinstance(raw, dict) and set(raw) == {'unsupported_measurement'}:
        if not isinstance(raw['unsupported_measurement'], str) or not raw['unsupported_measurement'].strip():
            raise ValueError('Unsupported measurement requires an explanation')
        return None
    batch = ResearchBatch.from_dict(raw)
    if len(batch.cases) != count:
        raise ValueError('Model returned wrong hypothesis count')
    if batch.comparison=='transformed_vs_base' and any(not h.transformations for h in batch.cases):
        raise ValueError('transformed_vs_base removes source transformations only and preserves the environment. Empty transformations compare a field to itself; use lens_vs_free_space for a lens-on/off question or return unsupported_measurement.')
    if any(h.id in existing or (h.parent_id is not None and h.parent_id not in existing) for h in batch.cases):
        raise ValueError('Invalid experiment lineage')
    return batch
