"""Validated evidence-to-figure boundary: descriptions never become executable code."""
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import numpy as np
from ..llm_config import reasoning_options

RECIPES = {'parity_components', 'quartic_moment_test', 'vortex_ring_scan', 'coherence_law', 'recorded_comparisons'}

@dataclass(frozen=True)
class FigurePlan:
    recipe: str
    question: str
    falsifier: str
    comparisons: tuple[str, ...]

    @classmethod
    def from_dict(cls, value):
        if not isinstance(value, dict) or set(value) != {'recipe','question','falsifier','comparisons'}:
            raise ValueError('Figure plan accepts only the documented structured fields')
        if value['recipe'] not in RECIPES:
            raise ValueError('Unknown trusted figure recipe')
        if any(not isinstance(value[k],str) or not 1 <= len(value[k]) <= 3000 for k in ('question','falsifier')):
            raise ValueError('A figure requires a scientific question and falsifier')
        c = value['comparisons']
        if not isinstance(c,list) or not 1 <= len(c) <= 12 or any(not isinstance(s,str) or not 1 <= len(s) <= 300 for s in c):
            raise ValueError('Explicit bounded comparisons required')
        return cls(value['recipe'],value['question'],value['falsifier'],tuple(c))

    def record(self):
        return asdict(self)


def render_recorded_evidence(records, cycle: Path, out: Path, observable: str, labels):
    """Show every valid case's own propagation, rather than a Gaussian anchor only."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    valid=[r for r in records if r.get('checks') and all(r['checks'].values()) and r.get('comparison',{}).get('testable')]
    plan=FigurePlan('recorded_comparisons', 'Which cases support the frozen prediction?',
                    'Failed constraints or an unsupported comparison reject the prediction.',
                    tuple(r['hypothesis']['id'] for r in valid))
    (out/'figure_plan.json').write_text(json.dumps(plan.record(),indent=2))
    fig,ax=plt.subplots(figsize=(7,3.3),layout='constrained')
    values=[r for r in records if r.get('comparison',{}).get('comparison_values')]
    if values:
        x=np.arange(len(values));ab=np.asarray([r['comparison']['comparison_values'] for r in values])
        for i in range(2):ax.plot(x,ab[:,i], 'o-' if i==0 else 's--', label=labels[i])
        ax.set(xticks=x,xticklabels=[r['hypothesis']['id'] for r in values],ylabel=observable)
        ax.tick_params(axis='x',labelrotation=30);ax.legend(frameon=False)
    fig.savefig(out/'research_results.png',dpi=190);plt.close(fig)
    chosen=valid[:6]
    fig,axs=plt.subplots(1,len(chosen),figsize=(3.1*len(chosen),3.2),squeeze=False,layout='constrained')
    for ax,r in zip(axs[0],chosen):
        with np.load(cycle/(r['hypothesis']['id']+'.npz')) as a:
            im=ax.pcolormesh(a['x_m']*1e3,a['z_m']*1e3,a['single_profile'],cmap='magma',shading='nearest')
            ax.set(xlabel='x (mm)',ylabel='z (mm)',title=r['hypothesis']['id']+' / '+r['hypothesis']['beam']['family'])
            fig.colorbar(im,ax=ax,label='Marginal intensity (W/m)')
    fig.savefig(out/'case_propagation.png',dpi=190);plt.close(fig)
    return plan, ['research_results.png','case_propagation.png']

@dataclass(frozen=True)
class EvidenceFigureSelection:
    kind: str
    hypothesis_ids: tuple[str, ...]
    rationale: str
    falsifier: str

    @classmethod
    def from_dict(cls, value, valid_ids):
        if not isinstance(value,dict) or set(value)!={'kind','hypothesis_ids','rationale','falsifier'}:
            raise ValueError('Unknown figure selection fields')
        if value['kind'] not in {'focal_comparison','case_propagation'}:
            raise ValueError('Unsupported trusted rendering operation')
        ids=value['hypothesis_ids']
        if not isinstance(ids,list) or not 1<=len(ids)<=6 or len(set(ids))!=len(ids) or any(i not in valid_ids for i in ids):
            raise ValueError('Figures must identify existing valid observations')
        if any(not isinstance(value[k],str) or not 1<=len(value[k])<=3000 for k in ('rationale','falsifier')):
            raise ValueError('Every selection needs a scientific purpose and falsifier')
        return cls(value['kind'],tuple(ids),value['rationale'],value['falsifier'])


def select_evidence_figure(records,question,out,*,deadline,ledger_path,global_max_calls,model='deepseek-flash'):
    """One budgeted model turn; errors are recorded and never execute model text."""
    import time
    from ..auto_paper import model_json
    from ..paper_writing import reserve_paper_call
    valid=[r for r in records if r.get('checks') and all(r['checks'].values()) and r.get('comparison',{}).get('testable')]
    ids={r['hypothesis']['id'] for r in valid}
    # The fallback remains explicit, without attributing it to an AI decision.
    fallback=EvidenceFigureSelection('focal_comparison',tuple(r['hypothesis']['id'] for r in valid[:6]),
        'Show individually identified valid cases and their actual saved focal arms.',
        'Missing or invalid evidence cannot support a mechanism claim.')
    state={'calls':0,'max_api_calls':global_max_calls}
    try:
        if time.monotonic()>=deadline:raise RuntimeError('Figure planning deadline reached')
        from openai import OpenAI
        reserve_paper_call(state,Path(ledger_path))
        response=OpenAI(timeout=min(75,max(1,deadline-time.monotonic())),max_retries=0).responses.create(
            model=model,reasoning=reasoning_options('none'),max_output_tokens=2500,
            instructions='You are the Auto BeamScientist evidence-figure planner. Choose actual valid cases that test the mechanism, rather than a convenient Gaussian anchor. Return JSON only, no code.',
            input='Return {"kind":"focal_comparison" or "case_propagation","hypothesis_ids":[existing IDs, at most six],"rationale":str,"falsifier":str}. Focal comparison uses saved single/coherent intensity arrays (and their signed difference); propagation uses each case\'s saved single-arm marginal. These plots cannot establish novelty or supply missing experiments. Question: '+question+'\nObservations: '+json.dumps(valid))
        (out/'figure_agent_call.json').write_text(json.dumps({'call':state['calls'],'status':response.status,'output':response.output_text,'usage':response.usage.model_dump() if response.usage else None},indent=2))
        if response.status!='completed':raise ValueError('Truncated figure plan')
        chosen=EvidenceFigureSelection.from_dict(model_json(response.output_text),ids)
        source='model'
    except Exception as exc:
        chosen=fallback;source='explicit deterministic fallback'
        (out/'figure_agent_error.json').write_text(json.dumps({'error_type':type(exc).__name__,'error':str(exc)},indent=2))
    (out/'figure_selection.json').write_text(json.dumps({'source':source,**asdict(chosen)},indent=2))
    return chosen


def render_selected_evidence(selection,records,cycle,out):
    """Trusted intensity renderer. No arbitrary expression or generated code path."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    by_id={r['hypothesis']['id']:r for r in records}
    if selection.kind=='case_propagation':
        return None
    ids=selection.hypothesis_ids
    fig,axes=plt.subplots(len(ids),3,figsize=(9,2.65*len(ids)),squeeze=False,layout='constrained')
    for row,id in enumerate(ids):
        r=by_id[id]
        with np.load(cycle/(id+'.npz')) as a:
            x=a['x_m']*1e3;single=a['single_focal']
            coherent=a['coherent_focal'] if 'coherent_focal' in a else None
            upper=max(float(single.max()),float(coherent.max()) if coherent is not None else 0)
            for ax,image,title in [(axes[row,0],single,'Single'),(axes[row,1],coherent,'Coherent')]:
                if image is None:ax.text(.5,.5,'Exact cancellation / unavailable',ha='center');ax.set_axis_off();continue
                im=ax.pcolormesh(x,x,image,shading='nearest',cmap='magma',vmin=0,vmax=upper,rasterized=True)
                ax.set(xlabel='x (mm)',ylabel='y (mm)',aspect='equal',title=id+' '+r['hypothesis']['beam']['family']+' / '+title)
                fig.colorbar(im,ax=ax,label='Intensity (W/m²)')
            ax=axes[row,2]
            if coherent is None:ax.set_axis_off();continue
            diff=coherent-single;lim=float(abs(diff).max()) or 1
            im=ax.pcolormesh(x,x,diff,shading='nearest',cmap='RdBu_r',vmin=-lim,vmax=lim,rasterized=True)
            ax.set(xlabel='x (mm)',ylabel='y (mm)',aspect='equal',title='Saved focal intensities: coherent − single')
            fig.colorbar(im,ax=ax,label='Difference (W/m²)')
    fig.savefig(out/'mechanism_comparison.png',dpi=170);plt.close(fig)
    return 'mechanism_comparison.png'
