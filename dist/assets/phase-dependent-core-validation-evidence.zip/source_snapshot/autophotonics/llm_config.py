"""Provider-neutral settings for bounded Responses API requests."""
import os


def reasoning_options(default: str = 'low') -> dict[str, str]:
    effort = os.environ.get('AUTOPHOTONICS_REASONING_EFFORT', default)
    if effort not in {'none', 'minimal', 'low', 'medium', 'high', 'xhigh'}:
        raise ValueError('Invalid AUTOPHOTONICS_REASONING_EFFORT')
    return {'effort': effort}
